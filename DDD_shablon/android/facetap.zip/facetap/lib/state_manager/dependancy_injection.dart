import 'package:facetap/apis/apis.dart';
import 'package:facetap/models/upload_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/services/authentication_service.dart';
import 'package:facetap/services/cache_service.dart';
import 'package:facetap/services/gifts_service.dart';
import 'package:facetap/services/media_upload_service.dart';
import 'package:facetap/services/places_service.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/services/serializer.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:get_it/get_it.dart';

final locator = GetIt.instance;

void init() {
  // services
  locator.registerLazySingleton(() => NavigationService());
  // locator.registerLazySingleton(() => BaseClassProvider());
  locator.registerLazySingleton(() => Serializer());
  locator.registerLazySingleton(() => CacheService());
  locator.registerLazySingleton(() => AuthenticationService());
  locator.registerLazySingleton(() => UserService());
  locator.registerLazySingleton(() => MediaUploadService());
  locator.registerLazySingleton(() => PostsService());
  locator.registerLazySingleton(() => PlacesService());
  locator.registerLazySingleton(() => GiftsService());

  //apis
  locator.registerLazySingleton(() => ApiClient());

  //models
  locator.registerLazySingleton(() => UserModel());
  locator.registerLazySingleton(() => UploadModel());
}
