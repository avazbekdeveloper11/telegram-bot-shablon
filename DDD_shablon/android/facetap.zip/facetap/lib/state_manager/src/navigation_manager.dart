import 'package:flutter/widgets.dart';

class NavigationService {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();

  get currentContext => _navigatorKey.currentContext;

  get navigationKey => _navigatorKey;

  Future<T> push<T extends Object>(Route<T> route) {
    return _navigatorKey.currentState.push(route);
  }

  Future<T> pushAndRemoveUntil<T extends Object>(Route<T> route) {
    return _navigatorKey.currentState.pushAndRemoveUntil(route, (_) => false);
  }

  void pop<T extends Object>([T result]) {
    return _navigatorKey.currentState.pop(result);
  }
}
