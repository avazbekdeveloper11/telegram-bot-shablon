enum LoadingState{
  loading,
  idle
}