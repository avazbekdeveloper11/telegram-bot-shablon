import 'package:facetap/apis/errors.dart';
import 'package:facetap/models/error_model.dart';
import 'package:facetap/services/serializer.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';

import 'dependancy_injection.dart';
import 'enums.dart';
import 'manager.dart';

abstract class BaseViewModel extends BaseViewModelManager {
  final NavigationService navigationService = locator<NavigationService>();
  final Serializer serializer = locator<Serializer>();

  bool get isloading => isBusy;

  void setState(LoadingState loadingState) {
    loadingState == LoadingState.loading ? setBusy(true) : setBusy(false);
  }

  Future<T> onError<T extends Object>(dynamic error) {
    if (error is ErrorModel) showSnackBar(error.error.message);

    if (error == ApiClientErrors.UNKNOWN_ERROR) showSnackBar('Error occured, please try again.');
    if (error == ApiClientErrors.NOT_FOUND) showSnackBar('Error occured, please try again.');
    if (error == ApiClientErrors.SERVER_ERROR) showSnackBar('We are experiencing server side error, please try again.');
    return null;
  }

  void showSnackBar(String message) {
    ScaffoldMessenger.of(navigationService.currentContext).showSnackBar(
      SnackBar(
          content: Text(
            message,
            style: Regular.copyWith(color: BlackColor),
          ),
          backgroundColor: WhiteColor),
    );
  }

  void initState() {}

  void onDispose() {

  }

  void deactivate() {}

  void didChangeAppLifecycleState(AppLifecycleState state) {}
}
