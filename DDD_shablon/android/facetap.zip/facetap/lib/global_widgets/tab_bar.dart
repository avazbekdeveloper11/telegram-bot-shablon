
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class CustomTabBar extends StatelessWidget {
  final TabController tabController;
  final List<String> tabs;
 final Function onTap;

  const CustomTabBar({Key key, @required this.tabController,  @required  this.tabs,  @required  this.onTap}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return   TabBar(
      dragStartBehavior: DragStartBehavior.down,
      onTap: (i)=> onTap(i),
      labelPadding: EdgeInsets.zero,
      isScrollable: false,
      indicatorColor: Colors.white,
      labelColor:  Colors.white,
      controller: tabController,
      labelStyle: Bold.copyWith(fontSize: 14.0),
      unselectedLabelColor: Color(0xffAAABAD),
      tabs: tabs.map((item) => Tab(text: item, iconMargin: EdgeInsets.zero)).toList(),
    );
  }
}

