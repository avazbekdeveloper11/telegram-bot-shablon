import 'package:flutter/material.dart';

class ContentLoader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: const [
        CircularProgressIndicator(),
        /*SizedBox(height: 20),
          Text('Loading'),*/
      ],
    );
  }
}
