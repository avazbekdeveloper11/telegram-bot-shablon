import 'package:extended_image/extended_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/view_model/image_category_view_model.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class ImageTemplate extends StatelessWidget {
  final PostModel post;
  final bool isImage;
  final String hashTagName;
  final Function onViewPostClicked;

  const ImageTemplate({Key key, this.post, this.isImage = true, this.hashTagName = '', this.onViewPostClicked})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ImageCategoryViewModel>.reactive(
      viewModelBuilder: () => ImageCategoryViewModel(),
      builder: (context, model, _) {
        return GestureDetector(
          child: isImage
              ? Container(
                  padding: EdgeInsets.all(1.0),
                  height: screenWidth(context) / 2.8,
                  width: screenWidth(context) / 3 - 2,
                  child: Stack(
                    children: [
                      Container(
                        height: screenWidth(context) / 2.8,
                        width: screenWidth(context) / 3,
                        child: post != null
                            ? ExtendedImage.network(
                          post.medias.first.thumbnailUrl,
                          clearMemoryCacheWhenDispose: false,
                          fit: BoxFit.cover,
                          cache: true,
                          loadStateChanged: (ExtendedImageState state) {
                            switch (state.extendedImageLoadState) {
                              case LoadState.loading:
                                return Container();
                                break;
                              case LoadState.completed:
                                return ExtendedRawImage(
                                  image: state.extendedImageInfo?.image,
                                );
                                break;
                              case LoadState.failed:
                                Future.delayed(Duration(seconds: 1), (){state.reLoadImage();});
                                return Container();
                                break;
                              default:
                                return Container();
                            }
                          },
                        )
                            : Container(color: TextFromFieldHintColor.withOpacity(0.5)),
                      ),
                      (post != null)
                          ? Positioned(
                              bottom: 0,
                              right: 0,
                              child: Container(
                                margin: EdgeInsets.all(8),
                                child: Row(
                                  children: [
                                    Text('${post.likeCount}', style: Regular.copyWith(color: WhiteColor, fontSize: 13)),
                                    SvgPicture.asset(Assets.svgMiniHeart, color: post.isLiked ? AccentColor : WhiteColor),
                                  ],
                                ),
                              ),
                            )
                          : Container()
                    ],
                  ),
                )
              : GestureDetector(
                  onTap: () => model.onHashTagHeaderTap(hashTagName),
                  child: Container(
                    margin: EdgeInsets.only(right: 2),
                    height: screenWidth(context) / 2.8,
                    width: screenWidth(context) / 3 - 2,
                    color: Transparent,
                    child: Center(
                      child: Text('Tap to view more content',
                          style: Medium.copyWith(color: WhiteColor), textAlign: TextAlign.center),
                    ),
                  ),
                ),
          onTap: () => onViewPostClicked() ?? model.onNavigationContentPageTap(isImage, post),
        );
      },
    );
  }
}
