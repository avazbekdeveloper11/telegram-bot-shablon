import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/view_model/content_controller_view_model.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/formatter.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import 'menu_button.dart';

class ContentController extends StatelessWidget {
  final Function onCommentsPressed;
  final Function onLikedPressed;
  final Function onSubscribePressed;
  final Function updateNeeded;
  final bool isOpenCommentsIcon;
  final PostModel post;
  final List<String> usersIHaveSubscribed;

  const ContentController({
    Key key,
    this.onCommentsPressed,
    this.onSubscribePressed,
    this.isOpenCommentsIcon = true,
    @required this.post,
    this.onLikedPressed,
    this.usersIHaveSubscribed,
    this.updateNeeded,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ContentControllerViewModel>.reactive(
      initState: (model) => model.initData(usersIHaveSubscribed, updateNeeded),
      viewModelBuilder: () => ContentControllerViewModel(),
      builder: (context, model, _) {
        print('post: $post');
        bool showPlus =
            (model.userModel.id != post.user.id) && (post.user.amIFollowing != 'true') && (!(usersIHaveSubscribed ?? []).contains(post.user.id));
        double padding = showPlus ? 12.0 : 0.0;
        return model.progress != 0
            ? Center(
                child: Container(
                  height: screenWidth(context) / 4,
                  width: screenWidth(context) / 2,
                  decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(8)),
                  child: Center(
                    child: Container(
                      padding: EdgeInsets.all(16),
                      height: screenWidth(context) / 4,
                      width: screenWidth(context) / 4,
                      child: Stack(
                        children: [
                          Container(
                            height: screenWidth(context) / 4 - 32,
                            width: screenWidth(context) / 4 - 32,
                            child: CircularProgressIndicator(
                              strokeWidth: 8,
                              backgroundColor: Color(0x24ffffff),
                              valueColor: new AlwaysStoppedAnimation<Color>(Colors.white),
                              value: model.progress / 100,
                            ),
                          ),
                          Center(
                            child: Text(
                              "${model.progress.toInt()}%",
                              style: Medium.copyWith(color: Colors.white, fontSize: 17),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              )
            : Stack(
                children: [
                  Container(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                GestureDetector(
                                  onTap: () => model.onNavigationProfilePage(post.user.id),
                                  child: Container(
                                    padding: EdgeInsets.only(bottom: padding),
                                    child: CircleAvatar(
                                      radius: 25.0,
                                      backgroundColor: TextFromFieldHintColor,
                                      child: post.user.profilePhoto.isNotEmpty
                                          ? ClipRRect(
                                              borderRadius: BorderRadius.circular(50.0),
                                              child: CachedNetworkImage(
                                                imageUrl: post.user.profilePhoto,
                                                fit: BoxFit.cover,
                                                height: 50.0,
                                                width: 50.0,
                                                placeholder: (context, url) => Container(color: PrimaryLightColor),
                                              ),
                                            )
                                          : SvgPicture.asset(Assets.svgAvatarPlaceholder),
                                    ),
                                    color: Colors.transparent,
                                  ),
                                ),
                                showPlus
                                    ? GestureDetector(
                                        onTap: onSubscribePressed,
                                        child: CircleAvatar(
                                          radius: 12.0,
                                          backgroundColor: AccentColor,
                                          child: Icon(Icons.add, color: WhiteColor, size: 18.0),
                                        ),
                                      )
                                    : Container(),
                              ],
                            ),
                            SizedBox(width: 12.0),
                            Column(
                              children: [
                                GestureDetector(
                                  onTap: () => model.onNavigationProfilePage(post.user.id),
                                  child: Container(
                                      color: Colors.transparent,
                                      padding: EdgeInsets.all(4),
                                      child: Text('@${post.user.username}', style: Medium.copyWith(fontSize: 16.0, color: WhiteColor))),
                                ),
                                Text(
                                  '${formatAmount(post.viewCount)} views',
                                  style: Medium.copyWith(fontSize: 14.0, color: WhiteColor.withOpacity(0.4)),
                                ),
                              ],
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            Flexible(child: Container()),
                            Container(
                              height: 48.0,
                              width: 48.0,
                              child: MenuButton(
                                icon: SvgPicture.asset(Assets.svgMoreHorizontal),
                                onTap: () => model.sharePost(post),
                                radius: 24.0,
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 16.0),
                          child: Container(
                            width: double.infinity,
                            child: Text(post.caption, style: Regular.copyWith(color: WhiteColor, fontSize: 14.0)),
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              child: Container(
                                color: Colors.transparent,
                                padding: EdgeInsets.all(4),
                                child: Row(
                                  children: [
                                    SvgPicture.asset(Assets.svgFeedComment),
                                    SizedBox(width: 8.0),
                                    Text('${formatAmount(post.commentCount)}', style: Medium.copyWith(color: WhiteColor, fontSize: 14.0)),
                                  ],
                                ),
                              ),
                              onTap: onCommentsPressed,
                            ),
                            GestureDetector(
                              onTap: onLikedPressed,
                              child: Container(
                                color: Colors.transparent,
                                padding: EdgeInsets.all(8),
                                child: Row(
                                  children: [
                                    post.isLiked ? SvgPicture.asset(Assets.svgFeedLike) : SvgPicture.asset(Assets.svgFeedDislike),
                                    SizedBox(width: 8.0),
                                    Text('${formatAmount(post.likeCount)}', style: Medium.copyWith(color: WhiteColor, fontSize: 14.0)),
                                  ],
                                ),
                              ),
                            ),
                            Row(
                              children: [
                                SvgPicture.asset(Assets.svgFeedRating),
                                SizedBox(width: 8.0),
                                Text('${formatAmount(post.rating)}', style: Medium.copyWith(color: WhiteColor, fontSize: 14.0)),
                              ],
                            ),
                          ],
                        ),
                        isOpenCommentsIcon
                            ? IconButton(
                                color: Colors.transparent,
                                onPressed: onCommentsPressed,
                                icon: SvgPicture.asset(Assets.svgCommentClose, width: 12.0, height: 12.0),
                                padding: EdgeInsets.only(top: 22.0, left: 100.0, right: 100.0),
                              )
                            : Container(),
                      ],
                    ),
                    decoration: BoxDecoration(
                      gradient: isOpenCommentsIcon
                          ? LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.center,
                              colors: [PrimaryColor, Transparent],
                              stops: [0.0, 0.5],
                            )
                          : LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.center,
                              colors: [Transparent, Transparent],
                              stops: [0.0, 0.5],
                            ),
                    ),
                  ),
                  model.isloading ? Loading() : Container()
                ],
              );
      },
    );
  }
}
