import 'dart:ui';

import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/view_model/comments_page_view_model.dart';
import 'package:facetap/global_widgets/views/changed_text_form_field.dart';
import 'package:facetap/global_widgets/views/comments_view_text.dart';
import 'package:facetap/global_widgets/views/infinite_list_empty.dart';
import 'package:facetap/models/comments_model.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class CommentsPage extends StatelessWidget {
  final PostModel post;

  const CommentsPage({Key key, this.post}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<CommentsViewModel>.reactive(
      initState: (model) => model.initData(post),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => CommentsViewModel(),
      builder: (context, model, _) {
        return Container(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              color: PrimaryDarkColor.withOpacity(0.5),
              child: GestureDetector(
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment.topCenter,
                      child: Column(
                        children: [
                          IconButton(
                            onPressed: model.onCloseComments,
                            icon: SvgPicture.asset('assets/svg/open_comments.svg', width: 12.0, height: 12.0),
                            padding: EdgeInsets.only(top: 50.0, bottom: 24.0, left: 100.0, right: 100.0),
                          ),
                          Text(
                            '${model.post.commentCount} comments',
                            style: Regular.copyWith(color: WhiteColor),
                          ),
                          Container(
                            color: WhiteColor.withOpacity(0.2),
                            height: 1.0,
                            margin: EdgeInsets.all(16.0),
                          )
                        ],
                      ),
                    ),
                    Padding(
                        padding: const EdgeInsets.only(top: 130.0, bottom: 70.0),
                        child: NoScrollGlow(
                          child: SingleChildScrollView(
                            controller: model.scrollController,
                            child: PagedListView<int, CommentModel>(
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              pagingController: model.pagingController,
                              builderDelegate: PagedChildBuilderDelegate<CommentModel>(
                                itemBuilder: (context, item, index) => GestureDetector(
                                  onTap: () => model.onCommentSelected(index),
                                  child: Container(
                                    color: model.commentBackground(index),
                                    child: CommentsViewText(
                                      onNavigationProfilePage: () => model.onUsernameTap(model.pagingController.itemList[index].user),
                                      comment: model.pagingController.itemList[index],
                                      commentReplies: model.pagingController.itemList[index].replies,
                                    ),
                                  ),
                                ),
                                firstPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                                newPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                                noItemsFoundIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                              ),
                            ),
                          ),
                        )
                        /*NoScrollGlow(
                        child: SingleChildScrollView(
                          controller: model.scrollController,
                          child: Column(
                            children: [
                              for (int index = 0; index < model.comments.length; index++)
                                GestureDetector(
                                  onTap: () => model.onCommentSelected(index),
                                  child: Container(
                                    color: model.commentBackground(index),
                                    child: CommentsViewText(
                                      onNavigationProfilePage: () => model.onUsernameTap(model.comments[index].user),
                                      comment: model.comments[index],
                                      commentReplies: model.comments[index].replies,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),*/
                        ),
                    Padding(
                      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Visibility(
                              visible: model.isActionsViewVisible,
                              child: Container(
                                color: PrimaryDarkColor,
                                margin: EdgeInsets.only(top: 24.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    IconButton(
                                      icon: Icon(Icons.close_rounded, color: WhiteColor),
                                      onPressed: model.onCancelCommentSelection,
                                    ),
                                    IconButton(
                                      icon: Icon(Icons.delete_outline_rounded, color: WhiteColor),
                                      onPressed: model.onDeleteSelectedComment,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            ChangedTextFormField(
                              controller: model.commentController,
                              focusNode: model.commentNode,
                              // labelText: "Comment",
                              hintText: "Comment...",
                              textInputType: TextInputType.text,
                              // onFieldSubmitted: (term) { // send by action btn press
                              //   print("====$term");
                              //   model.commentController.text = "";
                              // },
                              backgroundColor: PrimaryDarkColor,
                              containerHeight: 70.0,
                              horizontalPadding: 16.0,
                              verticalPadding: 0,
                              suffixIcon: IconButton(
                                icon: Icon(
                                  Icons.send_rounded,
                                  color: model.isSendActive ? WhiteColor : TextFromFieldHintColor,
                                ),
                                onPressed: model.isSendActive ? model.onCommentSend : null,
                              ),
                              onChanged: model.onCommentValueChanged,
                            ),
                          ],
                        ),
                      ),
                    ),
                    model.isloading ? Loading() : Container()
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
