import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';

class SearchWidget extends StatelessWidget {
  final String hintText;
  final ValueChanged<String> onChangedSuffix;
  final Function onTap;
  final Function onEditingComplete;
  final TextEditingController controller;
  final bool autofocus;

   SearchWidget({Key key, this.hintText, this.onChangedSuffix, this.controller, this.onTap, this.autofocus=false, this.onEditingComplete}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      onEditingComplete: onEditingComplete,
      autofocus: autofocus,
      onChanged: (v) => onChangedSuffix(v),
      style: Regular.copyWith(color: WhiteColor),
      cursorColor: WhiteColor,
      controller: controller,
      decoration: InputDecoration(
        prefixIcon: Icon(Icons.search, color: SearchTextColor),
        suffixIcon: GestureDetector(
          onTap: onTap,
          child: Container(
            color: Colors.transparent,
            padding: EdgeInsets.all(12),
            child: Container(
              decoration: BoxDecoration(color: Color(0xff808185), shape: BoxShape.circle),
              child: Icon(Icons.close, color: PrimaryDarkColor, size: 12),
            ),
          ),
        ),
        contentPadding: EdgeInsets.symmetric(horizontal: 12),
        filled: true,
        fillColor: SearchBackgroundColor,
        hintStyle: Regular.copyWith(color: SearchTextColor),
        hintText: hintText,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
          borderSide: BorderSide(color: Colors.transparent, width: 0.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
          borderSide: BorderSide(color: Colors.transparent, width: 0.0),
        ),
        disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
          borderSide: BorderSide(color: Colors.transparent, width: 0.0),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
          borderSide: BorderSide(color: Colors.transparent, width: 0.0),
        ),
      ),
      keyboardType: TextInputType.text,
    );
  }
}
