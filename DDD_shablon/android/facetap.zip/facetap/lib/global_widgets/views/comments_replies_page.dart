import 'package:facetap/global_widgets/view_model/comments_replies_page_view_model.dart';
import 'package:facetap/models/comments_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CommentsRepliesViewText extends StatelessWidget {
  final CommentModel comment;
  final Function onNavigationProfilePage;
  final Function onLikeChanged;
  final Function userImage;

  const CommentsRepliesViewText({
    Key key,
    this.comment,
    this.onNavigationProfilePage,
    this.onLikeChanged,
    this.userImage,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<CommentsRepliesViewModel>.reactive(
      viewModelBuilder: () => CommentsRepliesViewModel(),
      builder: (context, model, _) {
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            GestureDetector(
              child: Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: userImage(comment.user),
              ),
              onTap: onNavigationProfilePage,
            ),
            SizedBox(width: 12.0),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                    child: Text("@${comment.user.username}", style: Medium.copyWith(fontSize: 16.0, color: WhiteColor)),
                    onTap: onNavigationProfilePage,
                  ),
                  SizedBox(height: 6.0),
                  Text(
                    comment.content,
                    style: Regular.copyWith(fontSize: 14.0, color: WhiteColor, height: 1.2),
                  ),
                  SizedBox(height: 8.0),
                ],
              ),
            ),
            Container(
              child: GestureDetector(
                child: Container(
                  color: Transparent,
                  padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
                  child: Column(
                    children: [
                      Container(
                        width: 16.0,
                        height: 16.0,
                        child: SvgPicture.asset(
                          comment.isLiked ? "assets/svg/like_icon.svg" : "assets/svg/unlike_icon.svg",
                          width: 16.0,
                          height: 16.0,
                        ),
                      ),
                      SizedBox(height: 8.0),
                      Text(
                        '${comment.likeCount}',
                        style: Medium.copyWith(fontSize: 14.0, color: WhiteColor),
                      ),
                    ],
                  ),
                ),
                onTap: () => onLikeChanged(comment),
              ),
            ),
          ],
        );
      },
    );
  }
}
