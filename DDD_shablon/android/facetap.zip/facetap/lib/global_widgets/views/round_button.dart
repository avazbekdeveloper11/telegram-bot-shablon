import 'dart:ui';

import 'package:facetap/global_widgets/view_model/round_button_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';

class RoundButton extends StatelessWidget {
  final Widget child;
  final String title;
  final Color color;
  final Function onClick;

  const RoundButton({
    Key key,
    this.child,
    this.title,
    this.color = RoundButtonColor,
    this.onClick,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<RoundButtonViewModel>.reactive(
      viewModelBuilder: () => RoundButtonViewModel(),
      builder: (context, model, _) {
        return Container(
          height: 90.0,
          width: 90.0,
          child: InkWell(
            onTap: onClick,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CircleAvatar(radius: 24, backgroundColor: color, child: child),
                Padding(
                  padding: EdgeInsets.only(top: 8.0),
                  child: Text(
                    title,
                    overflow: TextOverflow.ellipsis,
                    style: Regular.copyWith(color: WhiteColor),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
