import 'package:facetap/global_widgets/view_model/changed_text_form_field_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ChangedTextFormField extends StatelessWidget {
  final String hintText;
  final TextInputType textInputType;
  final String labelText;
  final TextEditingController controller;
  final bool labelBehavior;
  final bool obscureText;
  final IconButton suffixIcon;
  final List<TextInputFormatter> inputFormatters;
  final FormFieldValidator<String> validator;
  final ValueChanged<String> onFieldSubmitted;
  final FocusNode focusNode;
  final Color backgroundColor;
  final double containerHeight;
  final double horizontalPadding;
  final double verticalPadding;
  final ValueChanged<String> onChanged;

  const ChangedTextFormField({
    Key key,
    this.hintText,
    this.textInputType,
    this.labelText,
    this.controller,
    this.labelBehavior = false,
    this.obscureText = false,
    this.inputFormatters,
    this.suffixIcon,
    this.validator,
    this.onFieldSubmitted,
    this.focusNode,
    this.backgroundColor,
    this.containerHeight,
    this.horizontalPadding = 16.0,
    this.verticalPadding = 8.0,
    this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ChangedTextFormFieldViewModel>.reactive(
      viewModelBuilder: () => ChangedTextFormFieldViewModel(),
      builder: (context, model, _) {
        return Container(
          color: backgroundColor,
          height: containerHeight,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: horizontalPadding, vertical: verticalPadding),
            child: TextFormField(
              inputFormatters: inputFormatters,
              obscureText: obscureText,
              keyboardType: textInputType,
              controller: controller,
              cursorColor: WhiteColor,
              validator: validator,
              onChanged: onChanged,
              focusNode: focusNode,
              onFieldSubmitted: onFieldSubmitted,
              style: Medium.copyWith(fontSize: 16.0, color: WhiteColor),
              decoration: getTextFormFieldDecoration(),
            ),
          ),
        );
      },
    );
  }

  InputDecoration getTextFormFieldDecoration() {
    return InputDecoration(
      suffixIcon: suffixIcon,
      labelStyle: Medium.copyWith(fontSize: 16.0, color: TextFromFieldHintColor),
      labelText: labelText,
      hintText: hintText,
      alignLabelWithHint: true,
      floatingLabelBehavior: labelBehavior ? FloatingLabelBehavior.always : FloatingLabelBehavior.auto,
      hintStyle: Medium.copyWith(fontSize: 16.0, color: TextFromFieldHintColor),
      disabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: TextFromFieldHintColor)),
      enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: TextFromFieldHintColor)),
      focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: TextFromFieldHintColor)),
      border: UnderlineInputBorder(borderSide: BorderSide(color: TextFromFieldHintColor)),
    );
  }
}
