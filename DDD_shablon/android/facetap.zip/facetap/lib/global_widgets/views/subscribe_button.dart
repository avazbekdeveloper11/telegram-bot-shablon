import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';

class SubscribeButton extends StatelessWidget {
  final Function onTap;
  final String text;
  final Color buttonColor;
  final bool isColorText;
  final double fontSize;
  final bool isBorderColored;

  const SubscribeButton({
    Key key,
    @required this.onTap,
    this.text,
    this.buttonColor = Transparent,
    this.isColorText = true,
    this.isBorderColored = false,
    this.fontSize = 12.0,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: isBorderColored ? buttonColor : GrayColor, width: 2.0),
          borderRadius: BorderRadius.circular(6.0),
          color: buttonColor,
        ),
        child: Center(child: Text(text, style: Medium.copyWith(color: isColorText ? WhiteColor : BlackColor, fontSize: fontSize))),
        padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0),
      ),
      onTap: onTap,
    );
  }
}
