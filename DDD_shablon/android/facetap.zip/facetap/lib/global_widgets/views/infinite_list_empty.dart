import 'package:facetap/global_widgets/view_model/infinite_list_empty_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class InfiniteListEmptyItem extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<InfiniteListEmptyViewModel>.reactive(
      viewModelBuilder: () => InfiniteListEmptyViewModel(),
      builder: (context, model, _) {
        return Container(
          padding: EdgeInsets.all(32.0),
          alignment: Alignment.topCenter,
          child: Column(
            children: [
              // Padding(
              //   padding: const EdgeInsets.all(8.0),
              //   child: Icon(Icons.close, color: WhiteColor),
              // ),
              // Text('No items found.', style: Medium.copyWith(color: WhiteColor, fontSize: 16.0)),
              Container(),
            ],
          ),
        );
      },
    );
  }
}
