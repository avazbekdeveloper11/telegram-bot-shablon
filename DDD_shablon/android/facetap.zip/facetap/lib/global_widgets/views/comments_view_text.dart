import 'package:facetap/global_widgets/view_model/comments_view_text_view_model.dart';
import 'package:facetap/global_widgets/views/comments_replies_page.dart';
import 'package:facetap/models/comments_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CommentsViewText extends StatelessWidget {
  final Function onNavigationProfilePage;
  final CommentModel comment;
  final List<CommentModel> commentReplies;

  const CommentsViewText({Key key, this.onNavigationProfilePage, this.comment, this.commentReplies}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<CommentsViewTextViewModel>.reactive(
      initState: (model) => model.initData(commentReplies),
      viewModelBuilder: () => CommentsViewTextViewModel(),
      builder: (context, model, _) {
        return Padding(
          padding: const EdgeInsets.only(left: 20, right: 20.0, bottom: 8.0, top: 16.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                child: Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: model.userImage(comment.user),
                ),
                onTap: onNavigationProfilePage,
              ),
              SizedBox(width: 12.0),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              GestureDetector(
                                child: Text('@${comment.user.username}', style: Medium.copyWith(fontSize: 16.0, color: WhiteColor)),
                                onTap: onNavigationProfilePage,
                              ),
                              SizedBox(height: 6.0),
                              Text(
                                comment.content,
                                style: Regular.copyWith(fontSize: 14.0, color: WhiteColor, height: 1.2),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          child: GestureDetector(
                            child: Container(
                              color: Transparent,
                              padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
                              child: Column(
                                children: [
                                  Container(
                                    width: 16.0,
                                    height: 16.0,
                                    child: SvgPicture.asset(
                                      comment.isLiked ? 'assets/svg/like_icon.svg' : 'assets/svg/unlike_icon.svg',
                                      width: 16.0,
                                      height: 16.0,
                                    ),
                                  ),
                                  SizedBox(height: 8.0),
                                  Text(
                                    '${comment.likeCount}',
                                    style: Medium.copyWith(fontSize: 14.0, color: WhiteColor),
                                  ),
                                ],
                              ),
                            ),
                            onTap: () => model.onLikeChanged(comment),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8.0),
                    comment.replyCount > 0
                        ? Column(
                            children: [
                              GestureDetector(
                                child: Container(
                                  color: Transparent,
                                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                                  child: Row(
                                    children: [
                                      Text(
                                        comment.replyCount == 1 ? 'View ${comment.replyCount} reply' : 'View ${comment.replyCount} replies',
                                        style: Regular.copyWith(fontSize: 14.0, color: WhiteColor.withOpacity(0.4)),
                                      ),
                                      SizedBox(width: 4.0),
                                      !model.isOpenReplies
                                          ? SvgPicture.asset('assets/svg/open_comment_replies_icon.svg')
                                          : RotationTransition(
                                              turns: new AlwaysStoppedAnimation(180 / 360),
                                              child: SvgPicture.asset('assets/svg/open_comment_replies_icon.svg'),
                                            ),
                                    ],
                                  ),
                                ),
                                onTap: () => model.openRepliesComments(comment),
                              ),
                              SizedBox(height: 12.0),
                              model.isOpenReplies
                                  ? Column(
                                      children: [
                                        for (int index = 0; index < model.commentReplies.length; index++)
                                          GestureDetector(
                                            // onTap: () => model.onCommentSelected(index),
                                            child: Container(
                                              // color: model.commentBackground(index),
                                              child: CommentsRepliesViewText(
                                                comment: model.commentReplies[index],
                                                onNavigationProfilePage: onNavigationProfilePage,
                                                onLikeChanged: model.onLikeChanged,
                                                userImage: model.userImage,
                                              ),
                                            ),
                                          ),
                                      ],
                                    )
                                  : Container()
                            ],
                          )
                        : Container()
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/*
                    SizedBox(height: 8.0),
                    GestureDetector(
                      child: Container(
                        color: Transparent,
                        padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
                        child: Row(
                          children: [
                            Text('View $numberOfReplies replies',
                                style: Regular.copyWith(
                                    fontSize: 14.0, color: WhiteColor.withOpacity(0.4))),
                            SizedBox(width: 4.0),
                            !model.isOpenReplies
                                ? SvgPicture.asset(
                                    'assets/svg/open_comment_replies_icon.svg',
                                  )
                                : RotationTransition(
                                    turns: new AlwaysStoppedAnimation(180 / 360),
                                    child: SvgPicture.asset('assets/svg/open_comment_replies_icon.svg'),
                                  ),
                          ],
                        ),
                      ),
                      onTap: () => model.openRepliesComments(),
                    ),
                    SizedBox(height: 12.0),
                    model.isOpenReplies
                        ? CommentsRepliesViewText(
                            onNavigationProfilePage: onNavigationProfilePage,
                            numberReplies: numberOfReplies,
                            name: name,
                            isLikeComments: isLikeComments,
                            imageName: profileImageUrl,
                            likeNumber: numberOfLikes,
                            comments: comments,
                          )
                        : Container()
*/
