import 'package:facetap/utils/colors.dart';
import 'package:flutter/material.dart';

class MenuButton extends StatelessWidget {
  final Function onTap;
  final Widget icon;
  final bool isFilled;
  final double radius;

  const MenuButton({
    Key key,
    @required this.onTap,
    this.icon,
    this.isFilled = false,
    this.radius = 6.0,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: GrayColor, width: 2.0),
            borderRadius: BorderRadius.circular(radius),
            color: isFilled ? GrayColor : Transparent,
          ),
          child: icon),
      onTap: onTap,
    );
  }
}
