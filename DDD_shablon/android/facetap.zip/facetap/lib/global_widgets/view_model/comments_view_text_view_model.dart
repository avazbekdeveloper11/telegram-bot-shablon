import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/comments_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class CommentsViewTextViewModel extends BaseViewModel {
  final PostsService _postsService = locator<PostsService>();
  bool isOpenReplies = false;
  List<CommentModel> commentReplies = [];

  initData(List<CommentModel> commentReplies) {
    this.commentReplies = commentReplies;
  }

  onLikeChanged(CommentModel comment) {
    print("1");
    comment.isLiked = !comment.isLiked;
    notifyListeners();
    if (comment.isLiked) {
      comment.likeCount += 1;

      onCommentLiked(comment.id, comment.user.id);
    } else {
      comment.likeCount -= 1;
      onCommentDisliked(comment.id, comment.user.id);
    }
  }

  openRepliesComments(CommentModel comment) {
    isOpenReplies = !isOpenReplies;
    if (isOpenReplies)
      fetchComments(comment);
    else
      notifyListeners();
  }

  fetchComments(CommentModel comment) async {
    setState(LoadingState.loading);
    commentReplies.clear();
    CommentsListModel _response = await _postsService
        .getComments(objectType: 'comment', objectId: comment.id, page: 1, limit: 20)
        .onError((error, stackTrace) => onError(error));
    if (_response != null) {
      commentReplies.addAll(_response.comments);
      notifyListeners();
    }
    setState(LoadingState.idle);
  }

  userImage(UserModel profile) => CircleAvatar(
        radius: 18.0,
        backgroundColor: TextFromFieldHintColor,
        child: profile.profilePhoto.isNotEmpty
            ? ClipRRect(
                borderRadius: BorderRadius.circular(32.0),
                child: CachedNetworkImage(
                  imageUrl: profile.profilePhoto,
                  fit: BoxFit.cover,
                  height: 40.0,
                  width: 40.0,
                  placeholder: (context, url) => Container(color: TextFromFieldHintColor),
                ),
              )
            : SvgPicture.asset(Assets.svgAvatarPlaceholder),
      );

  onCommentLiked(String id, String ownerId) async {
    Map<String, dynamic> data = serializer.prepareDataToLike(id: id, objectType: 'comment', type: 'like', ownerId: ownerId);
    bool _response = await _postsService.like(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      print('===== liked: id $id');
    }
  }

  onCommentDisliked(String id,  String ownerId) async {
    Map<String, dynamic> data = serializer.prepareDataToLike(id: id, objectType: 'comment', type: 'dislike', ownerId: ownerId);
    bool _response = await _postsService.dislike(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      print('===== disliked: id $id');
    }
  }
}
