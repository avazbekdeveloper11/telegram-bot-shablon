import 'package:facetap/models/comments_model.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/profile_page/views/profile_page.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class CommentsViewModel extends BaseViewModel {
  final PostsService _postsService = locator<PostsService>();
  final UserModel _userModel = locator<UserModel>();
  ScrollController scrollController;
  FocusNode commentNode;
  PostModel post;
  TextEditingController commentController;
  bool isSendActive = false;
  bool isActionsViewVisible = false;
  CommentModel selectedComment;
  PagingController pagingController = PagingController<int, CommentModel>(firstPageKey: 1);

  initData(PostModel post) {
    this.post = post;
    scrollController = ScrollController();
    commentController = TextEditingController();
    pagingController.addPageRequestListener((pageKey) {
      fetchComments(pageKey);
    });
    commentNode = FocusNode();
    super.initState();
  }

  @override
  onDispose() {
    scrollController.dispose();
    commentController.dispose();
    commentNode.dispose();
    pagingController.dispose();
    super.onDispose();
  }

  onUsernameTap(UserModel user) {
    navigationService.push(MaterialPageRoute(builder: (_) => ProfilePage(userId: user.id, isNavigatorPop: true)));
  }

  fetchComments(int pageKey) async {
    if (pageKey == 1) pagingController?.itemList?.clear();
    try {
      final _response = await _postsService
          .getComments(objectType: 'post', objectId: post.id, page: pageKey, limit: 20)
          .onError((error, stackTrace) => onError(error));
      final isLastPage = (pagingController.itemList ?? []).length == _response.count || (_response.comments ?? []).isEmpty;
      isLastPage ? pagingController.appendLastPage(_response.comments ?? []) : pagingController.appendPage(_response.comments ?? [], pageKey + 1);
    } catch (error) {
      pagingController.error = error;
    }
  }

  void onCommentSend() async {
    String objectType = selectedComment == null ? 'post' : 'comment';
    String commentId = selectedComment == null ? "" : selectedComment.id;
    int repliedIndex = -1;
    if (selectedComment == null) {
      List<CommentModel> emptyList = [];
      if (pagingController.itemList == null) pagingController.itemList = emptyList;
      pagingController.itemList.insert(0, CommentModel(content: commentController.text, user: _userModel, replies: []));
    } else {
      repliedIndex = pagingController.itemList.indexOf(selectedComment);
      pagingController.itemList[repliedIndex].replies.insert(0, CommentModel(content: commentController.text, user: _userModel));
    }
    Map<String, dynamic> data = serializer.prepareDataToComment(
        content: commentController.text,
        postId: post.id,
        objectType: objectType,
        postOwnerId: post.user.id,
        commentId: commentId,
        commentOwnerId: selectedComment == null ? "" : selectedComment.user.id);
    commentController.text = "";
    onCancelCommentSelection();
    CommentModel _response = await _postsService.createComment(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      print("===== comment added: ${_response.id}");
      if (objectType == 'comment' && repliedIndex > -1) {
        pagingController.itemList[repliedIndex].replies.bottom = _response;
        pagingController.itemList[repliedIndex].replyCount += 1;
      }
    }
    int count = pagingController.itemList.length;
    for (var comment in pagingController.itemList) {
      count += comment.replyCount;
    }
    post.commentCount = count;
    notifyListeners();
  }

  void onCommentValueChanged(String value) {
    isSendActive = value.isEmpty ? false : true;
    notifyListeners();
  }

  onCommentSelected(int index) {
    if (selectedComment != null && selectedComment == pagingController.itemList[index]) {
      selectedComment = null;
      isActionsViewVisible = false;
    } else {
      selectedComment = pagingController.itemList[index];
      if (post.user.id == _userModel.id) {
        // my post, can delete any comment
        isActionsViewVisible = true;
      } else {
        if (pagingController.itemList[index].user.id == _userModel.id) {
          // not my post, but my comment
          isActionsViewVisible = true;
        } else {
          // not my post, not my comment
          // do only reply to comment
          isActionsViewVisible = false;
        }
      }
      commentNode.requestFocus();
    }
    notifyListeners();
  }

  Color commentBackground(int index) {
    if (selectedComment != null && selectedComment.id == pagingController.itemList[index].id) return PrimaryLightColor;
    return Transparent;
  }

  onCancelCommentSelection() {
    selectedComment = null;
    isActionsViewVisible = false;
    notifyListeners();
  }

  onDeleteSelectedComment() async {
    var id = selectedComment.id;
    pagingController.itemList.remove(selectedComment);
    Map<String, dynamic> data =
        serializer.prepareDataToDeleteComment(id: selectedComment.id, objectId: selectedComment.objectId, postId: post.id, objectType: "comment");
    onCancelCommentSelection();
    bool _response = await _postsService.deleteComment(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print("===== comment removed: $id");
  }

  onCloseComments() => navigationService.pop();
}
