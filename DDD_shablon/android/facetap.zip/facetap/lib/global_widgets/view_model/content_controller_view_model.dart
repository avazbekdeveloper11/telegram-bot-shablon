import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:downloads_path_provider_28/downloads_path_provider_28.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/views/round_button.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/reports_model.dart';
import 'package:facetap/models/scheme_model.dart';
import 'package:facetap/models/share_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/home_page/views/home_screen.dart';
import 'package:facetap/pages/profile_page/views/profile_page.dart';
import 'package:facetap/pages/settings_page/local_widget/views/settings_templates.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/validators.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_appavailability/flutter_appavailability.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_svg/svg.dart';
import 'package:open_file/open_file.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:share_options/share_options.dart';
import 'package:uuid/uuid.dart';

class ContentControllerViewModel extends BaseViewModel {
  final PostsService _postsService = locator<PostsService>();
  final UserService _userService = locator<UserService>();
  final UserModel userModel = locator<UserModel>();
  List<String> usersIHaveSubscribed = [];
  List<ShareOption> shareOptions = [];
  List<SchemeModel> shareOptionsIOS = [];
  Function updateNeeded;
  List<ReportTypeModel> reportTypes = [];

  initData(List<String> usersIHaveSubscribed, Function updateNeeded) {
    flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    final android = AndroidInitializationSettings('@mipmap/ic_launcher');
    final iOS = IOSInitializationSettings();
    final initSettings = InitializationSettings(android: android, iOS: iOS);

    flutterLocalNotificationsPlugin.initialize(initSettings, onSelectNotification: _onSelectNotification);
    this.usersIHaveSubscribed = usersIHaveSubscribed;
    this.updateNeeded = updateNeeded;
    if (shareOptionsIOS.length <= 1) {
      shareOptionsIOS.clear();
      shareOptionsIOS.add(null);
      schemas.forEach((element) async {
        try {
          var availability = await AppAvailability.checkAvailability(element.scheme);
          // print('===== scheme $element: ${availability['package_name']}');
          shareOptionsIOS.add(element);
        } catch (e) {
          print((e as PlatformException).message);
        }
      });
    }
    super.initState();
  }

  onNavigationProfilePage(String id) {
    navigationService.push(MaterialPageRoute(builder: (_) => ProfilePage(userId: id, isNavigatorPop: true)));
  }

  sharePost(PostModel post) async {
    setState(LoadingState.loading);
    if (post.share == null) {
      ShareModel _response = await _userService.getPostLink(postId: post.id).onError((error, stackTrace) => onError(error));
      if (_response != null) {
        post.share = _response.url;
        notifyListeners();
      }
    }
    if (Platform.isAndroid) {
      if (shareOptions.length <= 1) {
        shareOptions.clear();
        shareOptions.add(null);
        final options = await ShareOptions.getTextShareOptions('Check out facetap post ${post.share}', subject: 'Facetap Post');
        options.forEach((element) {
          if (checkSocialOccurrences(element.activityInfo.packageName) || checkSocialOccurrences(element.activityInfo.className))
            shareOptions.add(element);
        });
      }
    } else {
      if (shareOptionsIOS.length <= 1) {
        shareOptionsIOS.clear();
        shareOptionsIOS.add(null);
        schemas.forEach((element) async {
          try {
            var availability = await AppAvailability.checkAvailability(element.scheme);
            print('===== scheme $element: ${availability['package_name']}');
            shareOptionsIOS.add(element);
          } catch (e) {
            print((e as PlatformException).message);
          }
        });
      }
    }
    setState(LoadingState.idle);
    showContentBottomSheet(post);
  }

  showContentBottomSheet(PostModel post) => showModalBottomSheet(
        backgroundColor: BottomSheetColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(12.0), topRight: Radius.circular(12.0))),
        context: navigationService.currentContext,
        builder: (BuildContext bc) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16, right: 16, top: 12, bottom: 12),
                child: Text('Share on', style: Regular.copyWith(color: WhiteColor, fontSize: 16)),
              ),
              Platform.isIOS
                  ? Container(
                      color: Color(0xff1d1d1d),
                      padding: EdgeInsets.symmetric(vertical: 16.0),
                      child: SizedBox(
                        height: 90.0,
                        child: ListView.builder(
                          itemCount: shareOptionsIOS.length,
                          itemBuilder: (_, index) {
                            var shareOption = shareOptionsIOS[index];
                            return Container(
                              width: 90.0,
                              child: shareOption == null
                                  ? InkWell(
                                      onTap: () => Clipboard.setData(new ClipboardData(text: post.share)).then((_) {
                                        onBackPressed();
                                        showSnackBar('Link copied to clipboard');
                                      }),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          CircleAvatar(
                                            radius: 24.0,
                                            backgroundColor: RoundButtonColor,
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(24.0),
                                              child: Padding(
                                                padding: const EdgeInsets.all(10.0),
                                                child: SvgPicture.asset(Assets.svgCopy, width: 48.0, height: 48.0),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              'Copy link',
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : InkWell(
                                      onTap: () => shareIos(shareOption, post.share), //=> shareOption.share(),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          ClipRRect(
                                            borderRadius: BorderRadius.circular(24.0),
                                            child: SvgPicture.asset(shareOption.iconAssets, width: 48, height: 48),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              shareOption.name,
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                            );
                          },
                          scrollDirection: Axis.horizontal,
                          shrinkWrap: false,
                          physics: BouncingScrollPhysics(),
                        ),
                      ),
                    )
                  : Container(
                      color: Color(0xff1d1d1d),
                      padding: EdgeInsets.symmetric(vertical: 16.0),
                      child: SizedBox(
                        height: 90.0,
                        child: ListView.builder(
                          itemCount: shareOptions.length,
                          itemBuilder: (_, index) {
                            var shareOption = shareOptions[index];
                            return Container(
                              width: 90.0,
                              child: shareOption == null
                                  ? InkWell(
                                      onTap: () => Clipboard.setData(new ClipboardData(text: post.share)).then((_) {
                                        onBackPressed();
                                        showSnackBar('Link copied to clipboard');
                                      }),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          CircleAvatar(
                                            radius: 24.0,
                                            backgroundColor: RoundButtonColor,
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(24.0),
                                              child: Padding(
                                                padding: const EdgeInsets.all(10.0),
                                                child: SvgPicture.asset(Assets.svgCopy, width: 48.0, height: 48.0),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              'Copy link',
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : InkWell(
                                      onTap: () => shareOption.share(),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          ClipRRect(
                                            borderRadius: BorderRadius.circular(24.0),
                                            child: Image.memory(shareOption.icon, width: 48.0, height: 48.0),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              shareOption.name,
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                            );
                          },
                          scrollDirection: Axis.horizontal,
                          shrinkWrap: false,
                          physics: BouncingScrollPhysics(),
                        ),
                      ),
                    ),
              Container(
                padding: EdgeInsets.only(bottom: 32),
                color: Color(0xff1d1d1d),
                alignment: Alignment.centerLeft,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      RoundButton(child: SvgPicture.asset(Assets.svgFlag), title: 'Report', onClick: () => fetchReportTypes(post)),
                      RoundButton(child: SvgPicture.asset(Assets.svgHeartBroken), title: 'Not interested'),
                      RoundButton(
                        child: SvgPicture.asset(Assets.svgDownload),
                        title: 'Download',
                        onClick: () => _download(post.medias.first.mediaUrl, post.medias.first.mediaId, post.medias.first.contentType),
                      ),
                      RoundButton(
                        child: SvgPicture.asset(Assets.svgBookmark),
                        title: post.saved ? 'Remove from favorites' : 'Add to favorites',
                        onClick: () => savePost(post),
                      ),
                      Visibility(
                        visible: userModel.id == post.user.id,
                        child: RoundButton(
                          child: SvgPicture.asset(Assets.svgBlocked),
                          title: 'Delete',
                          onClick: () => deletePost(post),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          );
        },
      );

  onBackPressed() => navigationService.pop();

  deletePost(PostModel post) async {
    onBackPressed();
    showDialog(
      context: navigationService.currentContext,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Color(0xff1e1e1e),
          title: Text('Delete this post?', style: Regular.copyWith(color: WhiteColor)),
          content: Text("This post will be removed from Facetap and won't be visible to others.", style: Regular.copyWith(color: WhiteColor)),
          actions: [
            TextButton(child: Text('Cancel', style: Regular.copyWith(color: WhiteColor)), onPressed: () => onBackPressed()),
            TextButton(child: Text('Confirm', style: Regular.copyWith(color: AccentColor)), onPressed: () => _delete(post))
          ],
        );
      },
    );
  }

  _delete(PostModel post) async {
    onBackPressed();
    updateNeeded();
    Map<String, dynamic> data = serializer.prepareDataToDeletePost(postId: post.id);
    bool _response = await _postsService.deletePost(data: data).onError((error, stackTrace) => onError(error));
    navigationService.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => HomePage(defaultIndex: 4)));
    if (_response != null) print('post deleted');
  }

  savePost(PostModel post) async {
    onBackPressed();
    updateNeeded();
    post.saved ? _unsave(post) : _save(post);
  }

  _unsave(PostModel post) async {
    // showSnackbar('Removed from favorites');
    Map<String, dynamic> data = serializer.prepareDataToSavePost(postId: post.id);
    bool _response = await _postsService.removeSavedPost(data).onError((error, stackTrace) => onError(error));
    if (_response != null) print('post unsaved');
  }

  _save(PostModel post) async {
    // showSnackbar('Saved to favorites');
    Map<String, dynamic> data = serializer.prepareDataToSavePost(postId: post.id);
    bool _response = await _postsService.savePost(data).onError((error, stackTrace) => onError(error));
    if (_response != null) print('post saved');
  }

  fetchReportTypes(PostModel post) async {
    if ((reportTypes ?? []).isEmpty) {
      setState(LoadingState.loading);
      ReportTypesModel _response = await _userService.reportUserTypes(page: 1, limit: 20).onError((error, stackTrace) => onError(error));
      setState(LoadingState.idle);
      if (_response != null) reportTypes.addAll(_response.results);
    }
    onBackPressed();
    showReportBottomSheet(post);
  }

  reportUser(int reportId, String postId) async {
    onBackPressed();
    showSnackBar('Report sent');
    Map<String, dynamic> data = serializer.prepareDataToReportPost(reportId: reportId, postId: postId);
    bool _response = await _postsService.reportPost(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print('post reported $postId');
  }

  showReportBottomSheet(PostModel post) => showModalBottomSheet(
        backgroundColor: BottomSheetColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(12.0), topRight: Radius.circular(12.0))),
        context: navigationService.currentContext,
        builder: (BuildContext bc) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16, right: 16, top: 12, bottom: 12),
                child: Text('Report', style: Regular.copyWith(color: WhiteColor, fontSize: 16)),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16, right: 16, bottom: 12),
                child: Text('Why are you reporting this profile?', style: Regular.copyWith(color: TextFromFieldHintColor, fontSize: 14)),
              ),
              Container(
                padding: EdgeInsets.only(left: 16, right: 16, bottom: 32),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      for (var item in reportTypes) SettingsTemplates(name: item.message, onNavigationTap: () => reportUser(item.id, post.id)),
                    ],
                  ),
                ),
              )
            ],
          );
        },
      );

  shareIos(SchemeModel shareOption, String url) {
    var launch = '';
    switch (shareOption.scheme) {
      case 'fb://': //fb://post/%s  https://gist.github.com/nhnam/5f106eaebff6366c0e21578c40515094
        launch = 'post/$url';
        break;
      case 'twitter://': //twitter://post?message=[Tweet Text]  https://github.com/yeswasi/URLScheme/wiki/Twitter
        launch = 'post?message=$url';
        break;
      case 'vk://': // not support https://github.com/VKCOM/vk-ios-sdk/issues/545#issuecomment-554340462
        launch = '';
        break;
      case 'whatsapp://': // whatsapp://send?text=xxx
        launch = 'send?text=$url';
        break;
      case 'tg://': // tg://msg?text=Hello
        launch = 'msg?text=$url';
        break;
      case 'viber://': // viber://forward?text=foo
        launch = 'forward?text=$url';
        break;
      case 'wechat://': // no info
        launch = '';
        break;
      case 'line://': // no info
        launch = '';
        break;
      case 'instagram://': //  maybe
        launch = 'send/text=$url';
        break;
      case 'ha://': // no info
        launch = '';
        break;
      case 'linkedin://': //
        launch = '';
        break;
    }
    if (launch.isNotEmpty) AppAvailability.launchApp(shareOption.scheme + launch);
  }

  final Dio _dio = Dio();

  double progress = 0;

  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

  Future<void> _onSelectNotification(String json) async {
    final obj = jsonDecode(json);

    if (obj['isSuccess']) {
      OpenFile.open(obj['filePath']);
    } else {
      showDialog(
        context: navigationService.currentContext,
        builder: (_) => AlertDialog(
          title: Text('Error'),
          content: Text('${obj['error']}'),
        ),
      );
    }
  }

  Future<void> _showNotification(Map<String, dynamic> downloadStatus) async {
    final android =
        AndroidNotificationDetails('channel id', 'channel name', channelDescription: 'channel description', priority: Priority.high, importance: Importance.max);
    final iOS = IOSNotificationDetails();
    final platform = NotificationDetails(android: android, iOS: iOS);
    final json = jsonEncode(downloadStatus);
    final isSuccess = downloadStatus['isSuccess'];

    await flutterLocalNotificationsPlugin.show(
        0, // notification id
        isSuccess ? 'Success' : 'Failure',
        isSuccess ? 'File has been downloaded successfully!' : 'There was an error while downloading the file.',
        platform,
        payload: json);
  }

  Future<Directory> _getDownloadDirectory() async {
    if (Platform.isAndroid) {
      return await DownloadsPathProvider.downloadsDirectory;
    }

    // in this example we are using only Android and iOS so I can assume
    // that you are not trying it for other platforms and the if statement
    // for iOS is unnecessary

    // iOS directory visible to user
    return await getApplicationDocumentsDirectory();
  }

  void _onReceiveProgress(int received, int total) {
    if (total != -1) {
      progress = (received / total * 100);
      notifyListeners();
    }
  }

  Future<void> _startDownload(String savePath, String _fileUrl) async {
    Navigator.of(navigationService.currentContext).pop();
    Map<String, dynamic> result = {
      'isSuccess': false,
      'filePath': null,
      'error': null,
    };

    try {
      final response = await _dio.download(_fileUrl, savePath, onReceiveProgress: _onReceiveProgress);

      result['isSuccess'] = response.statusCode == 200;
      result['filePath'] = savePath;
    } catch (ex) {
      result['error'] = ex.toString();
    } finally {
      progress = 0;
      notifyListeners();
      await _showNotification(result);
    }
  }

  Future<void> _download(String urlImage, String id, String extension) async {
    final dir = await _getDownloadDirectory();
    // final isPermissionStatusGranted = await _requestPermissions();
    print(urlImage);
    print(extension);
    final savePath = path.join(dir.path, "${Uuid().v1()}${extension.replaceAll('/', '.')}");
    await _startDownload(savePath, urlImage);
  }
}
