import 'dart:ui';

import 'package:facetap/providers/base_class_provider.dart';
import 'package:facetap/utils/colors.dart';
import 'package:flutter/material.dart';

class BaseClass extends StatelessWidget {
  final Widget child;

  const BaseClass({Key key, @required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(color: PrimaryDarkColor.withOpacity(0.7), image: DecorationImage(image: getImagePath(context), fit: BoxFit.cover)),
        child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10), child: child));
  }
}
