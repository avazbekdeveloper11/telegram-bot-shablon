import 'package:facetap/utils/colors.dart';
import 'package:flutter/material.dart';

class Loading extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: PrimaryDarkColor.withOpacity(0.5),
      child: Scaffold(
        backgroundColor: PrimaryDarkColor.withOpacity(0.5),
        body: Container(
          color: PrimaryDarkColor.withOpacity(0.5),
          child: Center(
            child: CircularProgressIndicator(),
          ),
        ),
      ),
    );
  }
}
