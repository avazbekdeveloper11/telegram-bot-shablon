extension StringValidator on String {
  bool isImage() {
    return this.toLowerCase().endsWith('.jpeg') || this.toLowerCase().endsWith('.jpg') || this.toLowerCase().endsWith('.png');
  }
}
