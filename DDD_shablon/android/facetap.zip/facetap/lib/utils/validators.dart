import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/scheme_model.dart';

bool isEmailValidate(String email) => RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(email);

bool isPasswordValidate(String password) => RegExp(r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$").hasMatch(password);

bool isNumeric(String s) {
  if (s == null) return false;
  return double.parse(s) != null;
}

List<String> socialsToShare = [
  'facebook',
  'instagram',
  'gmail',
  'linkedin',
  'messag',
  'telegram',
  'email',
  'whatsup',
  'vk',
  'whatsapp',
  'twitter',
  'wechat',
  'snapchat',
  'viber',
];

List<SchemeModel> schemas = [
  SchemeModel('fb://', Assets.iconFacebook, 'Facebook'),
  SchemeModel('twitter://', Assets.iconTwitter, 'Twitter'),
  // SchemeModel('vk://', Assets.iconVk, 'VK'),
  SchemeModel('whatsapp://', Assets.iconWhatsapp, 'WhatsApp'),
  SchemeModel('tg://', Assets.iconTg, 'Telegram'),
  SchemeModel('viber://', Assets.iconViber, 'Viber'),
  // SchemeModel('wechat://', Assets.iconWechat, 'WeChat'),
  // SchemeModel('line://', Assets.iconLine, 'Line'),
  SchemeModel('instagram://', Assets.iconInstagram, 'Instagram'),
  // SchemeModel('ha://', Assets.iconSnapchat, 'Snapchat'),
  // SchemeModel('linkedin://', Assets.iconLinkedin, 'LinkedIn'),
];

bool checkSocialOccurrences(String text) {
  for (var element in socialsToShare) {
    // print('====== ttt : $text ${text.toLowerCase().contains(element)}');
    if (text.toLowerCase().contains(element)) return true;
  }
  return false;
}
