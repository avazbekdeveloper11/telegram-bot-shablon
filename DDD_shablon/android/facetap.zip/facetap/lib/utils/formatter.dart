import 'package:intl/intl.dart';

formatAmount(amount) => amount == null ? '0' : NumberFormat.compact().format(amount);
