import 'package:flutter/material.dart';

const Color PrimaryColor = Color(0xff030201);

const Color PrimaryLightColor = Color(0xff4B4854);

const Color PrimaryDarkColor = Color(0xff0A121F);

const Color AccentColor = Color(0xffFF5F0E);

const Color WhiteColor = Colors.white;

const Color GrayColor = Color(0xff404247);

const Color BlackColor = Colors.black;

const Color TextFromFieldHintColor = Color(0xff8B8B8B);

const Color NewPostBorderColor = Color(0x20FFFFFF);

const Color Transparent = Colors.transparent;

const Color SearchBackgroundColor = Color(0x14ffffff);

const Color SearchTextColor = Color(0x50FFFFFF);

const Color BottomSheetColor = Color(0xff202021);

const Color DarkWindowColor = Color(0xff0a0a0a);

const Color RoundButtonColor = Color(0xff232324);
