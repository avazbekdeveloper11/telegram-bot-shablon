import 'package:flutter/material.dart';

const TextStyle Regular = TextStyle(
  fontWeight: FontWeight.w400,
);

const TextStyle Medium = TextStyle(
  fontWeight: FontWeight.w500,
);

const TextStyle Bold = TextStyle(
  fontWeight: FontWeight.w700,
);
