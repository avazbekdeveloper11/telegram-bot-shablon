import 'dart:convert';

import 'package:facetap/apis/apis.dart';
import 'package:facetap/apis/errors.dart';
import 'package:facetap/models/error_model.dart';
import 'package:facetap/models/login_model.dart';
import 'package:facetap/models/register_model.dart';
import 'package:facetap/models/tokens_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/models/verification_code_model.dart';
import 'package:facetap/services/cache_service.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';

class AuthenticationService {
  final ApiClient _apiClient = locator<ApiClient>();
  final CacheService _cacheService = locator<CacheService>();
  final UserModel _userModel = locator<UserModel>();

  Future<T> _onApiCallback<T extends Object>(
      {@required Response response,
      Future<T> Function(ErrorModel) onError,
      @required Future<T> Function(Map<String, dynamic>) onSuccess,
      int successCode = 200}) async {
    print('\n=====\nresponse => ${response.statusCode} ${response.request}');
    print('${response.body}');
    print('=====\n\n');
    if (response.statusCode == successCode)
      return onSuccess != null ? onSuccess.call(jsonDecode(response.body)) : Future.error(ApiClientErrors.NO_SUCCESS_BODY_FOUND);

    return onError.call(ErrorModel.fromJson(jsonDecode(response.body)));
  }

  Future<RegisterModel> register({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.register(data);

      Future<RegisterModel> _onSuccess(Map<String, dynamic> body) async {
        RegisterModel model = RegisterModel.fromJson(body);
        return model;
      }

      Future<RegisterModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<RegisterModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<VerificationCodeModel> verifyByLink({@required Uri uri}) async {
    try {
      Response response = await _apiClient.verifyByLink(uri);

      Future<VerificationCodeModel> _onSuccess(Map<String, dynamic> body) async {
        VerificationCodeModel model = VerificationCodeModel.fromJson(body);
        _cacheService.saveAccessToken(model.accessToken);
        _cacheService.saveRefreshToken(model.refreshToken);
        _cacheService.saveId(model.id);
        _userModel.verifyFromJson(body);
        return model;
      }

      Future<VerificationCodeModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<VerificationCodeModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<TokensModel> getTokens({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.getTokens(data);

      Future<TokensModel> _onSuccess(Map<String, dynamic> body) async {
        TokensModel model = TokensModel.fromJson(body);
        _cacheService.saveAccessToken(model.accessToken);
        _cacheService.saveRefreshToken(model.refreshToken);
        _userModel.regFromJson(body);
        return model;
      }

      Future<TokensModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<TokensModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<LoginModel> login({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.login(data);

      Future<LoginModel> _onSuccess(Map<String, dynamic> body) async {
        LoginModel model = LoginModel.fromJson(body);
        _cacheService.saveAccessToken(model.accessToken);
        _cacheService.saveRefreshToken(model.refreshToken);
        _cacheService.saveId(model.id);
        _userModel.loginFromJson(body);
        return model;
      }

      Future<LoginModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<LoginModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> logout() async {
    try {
      Response response = await _apiClient.logout();

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<String> sendVerification({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.sendVerification(data);
print(response.body);
      if(response.statusCode==200){
        return response.body;
      }{
        return response.body;
      }

    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> setPassword({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.setPassword(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }
}
