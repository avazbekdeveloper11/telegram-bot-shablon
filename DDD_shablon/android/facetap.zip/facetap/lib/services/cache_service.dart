import 'package:shared_preferences/shared_preferences.dart';

class CacheService {
  void saveAccessToken(String accessToken) async {
    await SharedPreferences.getInstance().then((pref) async {
      await pref.setString('access_token', accessToken);
    });
  }

  void saveRefreshToken(String refreshToken) async {
    await SharedPreferences.getInstance().then((pref) async {
      await pref.setString('refresh_token', refreshToken);
    });
  }

  void saveId(String id) async {
    await SharedPreferences.getInstance().then((pref) async {
      await pref.setString('id', id);
    });
  }

  void saveProfileImage(String url) async {
    await SharedPreferences.getInstance().then((pref) async {
      await pref.setString('image', url);
    });
  }
}
