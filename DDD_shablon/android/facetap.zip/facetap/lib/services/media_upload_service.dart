import 'dart:convert';

import 'package:facetap/apis/apis.dart';
import 'package:facetap/apis/errors.dart';
import 'package:facetap/models/error_model.dart';
import 'package:facetap/models/upload_url_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';

class MediaUploadService {
  final ApiClient _apiClient = locator<ApiClient>();

  Future<T> _onApiCallback<T extends Object>(
      {@required Response response,
      Future<T> Function(ErrorModel) onError,
      @required Future<T> Function(Map<String, dynamic>) onSuccess,
      int successCode = 200}) async {
    print('\n=====\nresponse => ${response.statusCode} ${response.request}');
    print('${response.body}');
    print('=====\n\n');
    if (response.statusCode == successCode)
      return onSuccess != null ? onSuccess.call(jsonDecode(response.body)) : Future.error(ApiClientErrors.NO_SUCCESS_BODY_FOUND);

    return onError.call(ErrorModel.fromJson(jsonDecode(response.body)));
  }

  Future<UploadUrlModel> generateUploadUrl({@required String json}) async {
    try {
      Response response = await _apiClient.generateUploadUrl(json);

      Future<UploadUrlModel> _onSuccess(Map<String, dynamic> body) async {
        UploadUrlModel model = UploadUrlModel.fromJson(body);
        return model;
      }

      Future<UploadUrlModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<UploadUrlModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> uploadToServer({@required String url, @required String contentType, @required String metaType, @required dynamic data}) async {
    try {
      Response response = await _apiClient.uploadToServer(url, contentType, metaType, data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<UploadFile> uploadFile({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.uploadFile(data);

      Future<UploadFile> _onSuccess(Map<String, dynamic> body) async {
        UploadFile model = UploadFile.fromJson(body);
        return model;
      }

      Future<UploadFile> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }
}
