import 'dart:convert';

import 'package:facetap/apis/apis.dart';
import 'package:facetap/apis/errors.dart';
import 'package:facetap/models/places_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';

class PlacesService {
  final ApiClient _apiClient = locator<ApiClient>();

  Future<T> _onApiCallback<T extends Object>(
      {@required Response response,
      Future<T> Function(int) onError,
      @required Future<T> Function(Map<String, dynamic>) onSuccess,
      int successCode = 200}) async {
    print('\n=====\nresponse => ${response.statusCode} ${response.request}');
    print('${response.body}');
    print('=====\n\n');
    if (response.statusCode == successCode)
      return onSuccess != null ? onSuccess.call(jsonDecode(response.body)) : Future.error(ApiClientErrors.NO_SUCCESS_BODY_FOUND);

    if (response.statusCode == 404) return Future.error(ApiClientErrors.NOT_FOUND);

    if (response.statusCode == 500) return Future.error(ApiClientErrors.SERVER_ERROR);

    return onError.call(response.statusCode);
  }

  Future<PlacesModel> getNearbyPlaces({@required double lat, @required double long, String pageToken = '', String search = ''}) async {
    try {
      Response response = await _apiClient.getNearbyPlaces(lat, long, pageToken, search);

      Future<PlacesModel> _onSuccess(Map<String, dynamic> body) async {
        PlacesModel model = PlacesModel.fromJson(body);
        return model;
      }

      Future<PlacesModel> _error(int code) async {
        return Future.error(ApiClientErrors.UNKNOWN_ERROR);
      }

      return _onApiCallback<PlacesModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<PlacesModel> getPlacesByQuery({@required String search, String pageToken = ''}) async {
    try {
      Response response = await _apiClient.getPlacesByQuery(search, pageToken);

      Future<PlacesModel> _onSuccess(Map<String, dynamic> body) async {
        PlacesModel model = PlacesModel.fromJson(body);
        return model;
      }

      Future<PlacesModel> _error(int code) async {
        return Future.error(ApiClientErrors.UNKNOWN_ERROR);
      }

      return _onApiCallback<PlacesModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }
}
