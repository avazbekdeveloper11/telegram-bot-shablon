import 'package:facetap/models/location_model.dart';
import 'package:facetap/models/medias_model.dart';
import 'package:flutter/cupertino.dart';

class Serializer {
  Map<String, dynamic> prepareDataToRegister(
          {@required String email, @required String firstName, @required String lastName, @required String password, @required String username}) =>
      {'email': email, 'first_name': firstName, 'last_name': lastName, 'password': password, 'username': username};

  Map<String, dynamic> prepareDataToLogin({@required String email, @required String fcmToken, @required String password}) =>
      {'email': email, 'fcm_token': fcmToken, 'password': password};

  Map<String, dynamic> prepareDataToUpdateProfile({
    @required String bio,
    @required String firstName,
    @required String lastName,
    @required String profilePhoto,
    @required String profileBanner,
    @required String username,
    @required String locationName,
  }) =>
      {
        'bio': bio,
        'first_name': firstName,
        'last_name': lastName,
        'profile_photo': profilePhoto,
        'profile_banner': profileBanner,
        'username': username,
        'location_name': locationName,
      };

  Map<String, dynamic> prepareDataToUpdateEmail({@required String email}) => {'email': email};

  Map<String, dynamic> prepareDataToFollow({@required String id}) => {'following_id': id};

  Map<String, dynamic> prepareDataToBlock({@required String id}) => {'blocked_id': id};

  Map<String, dynamic> prepareDataToRemoveFollower({@required String id}) => {'follower_id': id};

  Map<String, dynamic> prepareDataToCretePost(
          {@required String caption,
          @required List<Map<String, dynamic>> hashtags,
          @required LocationModel location,
          @required List<NewPostMediaModel> medias,
          @required String locationName}) =>
      {'caption': caption, 'hashtags': hashtags, 'location': location, 'medias': medias, 'location_name': locationName};

  Map<String, dynamic> prepareDataToLike({@required String id, @required String objectType, @required String type, @required String ownerId}) =>
      {'object_id': id, 'object_type': objectType, 'type': type, 'owner_id': ownerId};

  Map<String, dynamic> prepareDataToComment(
          {@required String content,
          @required String postId,
          @required String objectType,
          String postOwnerId,
          @required String commentOwnerId,
          @required String commentId}) =>
      {
        'content': content,
        'post_id': postId,
        'object_type': objectType,
        'post_owner_id': postOwnerId,
        'comment_owner_id': commentOwnerId,
        'comment_id': commentId
      };

  Map<String, dynamic> prepareDataToDeleteComment(
          {@required String id, @required String objectId, @required String postId, @required String objectType}) =>
      {'id': id, 'object_id': objectId, 'post_id': postId, 'object_type': objectType};

  Map<String, dynamic> prepareDataToChangePassword({@required String password}) => {'new_password': password};

  Map<String, dynamic> prepareDataToResetPassword({@required String email, @required String type}) => {'email': email, 'type': type};

  Map<String, dynamic> prepareDataToSendGift(
          {@required String giftId, @required String giftTempId, @required String message, @required String receiverId}) =>
      {'gift_id': giftId, 'gift_temp_id': giftTempId, 'message': message, 'receiver_id': receiverId};

  Map<String, dynamic> prepareDataToView({@required String objectType, @required String objectId, @required String userId}) =>
      {'object_id': objectId, 'object_type': objectType, 'user_id': userId};

  Map<String, dynamic> prepareDataToInterests({@required List<String> interests}) => {'hashtags': interests};

  Map<String, dynamic> prepareDataToDeletePost({@required String postId}) => {'post_id': postId};

  Map<String, dynamic> prepareDataToSavePost({@required String postId}) => {'post_id': postId};

  Map<String, dynamic> prepareDataToReportUser({@required int reportId, String userId}) => {'report_id': reportId, 'user_id': userId};

  Map<String, dynamic> prepareDataToReportPost({@required int reportId, String postId}) => {'report_id': reportId, 'post_id': postId};

  Map<String, dynamic> prepareDataToPay({@required String method, @required String userId, @required int voteCardId}) =>
      {"method": method, "user_id": userId, "vote_card_id": voteCardId};

  Map<String, dynamic> prepareDataToUploadFile({@required dynamic content, @required String contentType, @required String metadata}) =>
      {'content': content, 'content_type': contentType, 'metadata': metadata};
}
