import 'dart:convert';

import 'package:facetap/apis/apis.dart';
import 'package:facetap/apis/errors.dart';
import 'package:facetap/models/comments_model.dart';
import 'package:facetap/models/error_model.dart';
import 'package:facetap/models/hashtag_model.dart';
import 'package:facetap/models/likes_model.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/rating_model.dart';
import 'package:facetap/models/reports_model.dart';
import 'package:facetap/models/search_model.dart';
import 'package:facetap/models/top_user_model.dart';
import 'package:facetap/models/users_liked_model.dart';
import 'package:facetap/services/chat/chat_model/chat_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';

class PostsService {
  final ApiClient _apiClient = locator<ApiClient>();

  Future<T> _onApiCallback<T extends Object>(
      {@required Response response,
      Future<T> Function(ErrorModel) onError,
      @required Future<T> Function(Map<String, dynamic>) onSuccess,
      int successCode = 200}) async {
    // print('\n=====\nresponse => ${response.statusCode} ${response.request}');
    // print('${response.body}');
    // print('=====\n\n');
    if (response.statusCode == successCode)
      return onSuccess != null ? onSuccess.call(jsonDecode(utf8.decode(response.bodyBytes))) : Future.error(ApiClientErrors.NO_SUCCESS_BODY_FOUND);

    return onError.call(ErrorModel.fromJson(jsonDecode(utf8.decode(response.bodyBytes))));
  }

  Future<PostsModel> getPosts({@required String location, @required int page, @required int limit}) async {
    try {
      Response response = await _apiClient.getPosts(location, page, limit);

      Future<PostsModel> _onSuccess(Map<String, dynamic> body) async {
        PostsModel model = PostsModel.fromJson(body);
        return model;
      }

      Future<PostsModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<PostsModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<PostModel> getPost({@required String postId}) async {
    try {
      Response response = await _apiClient.getPost(postId);

      Future<PostModel> _onSuccess(Map<String, dynamic> body) async {
        PostModel model = PostModel.fromJson(body['result']);
        return model;
      }

      Future<PostModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<PostModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<PostModel> getPostByLink({@required Uri uri}) async {
    try {
      Response response = await _apiClient.getPostByLink(uri);

      Future<PostModel> _onSuccess(Map<String, dynamic> body) async {
        PostModel model = PostModel.fromJson(body['result']);
        return model;
      }

      Future<PostModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<PostModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> deletePost({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.deletePost(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<PostModel> createPost({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.createPost(data);

      Future<PostModel> _onSuccess(Map<String, dynamic> body) async {
        PostModel model = PostModel.fromJson(body['result']);
        return model;
      }

      Future<PostModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<PostModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<SearchPost> userSearchPosts({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.userSearchPost(data);

      Future<SearchPost> _onSuccess(Map<String, dynamic> body) async {
        SearchPost model = SearchPost.fromJson(body);
        return model;
      }

      Future<SearchPost> _error(ErrorModel error) async {
        return Future.error(ApiClientErrors.UNKNOWN_ERROR);
      }

      return _onApiCallback<SearchPost>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<SearchModel> elasticSearch({@required int page, @required String type, @required String search, @required int limit}) async {
    try {
      Response response = await _apiClient.elasticSearch(search: search, limit: limit, type: type, page: page);

      Future<SearchModel> _onSuccess(Map<String, dynamic> body) async {
        SearchModel model = SearchModel.fromJson(body);
        return model;
      }

      Future<SearchModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<SearchModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<SearchPosts> userSearchRecent({@required int page, @required int limit}) async {
    try {
      Response response = await _apiClient.userSearchGet(page: page, limit: limit);

      Future<SearchPosts> _onSuccess(Map<String, dynamic> body) async {
        SearchPosts model = SearchPosts.fromJson(body);
        return model;
      }

      Future<SearchPosts> _error(ErrorModel error) async {
        return Future.error(ApiClientErrors.UNKNOWN_ERROR);
      }

      return _onApiCallback<SearchPosts>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<PostsModel> locationPosts({@required String locationName, @required int page, @required int limit, @required bool isLocation}) async {
    try {
      Response response = await _apiClient.locationPosts(locationName, page, limit, isLocation);

      Future<PostsModel> _onSuccess(Map<String, dynamic> body) async {
        PostsModel model = PostsModel.fromJson(body);
        return model;
      }

      Future<PostsModel> _error(ErrorModel error) async {
        return Future.error(ApiClientErrors.UNKNOWN_ERROR);
      }

      return _onApiCallback<PostsModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<SearchSuggestModel> suggestSearch({
    String search,
  }) async {
    try {
      Response response = await _apiClient.searchSuggest(
        search: search,
      );

      Future<SearchSuggestModel> _onSuccess(Map<String, dynamic> body) async {
        SearchSuggestModel model = SearchSuggestModel.fromJson(body);
        return model;
      }

      Future<SearchSuggestModel> _error(ErrorModel error) async {
        return Future.error(ApiClientErrors.UNKNOWN_ERROR);
      }

      return _onApiCallback<SearchSuggestModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<RatingsListPostsModel> getHashTagPosts({@required int limit, String type, @required int page}) async {
    try {
      Response response = await _apiClient.getHashTagPost(limit, type, page);

      Future<RatingsListPostsModel> _onSuccess(Map<String, dynamic> body) async {
        RatingsListPostsModel model = RatingsListPostsModel.fromJson(body);
        return model;
      }

      Future<RatingsListPostsModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<RatingsListPostsModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> like({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.like(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> dislike({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.like(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<UsersLikedModel> getUsersLiked(
      {@required String type,
      @required String objectType,
      @required String objectId,
      @required int page,
      @required int limit,
      @required String userId}) async {
    try {
      Response response = await _apiClient.getUsersLiked(type, userId, objectType, objectId, page, limit);
      Future<UsersLikedModel> _onSuccess(Map<String, dynamic> body) async {
        UsersLikedModel model = UsersLikedModel.fromJson(body);
        return model;
      }

      Future<UsersLikedModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<UsersLikedModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<TopUserModel> getTopUser({
    @required int page,
    @required int limit,
  }) async {
    try {
      Response response = await _apiClient.getTopUser(page, limit);
      print("1${response.statusCode}");
      Future<TopUserModel> _onSuccess(Map<String, dynamic> body) async {
        TopUserModel model = TopUserModel.fromJson(body);
        return model;
      }

      Future<TopUserModel> _error(ErrorModel error) async {
        return Future.error(ApiClientErrors.UNKNOWN_ERROR);
      }

      return _onApiCallback<TopUserModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<LikesModel> getLikeCount({@required String objectType, @required String objectId}) async {
    try {
      Response response = await _apiClient.getLikeCount(objectType, objectId);

      Future<LikesModel> _onSuccess(Map<String, dynamic> body) async {
        LikesModel model = LikesModel.fromJson(body);
        return model;
      }

      Future<LikesModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<LikesModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<CommentModel> createComment({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.createComment(data);

      Future<CommentModel> _onSuccess(Map<String, dynamic> body) async {
        CommentModel model = CommentModel.fromJson(body);
        return model;
      }

      Future<CommentModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<CommentModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> deleteComment({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.deleteComment(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<CommentsListModel> getComments({@required String objectType, @required String objectId, @required int page, @required int limit}) async {
    try {
      Response response = await _apiClient.getComments(objectType, objectId, page, limit);

      Future<CommentsListModel> _onSuccess(Map<String, dynamic> body) async {
        CommentsListModel model = CommentsListModel.fromJson(body);
        return model;
      }

      Future<CommentsListModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<CommentsListModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> viewed(String objectType, String objectId, String userId, Map<String, dynamic> data) async {
    try {
      Response response = await _apiClient.viewed(objectType, objectId, userId, data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> getViewsCount(String objectType, String objectId) async {
    try {
      Response response = await _apiClient.getViewsCount(objectType, objectId);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<HashtagSuggestModel> getHashtags({@required String search}) async {
    try {
      Response response = await _apiClient.getHashtags(search);

      Future<HashtagSuggestModel> _onSuccess(Map<String, dynamic> body) async {
        HashtagSuggestModel model = HashtagSuggestModel.fromJson(body);
        return model;
      }

      Future<HashtagSuggestModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<HashtagSuggestModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<PostsModel> getSavedPosts(int page, int limit) async {
    try {
      Response response = await _apiClient.getSavedPosts(page, limit);

      Future<PostsModel> _onSuccess(Map<String, dynamic> body) async {
        PostsModel model = PostsModel.fromJson(body);
        return model;
      }

      Future<PostsModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<PostsModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<ChatListModel> getChatRooms(int page, int limit) async {
    try {
      Response response = await _apiClient.getChatRooms(page, limit);

      Future<ChatListModel> _onSuccess(Map<String, dynamic> body) async {
        ChatListModel model = ChatListModel.fromJson(body);
        return model;
      }

      Future<ChatListModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<ChatListModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }


  Future<HasUnreadMessage> hasUnreadMessage() async {
    try {
      Response response = await _apiClient.hasUnreadMessageApi();

      Future<HasUnreadMessage> _onSuccess(Map<String, dynamic> body) async {
        HasUnreadMessage model = HasUnreadMessage.fromJson(body);
        return model;
      }

      Future<HasUnreadMessage> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<HasUnreadMessage>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }
  Future<bool> savePost(Map<String, dynamic> data) async {
    try {
      Response response = await _apiClient.savePost(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> removeSavedPost(Map<String, dynamic> data) async {
    try {
      Response response = await _apiClient.removeSavedPost(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<ReportTypesModel> reportPostTypes({@required int page, int limit}) async {
    try {
      Response response = await _apiClient.reportPostTypes(page, limit);

      Future<ReportTypesModel> _onSuccess(Map<String, dynamic> body) async {
        ReportTypesModel model = ReportTypesModel.fromJson(body);
        return model;
      }

      Future<ReportTypesModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<ReportTypesModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> reportPost({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.reportPost(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }
}
