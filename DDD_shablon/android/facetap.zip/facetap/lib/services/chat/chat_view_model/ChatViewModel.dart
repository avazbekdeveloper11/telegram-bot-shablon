import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:typed_data';

import 'package:facetap/apis/errors.dart';
import 'package:facetap/models/error_model.dart';
import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/models/upload_url_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/gift_page/views/gifts_page.dart';
import 'package:facetap/services/chat/chat_model/chat_model.dart';
import 'package:facetap/services/media_upload_service.dart';
import 'package:facetap/services/serializer.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:scroll_to_index/scroll_to_index.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:wechat_assets_picker/wechat_assets_picker.dart';
import 'package:wechat_camera_picker/wechat_camera_picker.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class ChatViewModel extends Model {
  var channelTwo;

  int page = 1;
  bool isTyping = false;
  bool online = false;
  bool replyMe = false;
  String imagePath="";
  FocusNode focusNode = FocusNode();
  AutoScrollController scrollController;
  AnimationController hideFabAnimation;
  final Serializer serializer = locator<Serializer>();
  List<SocketMessageModel> friendList = [];
  List<SocketMessageModel> messages = [];
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  bool isLoading;
  Timer timer;
  Future<void> init(String accessToken, BuildContext context, String senderId, String receiverChatID, String roomId,
      TickerProvider this2) async {
    isLoading = true;
    startTimer();
    hideFabAnimation = AnimationController(vsync: this2, duration: kThemeAnimationDuration);
    await flutterLocalNotificationsPlugin.cancelAll();
    scrollController = AutoScrollController(
        viewportBoundaryGetter: () => Rect.fromLTRB(0, 0, 0, MediaQuery.of(context).padding.bottom),
        axis: Axis.vertical);
    print("roomId $roomId");
    channelTwo =
        IOWebSocketChannel.connect(Uri.parse('wss://facetap.test.uzpos.uz/ws/chat/$roomId/?token=$accessToken'));
    await channelTwo.sink.add(json.encode({"type": "check_status", "recipient_id": receiverChatID}));
    print("page $page");
    await channelTwo.sink.add(
        '{"type": "get_chat_messages", "sender_id": "$senderId", "limit": 30, "page": $page, "recipient_id": "$receiverChatID", "room_id": "$roomId"}');
    page++;

    channelTwo?.stream?.listen((message) async {
      Map map = jsonDecode(message);
      log("message23 $message");
      switch (map["type"]) {
        case "typing":
          if (map["recipient_id"] == senderId) {
            isTyping = true;
            notifyListeners();
          }
          break;
        case "stop_typing":
          if (map["recipient_id"] == senderId) {
            isTyping = false;
            notifyListeners();
          }
          break;
        case "change_message_status":
          messages
              .where((element) {
                return element.messageId == map["message_id"];
              })
              .first
              .status = "read";
          notifyListeners();
          break;
        case "message":
          if (!map["mine"]) {
            isTyping = false;
          }
          messages.insert(0, SocketMessageModel.fromJsonMessage(map));
          print("messages.length ${messages.length}");
          if (scrollController.position.extentBefore < screenHeight(context) || map["mine"]) {
            scrollAnimatedDown();
          }
          notifyListeners();
          break;
        case "get_chat_messages":
          (map["messages"] as List).forEach((element) {
            messages.add(SocketMessageModel.fromJsonMessage(element));
            notifyListeners();
          });
          break;
        case "user_went_online":
          online = true;
          notifyListeners();
          break;
        case "user_went_offline":
          online = false;
          notifyListeners();
          break;
        case "check_status":
          if (map["status"] == "offline") {
            online = false;
          } else {
            online = true;
          }
          notifyListeners();
          break;
        case "edit_message":
          if(map["status"]=="success")
            messages[messages.indexWhere((element) => element.messageId==map["message_id"])] = SocketMessageModel.fromJsonMessage(map);
          notifyListeners();
          break;
        case "delete_message":
          if(map["status"]=="success")
          messages.removeWhere((element) => element.messageId==map["message_id"]);
          notifyListeners();
          break;
        case "blocked":
          if(map["status"]=="user_is_blocked")
            showBlockedErrorDialog(context);
          notifyListeners();
          break;
      }
    });


    scrollController = AutoScrollController()
      ..addListener(() {
        _scrollListener(accessToken, context, senderId, receiverChatID, roomId);
        switch (scrollController.position.userScrollDirection) {
          case ScrollDirection.forward:
            if (scrollController.position.extentBefore > 20) {
              if (scrollController.position.maxScrollExtent != scrollController.position.minScrollExtent) {
                hideFabAnimation.forward();
              }
            } else {
              hideFabAnimation.reverse();
            }
            break;
          case ScrollDirection.reverse:
            if (scrollController.position.maxScrollExtent != scrollController.position.minScrollExtent) {
              hideFabAnimation.reverse();
            }
            break;
          case ScrollDirection.idle:
            break;
        }
      });
  }

  void startTimer() {
    timer = Timer.periodic(const Duration(seconds: 3), (t) {
        isLoading = false; //set loading to false
    notifyListeners();
      t.cancel(); //stops the timer
    });
  }
  Future<void> sendMessage(
    String text,
    String receiverChatID,
    String senderId,
    String replyId,
    String roomId,
      String mediaId,
      String mediaType,
      int giftPoints
  ) async {
    await channelTwo.sink.add(json.encode({
      "type": "message",
      "message": "${text.trim()}",
      "room_id": "$roomId",
      "sender_id": "$senderId",
      "recipient_id": "$receiverChatID",
      "reply_id": "$replyId",
      "media_id": "$mediaId",
      "media_type": "$mediaType",
      "gift_points": giftPoints
    }));
    notifyListeners();
  }

  Future<void> readMessages(String receiverId, String roomId, String messageId) async {
    print("roomId $roomId");
    await channelTwo.sink.add(json.encode({
      "type": "change_message_status",
      "room_id": roomId,
      "recipient_id": receiverId,
      "apply": "specific",
      "message_id": messageId
    }));
  }

  Future<void> editMessage(String newMessage, String messageId) async {
    print("edit $messageId");
    await channelTwo.sink
        .add(json.encode({"type": "edit_message", "message": "$newMessage", "message_id": "$messageId"}));
  }

  Future<void> deleteMessage(String messageId, String senderId) async {
    await channelTwo.sink
        .add(json.encode({"type": "delete_message", "recipient_id": "$senderId", "message_id": "$messageId"}));
  }


  List<SocketMessageModel> getMessagesForChatID(String chatID) {
    return messages;
  }

  _scrollListener(
    String accessToken,
    BuildContext context,
    String senderId,
    String receiverChatID,
    String roomId,
  ) async {
    if (scrollController.position.extentBefore == scrollController.position.maxScrollExtent) {
      print("page $page");
    await  channelTwo.sink.add(
          '{"type": "get_chat_messages", "sender_id": "$senderId", "limit": 30, "page": $page, "recipient_id": "$receiverChatID", "room_id": "$roomId"}');
      page++;
    }
  }

  changeReplyMe(bool reply) {
    this.replyMe = reply;
  }


  scrollAnimatedDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scrollController.hasClients) {
        scrollController.animateTo(
          0,
          duration: Duration(seconds: 1),
          curve: Curves.fastOutSlowIn,
        );
      }
    });
  }

  showBlockedErrorDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Color(0xff1e1e1e),
          title: Center(child: Text("You are not able to write message to this user", style: Medium.copyWith(color: WhiteColor))),
        );
      },
    );
  }


  sendGift(BuildContext context, UserModel recipientProfile, String receiverChatID,
      String userId,
      String replyId,
      String roomId)async{
    Navigator.pop(context);
    GiftTempsModel giftTempsModel =    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => GiftsPage(profile: recipientProfile)));
    if(giftTempsModel!=null){
      print(giftTempsModel.image.mediaId);
      print(giftTempsModel.id);
      // giftTempsModel.image.
      sendMessage(giftTempsModel.message, receiverChatID, userId, replyId, roomId, giftTempsModel.image.mediaId, "gift", giftTempsModel.receiverPoints);
    }
  }

  imgFromCamera(BuildContext context, String receiverChatID,
      String senderId,
      String replyId,
      String roomId,) async {
    Navigator.pop(context);
    final AssetEntity _assets = await CameraPicker.pickFromCamera(
      context,
      enableRecording: false,
      textDelegate: EnglishCameraPickerTextDelegate(),
    );
    if (_assets != null) {
      _assets.file.then((value) {
        imagePath=value.path;
      });
      _assets.thumbDataWithSize(1280, 1280, quality: 60).then((value) {
        uploadFile(value, context, receiverChatID, senderId, replyId, roomId);
      });
    }else{
      imagePath="";
    }
  }


  imgFromGallery(BuildContext context, String receiverChatID,
      String senderId,
      String replyId,
      String roomId,) async {
    Navigator.pop(context);
    AssetPicker.pickAssets(
      context,
      maxAssets: 1,
      textDelegate: EnglishTextDelegate(),
      requestType: RequestType.image,
    ).then((List<AssetEntity> _assets) async {
      if (_assets != null) {
        _assets.first.file.then((value) {
          imagePath=value.path;
        });
        _assets.first.thumbDataWithSize(1280, 1280, quality: 60).then((value) {
          uploadFile(value, context, receiverChatID, senderId, replyId, roomId);
        });
      }else{
        imagePath="";
      }
      });
  }

  uploadFile(Uint8List postMedia , BuildContext context,    String receiverChatID,
      String senderId,
      String replyId,
      String roomId, ) async {
    Map<String, dynamic> data = serializer.prepareDataToUploadFile(
        content: postMedia, contentType: 'image/jpeg', metadata: 'chat_image');
    UploadFile _response = await MediaUploadService().uploadFile(data: data).onError((error, stackTrace) => onError(error, context));
    if (_response != null){
      print(_response.filename);
      sendMessage("", receiverChatID, senderId, replyId, roomId, _response.filename, "photo", 0);
    }
  }


  void showSnackBar(String message, BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(
            message,
            style: Regular.copyWith(color: BlackColor),
          ),
          backgroundColor: WhiteColor),
    );
  }


  Future<T> onError<T extends Object>(dynamic error, BuildContext context) {
    if (error is ErrorModel) showSnackBar(error.error.message, context);

    if (error == ApiClientErrors.UNKNOWN_ERROR) showSnackBar('Error occured, please try again.', context);
    if (error == ApiClientErrors.NOT_FOUND) showSnackBar('Error occured, please try again.', context);
    if (error == ApiClientErrors.SERVER_ERROR) showSnackBar('We are experiencing server side error, please try again.', context);
    return null;
  }


  dispose(
    String accessToken,
    BuildContext context,
    String senderId,
    String receiverChatID,
    String roomId,
  ) {
    isLoading = true;
    timer?.cancel();
    hideFabAnimation.dispose();
    print("status.goingAway ${status.goingAway}");
    scrollController?.removeListener(() {
      _scrollListener(accessToken, context, senderId, receiverChatID, roomId);
    });
    channelTwo?.sink?.close(status.goingAway);
    messages?.clear();
    page = 1;
  }
}
