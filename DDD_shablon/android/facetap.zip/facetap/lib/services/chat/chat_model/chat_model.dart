class ChatListModel {

  ChatListModel({
    this.rooms,
  });

  List<RoomModel> rooms;

  factory ChatListModel.fromJson(Map<String, dynamic> json) => ChatListModel(
    rooms: List<RoomModel>.from(json["rooms"].map((x) => RoomModel.fromJson(x))),
  );

}

class RoomModel {
  RoomModel({
    this.id,
    this.type,
    this.lastMessage,
    this.userId,
    this.profilePhoto,
    this.fullName,
    this.unreadCount,
    this.messagesCount,
    this.mediaType,
    this.replyUrl
  });

  String id;
  String type;
  SocketMessageModel lastMessage;
  String userId;
  String profilePhoto;
  String fullName;
  int unreadCount;
  int messagesCount;
  String mediaType;
  String replyUrl;

  factory RoomModel.fromJson(Map<String, dynamic> json) => RoomModel(
    id: json["id"],
    type: json["type"],
    lastMessage: SocketMessageModel.fromJsonMessage(json["last_message"]),
    userId: json["user_id"],
    profilePhoto: json["profile_photo"],
    fullName: json["full_name"],
    unreadCount: json["unread_count"],
    messagesCount: json["messages_count"],
    mediaType: json["media_type"],
    replyUrl: json["reply_url"]
  );


}


class SocketMessageModel {
  SocketMessageModel({
    this.type,
    this.message,
    this.mine,
    this.time,
    this.recipientId,
    this.senderId,
    this.limit,
    this.page,
    this.roomId,
    this.timezone,
    this.status,
    this.mediaUrl,
    this.contentType,
    this.lastSeen,
    this.thumbnailUrl,
    this.replyId,
    this.messageId,
    this.newChat,
    this.replyUrl,
    this.mediaType,
    this.giftPoints
  });
  String type;
  String message;
  bool mine;
  DateTime time;
  String recipientId;
  String senderId;
  int limit;
  int page;
  String roomId;
  int timezone;
  String status;
  String messageId;
  String mediaUrl;
  String contentType;
  String lastSeen;
  String thumbnailUrl;
  String replyId;
  bool newChat;
  String replyUrl;
String mediaType;
int giftPoints;


  factory SocketMessageModel.fromJsonMessage(Map<String, dynamic> json) {
   return SocketMessageModel(
      type: json["type"],
      message: json["message"],
      mine: json["mine"],
      time: json.keys.contains("sent_at") ? DateTime.parse(json["sent_at"]).toLocal() :  DateTime.parse(json["time"]).toLocal(),
      recipientId: json["recipient_id"],
      senderId: json["sender_id"],
      roomId: json["room_id"],
      status: json["status"],
      mediaUrl: json["media_url"],
      contentType: json["content_type"],
      replyId: json["reply_id"],
      messageId: json["id"],
     thumbnailUrl: json["thumbnail_url"],
     replyUrl: json["reply_url"],
     mediaType: json["media_type"],
     giftPoints: json["gift_points"]
    );
  }

}




class HasUnreadMessage {
  HasUnreadMessage({
    this.exist,
  });

  bool exist;

  factory HasUnreadMessage.fromJson(Map<String, dynamic> json) => HasUnreadMessage(
    exist: json["exist"],
  );

  Map<String, dynamic> toJson() => {
    "exist": exist,
  };
}