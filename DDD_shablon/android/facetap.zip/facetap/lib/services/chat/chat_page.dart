import 'dart:async';

import 'package:facetap/apis/errors.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/error_model.dart';
import 'package:facetap/models/reports_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/settings_page/local_widget/views/settings_templates.dart';
import 'package:facetap/services/chat/widgets/message_card_widget.dart';
import 'package:facetap/services/chat/widgets/message_form_field.dart';
import 'package:facetap/services/serializer.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:focused_menu/focused_menu.dart';
import 'package:focused_menu/modals.dart';
import 'package:intl/intl.dart' as intl;
import 'package:lottie/lottie.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:scoped_model/scoped_model.dart';
import 'package:scroll_to_index/scroll_to_index.dart';
import 'package:swipe_to/swipe_to.dart';
import 'package:web_socket_channel/status.dart' as status;

import 'chat_model/chat_model.dart';
import 'chat_view_model/ChatViewModel.dart';

class ChatPage extends StatefulWidget {
  final SocketMessageModel socketMessage;
  final UserModel recipientModel;
  final String accessToken;

  ChatPage(this.socketMessage, this.recipientModel, this.accessToken);

  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with TickerProviderStateMixin {
  TextEditingController textEditingController = TextEditingController();
  SocketMessageModel replyMessage;
  List<ReportTypeModel> reportTypes = [];
  final UserService _userService = UserService();
  final Serializer serializer = Serializer();
  bool _edit = false;

  void replyToMessage(SocketMessageModel message, FocusNode focusNode) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      FocusScope.of(context).requestFocus(focusNode);
    });
    print("message.messageId ${message.messageId}");
    setState(() {
      _edit = false;
      replyMessage = message;
    });
  }

  void editMessage(SocketMessageModel message, FocusNode focusNode) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      FocusScope.of(context).requestFocus(focusNode);
    });
    print("message.messageId ${message.messageId}");
    setState(() {
      _edit = true;
      replyMessage = message;
    });
  }

  void cancelReply(ChatViewModel model) {
    if (_edit) {
      setState(() {
        _edit = false;
        replyMessage = null;
      });
    } else {
      setState(() {
        replyMessage = null;
      });
    }
  }

  void showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(
            message,
            style: Regular.copyWith(color: BlackColor),
          ),
          backgroundColor: WhiteColor),
    );
  }

  Future<T> onError<T extends Object>(dynamic error) {
    if (error is ErrorModel) showSnackBar(error.error.message);

    if (error == ApiClientErrors.UNKNOWN_ERROR) showSnackBar('Error occured, please try again.');
    if (error == ApiClientErrors.NOT_FOUND) showSnackBar('Error occured, please try again.');
    if (error == ApiClientErrors.SERVER_ERROR) showSnackBar('We are experiencing server side error, please try again.');
    return null;
  }

  fetchReportTypes() async {
    Navigator.pop(context);
    if ((reportTypes ?? []).isEmpty) {
      ReportTypesModel _response =
          await _userService.reportUserTypes(page: 1, limit: 20).onError((error, stackTrace) => onError(error));

      if (_response != null) reportTypes.addAll(_response.results);
    }

    showReportBottomSheet();
  }

  reportUser(int reportId, BuildContext context) async {
    Navigator.pop(context);
    showSnackBar('Report sent');
    Map<String, dynamic> data =
        serializer.prepareDataToReportUser(reportId: reportId, userId: widget.recipientModel.id);
    bool _response = await _userService.reportUser(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print('user reported ${widget.recipientModel.id}');
  }

  blockUser() {
    Navigator.pop(context);
    showCustomDialog('Block this user?', "They won't be able to see your profile or content on FaceTap.",
        () => _block(widget.recipientModel.id));
  }

  _block(String id) async {
    Navigator.pop(context);
    Map<String, dynamic> data = serializer.prepareDataToBlock(id: id);
    bool _response = await _userService.block(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null && _response) {
      print(_response);
      showSnackBar("User successfully blocked");
    }
  }

  @override
  void initState() {
    ScopedModel.of<ChatViewModel>(context, rebuildOnChange: false).init(widget.accessToken, context,
        widget.socketMessage.senderId, widget.socketMessage.recipientId, widget.socketMessage.roomId, this);
    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused) {
      print(state);
      ScopedModel.of<ChatViewModel>(context, rebuildOnChange: false).channelTwo?.sink?.close(status.goingAway);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScopedModelDescendant<ChatViewModel>(builder: (context, child, model) {
      return GestureDetector(
        onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
        child: Scaffold(
            floatingActionButton: ScaleTransition(
              scale: model.hideFabAnimation,
              child: Container(
                margin: const EdgeInsets.only(bottom: 56),
                child: GestureDetector(
                  onTap: () {
                    print(8778);
                    model.scrollAnimatedDown();
                    setState(() {});
                  },
                  child: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(color: Color(0xff262626), shape: BoxShape.circle),
                    child: Icon(
                      Icons.keyboard_arrow_down,
                      color: Colors.white,
                      size: 32,
                    ),
                  ),
                ),
              ),
            ),
            backgroundColor: Color(0xff0A0A0A),
            appBar: AppBar(
              bottom: PreferredSize(
                  child: Container(
                    color: Color(0xff272727),
                    height: 1.0,
                  ),
                  preferredSize: Size.fromHeight(4.0)),
              elevation: 0,
              backgroundColor: Colors.transparent,
              leading: IconButton(
                icon: Icon(
                  Icons.arrow_back_ios,
                  size: 16,
                ),
                onPressed: () {
                  ScopedModel.of<ChatViewModel>(context, rebuildOnChange: false).dispose(widget.accessToken, context,
                      widget.socketMessage.senderId, widget.socketMessage.recipientId, widget.socketMessage.roomId);
                  Navigator.pop(context);
                },
              ),
              centerTitle: true,
              actions: [
                IconButton(
                    onPressed: () {
                      showMaterialModalBottomSheet(
                          backgroundColor: Colors.transparent,
                          context: context,
                          expand: false,
                          builder: (_) => Container(
                                decoration: BoxDecoration(
                                    color: Color(0xff202021),
                                    borderRadius:
                                        BorderRadius.only(topLeft: Radius.circular(12), topRight: Radius.circular(12))),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    GestureDetector(
                                      child: Padding(
                                        padding: const EdgeInsets.all(28.0),
                                        child: Text(
                                          "Block",
                                          style: Regular.copyWith(color: Color(0xffEE505A), fontSize: 16),
                                        ),
                                      ),
                                      onTap: blockUser,
                                    ),
                                    GestureDetector(
                                        child: Padding(
                                          padding: const EdgeInsets.all(28.0),
                                          child: Text(
                                            "Report",
                                            style: Regular.copyWith(color: Color(0xffffffff), fontSize: 16),
                                          ),
                                        ),
                                        onTap: fetchReportTypes),
                                    GestureDetector(
                                      child: Padding(
                                        padding: const EdgeInsets.all(28.0),
                                        child: Text(
                                          "Cancel",
                                          style: Regular.copyWith(color: Color(0xffffffff), fontSize: 16),
                                        ),
                                      ),
                                      onTap: () {
                                        Navigator.pop(context);
                                      },
                                    ),
                                  ],
                                ),
                              ));
                    },
                    icon: SvgPicture.asset(Assets.svgMoreHorizontal)),
              ],
              title: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                      width: screenWidth(context) / 1.5, child: Center(child: Text(widget.recipientModel.firstName))),
                  SizedBox(
                    height: 30,
                    width: screenWidth(context) / 1.5,
                    child: model.isTyping
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                'typing',
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: Regular.copyWith(
                                  color: Colors.white,
                                  fontSize: 14,
                                ),
                              ),
                              Lottie.asset(
                                'assets/animations/chat-typing-indicator.json',
                                width: 40,
                                height: 30,
                                alignment: Alignment.bottomLeft,
                              ),
                            ],
                          )
                        : Center(
                            child: Text(
                              model.online ? 'Online' : "Offline",
                              style: Theme.of(context).textTheme.headline6.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                  ),
                            ),
                          ),
                  ),
                ],
              ),
            ),
            body: WillPopScope(
              onWillPop: () async {
                ScopedModel.of<ChatViewModel>(context, rebuildOnChange: false).dispose(widget.accessToken, context,
                    widget.socketMessage.senderId, widget.socketMessage.recipientId, widget.socketMessage.roomId);
                return true;
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[Expanded(child: buildChatList(model)), buildChatArea(model)],
              ),
            )),
      );
    });
  }

  int daysBetween(DateTime from, DateTime to) {
    from = DateTime(from.year, from.month, from.day);
    to = DateTime(to.year, to.month, to.day);
    return (to.difference(from).inHours / 24).round();
  }

  Widget buildChatList(ChatViewModel model) {
    List<SocketMessageModel> messages = model.getMessagesForChatID(widget.socketMessage.recipientId);
    return Container(
      height: MediaQuery.of(context).size.height * 0.45,
      width: screenWidth(context),
      child: ListView.separated(
          separatorBuilder: (BuildContext context, int index) {
            return messages.length - 1 == index
                ? Container(
                    width: screenWidth(context),
                    child: Center(
                      child: Text(
                        "${messages[index].time.year == DateTime.now().year ? intl.DateFormat('MMM dd').format(messages[index].time) : intl.DateFormat('yyyy MMM dd').format(messages[index].time)}",
                        style: Bold.copyWith(color: Colors.white),
                      ),
                    ))
                : daysBetween(messages[index].time, messages[index + 1].time) == 0
                    ? Container()
                    : Container(
                        width: screenWidth(context),
                        child: Center(
                          child: Text(
                            "${messages[index].time.year == DateTime.now().year ? intl.DateFormat('MMM dd').format(messages[index].time) : intl.DateFormat('yyyy MMM dd').format(messages[index].time)}",
                            style: Bold.copyWith(color: Colors.white),
                          ),
                        ));
          },
          reverse: true,
          controller: model.scrollController,
          itemCount: messages.length + 1,
          itemBuilder: (ctx, index) {
            print(!model.isLoading);
            print(messages.length != 0);
            if (!model.isLoading || messages.length != 0) {
              if(messages.length==0){
                return Center(child: Text("No messages here yet...", style: Medium.copyWith(color: Colors.white),),);
              }else {
                if (index == messages.length) {
                  return Container();
                } else {
                  if (!messages[index].mine && messages[index].status == "new") {
                    print("status==new");
                    model.readMessages(messages[index].senderId, messages[index].roomId, messages[index].messageId);
                  }
                  return messages.length == 0
                      ? Container()
                      : AutoScrollTag(
                    key: ValueKey(index),
                    controller: model.scrollController,
                    index: index,
                    highlightColor: Color(0xff262626),
                    child: SwipeTo(
                      onLeftSwipe: () {
                        model.changeReplyMe(!messages[index].mine);
                        replyToMessage(messages[index], model.focusNode);
                      },
                      child: FocusedMenuHolder(
                        menuOffset: 8,
                        bottomOffsetHeight: 8,
                        menuBoxDecoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(24), color: Color(0x90252525)),
                        onPressed: () {
                          print(0989);
                        },
                        menuItems: [
                          FocusedMenuItem(
                              backgroundColor: Color(0xff252525),
                              title: Text(
                                "Reply",
                                style: Regular.copyWith(color: Color(0xffffffff), fontSize: 17),
                              ),
                              trailingIcon: Icon(
                                Icons.reply_rounded,
                                color: Color(0xffffffff),
                              ),
                              onPressed: () {
                                model.changeReplyMe(!messages[index].mine);
                                replyToMessage(messages[index], model.focusNode);
                              }),
                          if (messages[index].mediaUrl == '') ...[
                            FocusedMenuItem(
                                backgroundColor: Color(0xff252525),
                                title: Text(
                                  "Copy",
                                  style: Regular.copyWith(color: Color(0xffffffff), fontSize: 17),
                                ),
                                trailingIcon: Icon(
                                  Icons.copy,
                                  color: Color(0xffffffff),
                                ),
                                onPressed: () {
                                  Clipboard.setData(new ClipboardData(text: messages[index].message));
                                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                    content: Text("Text copied"),
                                    duration: Duration(milliseconds: 400),
                                  ));
                                })
                          ],
                          if (messages[index].mine && messages[index].mediaUrl == '') ...[
                            FocusedMenuItem(
                                backgroundColor: Color(0xff252525),
                                title: Text(
                                  "Edit",
                                  style: Regular.copyWith(color: Color(0xffffffff), fontSize: 17),
                                ),
                                trailingIcon: Icon(
                                  Icons.edit,
                                  color: Color(0xffffffff),
                                ),
                                onPressed: () {
                                  if (messages[index].mine) {
                                    editMessage(messages[index], model.focusNode);
                                  }
                                })
                          ],
                          // FocusedMenuItem(
                          //     backgroundColor: Color(0xff252525),
                          //     title: Text(
                          //       "Forward",
                          //       style: Regular.copyWith(color: Color(0xffffffff), fontSize: 17),
                          //     ),
                          //     trailingIcon: Icon(
                          //       Icons.forward,
                          //       color: Color(0xffffffff),
                          //     ),
                          //     onPressed: () {}),
                          FocusedMenuItem(
                              backgroundColor: Color(0xff252525),
                              title: Text(
                                "Delete",
                                style: Regular.copyWith(color: Color(0xffFF453A), fontSize: 17),
                              ),
                              trailingIcon: Icon(
                                Icons.delete_outline,
                                color: Color(0xffFF453A),
                              ),
                              onPressed: () {
                                model.deleteMessage(messages[index].messageId, messages[index].senderId);
                              }),
                        ],
                        child: MessagesItem(
                            imagePath: model.imagePath,
                            pageController: model.scrollController,
                            index: messages[index].replyId != ''
                                ? messages.indexOf(messages?.firstWhere(
                                    (element) => element.messageId == messages[index].replyId,
                                orElse: () => null))
                                : 0,
                            bottom: messages.length == 1
                                ? true
                                : index == 0
                                ? true
                                : messages[index].mine
                                ? !messages[index - 1].mine
                                : messages[index - 1].mine,
                            top: messages.length == 1
                                ? true
                                : index == messages.length - 1
                                ? true
                                : messages[index].mine
                                ? !messages[index + 1].mine
                                : messages[index + 1].mine,
                            replyMe: messages
                                ?.firstWhere((element) => element.messageId == messages[index].replyId,
                                orElse: () => null)
                                ?.mine ??
                                false,
                            replyMessage: messages?.firstWhere(
                                    (element) => element.messageId == messages[index].replyId,
                                orElse: () => null) ??
                                null,
                            message: messages[index],
                            isUserMassage: messages[index].mine,
                            recipientModel: widget.recipientModel,
                            isGroup: index == 0
                                ? false
                                : messages[index].mine
                                ? false
                                : messages.length != 0
                                ? !messages[index - 1].mine
                                : true),
                      ),
                    ),
                  );
                }
              }
            } else {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  CircularProgressIndicator(), //show this if state is loading
                  Text("Loading...."),
                ],
              );
            }
          }),
    );
  }

  Widget buildChatArea(
    ChatViewModel model,
  ) {
    return MessageFormField(
      sendGift: (String messageId) => model.sendGift(context, widget.recipientModel, widget.socketMessage.recipientId,
          widget.recipientModel.id, messageId, widget.socketMessage.roomId),
      camera: (String replyId) async {
        await model.imgFromCamera(context, widget.socketMessage.recipientId, widget.socketMessage.senderId, replyId,
            widget.socketMessage.roomId);
        cancelReply(model);
      },
      gallery: (String messageId) async {
        await model.imgFromGallery(context, widget.socketMessage.recipientId, widget.socketMessage.senderId, messageId,
            widget.socketMessage.roomId);
        cancelReply(model);
      },
      editMessage: (String newMessage, String messageId) => model.editMessage(newMessage, messageId),
      edit: _edit,
      focusNode: model.focusNode,
      firstName: widget.recipientModel.firstName,
      replyMe: model.replyMe,
      onSendMessage: (String messageContent, String messageId) {
        model.sendMessage(messageContent, widget.socketMessage.recipientId, widget.socketMessage.senderId, messageId,
            widget.socketMessage.roomId, "", "", 0);
      },
      onTyping: () async {
        await model.channelTwo.sink.add('{"type": "typing", "recipient_id": "${widget.socketMessage.recipientId}"}');
      },
      onStopTyping: () async {
        await model.channelTwo.sink
            .add('{"type": "stop_typing", "recipient_id": "${widget.socketMessage.recipientId}"}');
      },
      onCancelReply: () => cancelReply(model),
      replyMessage: replyMessage,
    );
  }

  showReportBottomSheet() => showModalBottomSheet(
        backgroundColor: BottomSheetColor,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(topLeft: Radius.circular(12.0), topRight: Radius.circular(12.0))),
        context: context,
        builder: (BuildContext bc) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16, right: 16, top: 12, bottom: 12),
                child: Text('Report', style: Regular.copyWith(color: WhiteColor, fontSize: 16)),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16, right: 16, bottom: 12),
                child: Text('Why are you reporting this profile?',
                    style: Regular.copyWith(color: TextFromFieldHintColor, fontSize: 14)),
              ),
              Container(
                padding: EdgeInsets.only(left: 16, right: 16, bottom: 32),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      for (var item in reportTypes)
                        SettingsTemplates(name: item.message, onNavigationTap: () => reportUser(item.id, context)),
                    ],
                  ),
                ),
              )
            ],
          );
        },
      );

  showCustomDialog(String title, String message, Function confirmAction) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Color(0xff1e1e1e),
          title: Text(title, style: Medium.copyWith(color: WhiteColor)),
          content: Text(message, style: Regular.copyWith(color: WhiteColor)),
          actions: [
            TextButton(
                child: Text('Cancel', style: Medium.copyWith(color: WhiteColor)),
                onPressed: () {
                  Navigator.pop(context);
                }),
            TextButton(child: Text('Confirm', style: Medium.copyWith(color: AccentColor)), onPressed: confirmAction)
          ],
        );
      },
    );
  }
}
