import 'dart:async';
import 'package:facetap/services/chat/chat_model/chat_model.dart';
import 'package:facetap/services/chat/widgets/reply_message_widget.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

class MessageFormField extends StatefulWidget {
  final Function(String, String) onSendMessage;
  final Function(String, String) editMessage;
  final bool replyMe;
  final bool edit;
  final Function onTyping;
  final FocusNode focusNode;
  final Function onStopTyping;
  final String  firstName;
  final SocketMessageModel replyMessage;
  final VoidCallback onCancelReply;
  final Function(String) camera;
  final Function(String) gallery;
  final Function  sendGift;

  const MessageFormField({
    @required this.onSendMessage,
    @required this.onTyping,
    @required this.onStopTyping,
    @required this.replyMessage,
    @required this.onCancelReply,
    this.replyMe,
    this.firstName,
    @required this.focusNode, this.edit, this.editMessage, this.camera, this.gallery, this.sendGift,
  });

  @override
  _MessageFormFieldState createState() => _MessageFormFieldState();
}

class _MessageFormFieldState extends State<MessageFormField> {
  TextEditingController _textEditingController;

  Timer _typingTimer;

  bool _isTyping = false;

  void _sendMessage() {
    if (_textEditingController.text.isEmpty) return;
    widget.onCancelReply();
    widget.edit ? widget.editMessage(_textEditingController.text, widget.replyMessage != null ? widget.replyMessage.messageId : "") : widget.onSendMessage(_textEditingController.text, widget.replyMessage != null ? widget.replyMessage.messageId : "");
    setState(() {
      _textEditingController.text = "";
    });
  }

  void _runTimer() {
    if (_typingTimer != null && _typingTimer.isActive) _typingTimer.cancel();
    _typingTimer = Timer(Duration(milliseconds: 1600), () {
      if (!_isTyping) return;
      _isTyping = false;
      widget.onStopTyping();
    });
    _isTyping = true;
    widget.onTyping();
  }

  @override
  void initState() {
    super.initState();
    _textEditingController = TextEditingController();
  }

  @override
  void dispose() {
    _textEditingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _textEditingController.text=widget.edit ? widget.replyMessage.message : "";
    _textEditingController.selection=TextSelection.collapsed(offset: _textEditingController.text.length);
    final isReplying = widget.replyMessage != null;
    return Container(
      margin: EdgeInsets.only(bottom: MediaQuery.of(context).padding.bottom+8),
      width: screenWidth(context),
      color: Colors.transparent,
      padding: const EdgeInsets.only(left: 0, right: 12, top: 8, bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Container(
            margin: EdgeInsets.symmetric(horizontal: 12, ),
            decoration: BoxDecoration(color: Color(0xffFF5F0E), shape: BoxShape.circle),
            child: IconButton(
              padding: EdgeInsets.all(0),
              onPressed: () {
                showMaterialModalBottomSheet(
                    backgroundColor: Colors.transparent,
                    context: context,
                    expand: false,
                    builder: (_) => Container(
                      decoration: BoxDecoration(
                          color: Color(0xff202021),
                          borderRadius:
                          BorderRadius.only(topLeft: Radius.circular(12), topRight: Radius.circular(12))),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GestureDetector(
                            child: Padding(
                              padding: const EdgeInsets.all(28.0),
                              child: Row(
                                children: [
                                  SvgPicture.asset("assets/svg/chat_camera.svg"),
                                  SizedBox(
                                    width: 16,
                                  ),
                                  Text(
                                    "Camera",
                                    style: Medium.copyWith(color: Color(0xffffffff), fontSize: 16),
                                  ),
                                ],
                              ),
                            ),
                            onTap:()=> widget.camera(widget.replyMessage != null ? widget.replyMessage.messageId : ""),
                          ),
                          GestureDetector(
                            child: Padding(
                              padding: const EdgeInsets.all(28.0),
                              child: Row(
                                children: [
                                  SvgPicture.asset("assets/svg/chat_gallery.svg"),
                                  SizedBox(
                                    width: 16,
                                  ),
                                  Text(
                                    "Gallery",
                                    style: Medium.copyWith(color: Color(0xffffffff), fontSize: 16),
                                  ),
                                ],
                              ),
                            ),
                            onTap: ()=>widget.gallery(widget.replyMessage != null ? widget.replyMessage.messageId : ""),
                          ),
                          GestureDetector(

                            child: Padding(
                              padding: const EdgeInsets.all(28.0),
                              child: Row(
                                children: [
                                  SvgPicture.asset("assets/svg/chat_gift.svg"),
                                  SizedBox(
                                    width: 16,
                                  ),
                                  Text(
                                    "Send gifts",
                                    style: Medium.copyWith(color: Color(0xffffffff), fontSize: 16),
                                  ),
                                ],
                              ),
                            ),
                            onTap: () =>
                              widget.sendGift(widget.replyMessage != null ? widget.replyMessage.messageId : ""),
                          ),
                        ],
                      ),
                    ));
              },
              icon: Icon(Icons.add),
              color: Colors.white,
              iconSize: 24,
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (isReplying) buildReply(),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Color(0xff202021),
                  ),
                  child: TextField(
                    focusNode: widget.focusNode,
                    scrollPadding: EdgeInsets.only(),
                    maxLines: null,
                    keyboardType: TextInputType.multiline,
                    onChanged: (_) {
                      _runTimer();
                    },
                    onSubmitted: (_) {
                      _sendMessage();
                    },
                    controller: _textEditingController,
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.symmetric(vertical: 16),
                      hintText: 'Type message...',
                      suffixIcon: Container(
                        child: IconButton(
                          padding: EdgeInsets.all(0),
                          onPressed: _sendMessage,
                          icon: Text(
                            "Send",
                            style: Bold.copyWith(
                              color: Color(0xffFF5F0E),
                              fontSize: 15,
                            ),
                          ),
                          color: Theme.of(context).primaryColor,
                          iconSize: 35,
                        ),
                      ),
                      hintStyle: Regular.copyWith(
                        color: Color(0xff808185),
                        fontSize: 15,
                      ),
                      border: InputBorder.none,
                    ),
                    style: Regular.copyWith(
                      color: Colors.white,
                      fontSize: 15,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildReply() => ReplyMessageWidget(
    firstName: widget.edit ? "Edit Message" : widget.replyMe ? widget.firstName : "you",
    message: widget.replyMessage,
    onCancelReply: widget.onCancelReply,
    input: false,
  );
}