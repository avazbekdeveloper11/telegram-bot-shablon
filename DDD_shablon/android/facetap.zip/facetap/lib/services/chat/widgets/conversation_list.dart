import 'package:extended_image/extended_image.dart';
import 'package:facetap/services/chat/chat_model/chat_model.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' as intl;


class ConversationList extends StatelessWidget {
  final String name;
  final SocketMessageModel messageText;
  final String imageUrl;
  final DateTime time;
  final int unReadMessageCount;
final Function onTap;
  ConversationList(
      {@required this.name,
        @required this.messageText,
        @required this.imageUrl,
        @required this.time, @required  this.unReadMessageCount, @required this.onTap});

  @override
  Widget build(BuildContext context) {
    print(DateTime.now().day - time.day);
    String _time;
    if (time.year == DateTime.now().year) {
      if (time.month == DateTime.now().month &&
          DateTime.now().day - time.day <= 7) {
        if (time.day == DateTime.now().day) {
          if ( DateTime.now().isBefore(time.add(Duration(minutes: 5)))) {
            _time = "Just now";
          } else {
            _time = intl.DateFormat('hh:mm').format(time);
          }
        } else {
          _time = intl.DateFormat('E').format(time);
        }
      } else {
        _time = intl.DateFormat('dd/MM').format(time);
      }
    } else {
      _time = intl.DateFormat('yyyy/MM').format(time);
    }
    print(messageText.replyUrl);
    print(messageText.mediaType);
    print(messageText.message);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.only(left: 16, right: 16, top: 10, bottom: 10),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Row(
                children: <Widget>[
                  Container(
                    height: 56,
                    width: 56,
                    child: ClipRRect(
                      child: ExtendedImage.network(
                        imageUrl,
                        fit: BoxFit.contain,
                        clearMemoryCacheWhenDispose: false,
                        cache: true,
                        loadStateChanged: (ExtendedImageState state) {
                          switch (state.extendedImageLoadState) {
                            case LoadState.loading:
                              return Container(
                                color: Color(0xff202021),
                                child: Center(child: Text("${name.substring(0,1)}${name.contains(' ') ? name.substring(name.lastIndexOf(" ")+1, name.lastIndexOf(" ")+2) : ""}",  style: Bold.copyWith(color: Colors.white),)),
                              );
                              break;
                            case LoadState.completed:
                              return  ExtendedRawImage(
                                image: state.extendedImageInfo?.image,
                              );
                              break;
                            case LoadState.failed:
                              return Container(
                                color: Color(0xff202021),
                                child: Center(child: Text("${name.substring(0,1)}${name.contains(' ') ? name.substring(name.lastIndexOf(" ")+1, name.lastIndexOf(" ")+2) : ""}",  style: Bold.copyWith(color: Colors.white),)),
                              );
                              break;
                            default: return Container();
                          }
                        },
                      ),
                      borderRadius: BorderRadius.circular(200),
                    ),
                  ),
                  SizedBox(
                    width: 16,
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.transparent,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            name,
                            style: Bold.copyWith(
                                fontSize: 14, color: Colors.white),
                          ),
                          SizedBox(
                            height: 6,
                          ),
                          messageText.replyUrl=="" ?   Text(
                           messageText.message,
                            style: Regular.copyWith(
                                fontSize: 13, color: Color(0xff808185)),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ) : Container(
                            height: 20,
                            child: Row(
                              children: [
                                ClipRRect(
                                  child: ExtendedImage.network(
                                    messageText.replyUrl,
                                    fit: BoxFit.contain,
                                    clearMemoryCacheWhenDispose: false,
                                    cache: true,
                                    loadStateChanged: (ExtendedImageState state) {
                                      switch (state.extendedImageLoadState) {
                                        case LoadState.loading:
                                          return Container();

                                          break;
                                        case LoadState.completed:

                                          return  ExtendedRawImage(
                                            image: state.extendedImageInfo?.image,
                                          );
                                          break;
                                        case LoadState.failed:
                                          return GestureDetector(
                                            child: Center(
                                              child: Container(),
                                            ),
                                          );
                                          break;
                                        default: return Container();
                                      }
                                    },
                                  ),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                SizedBox(width: 4,),
                                Text(
                                  messageText.mediaType=="photo" ? "Photo" : "Gift",
                                  style: Regular.copyWith(
                                      fontSize: 13, color: Color(0xff808185)),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text("$_time",
                    style: Regular.copyWith(
                      fontSize: 12,
                      color: Color(0xff808185),
                    )),
                SizedBox(
                  height: 2,
                ),
                unReadMessageCount==0 ? Container() : Container(
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Color(0xffFF5F0E)
                  ),
                  child: Center(
                    child: Text(
                      unReadMessageCount > 9 ? "9+" :  unReadMessageCount.toString(),
                      style: Bold.copyWith(color: Color(0xffffffff), fontSize: 11),
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}