import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';


class NewChatCard extends StatelessWidget {
final UserModel userModel;
  final Function onTap;
  NewChatCard(
      { @required this.onTap, this.userModel});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Row(
                children: <Widget>[
                  CircleAvatar(
                    backgroundImage: CachedNetworkImageProvider(userModel.profilePhoto),
                    maxRadius: 20,
                  ),
                  SizedBox(
                    width: 16,
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.transparent,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            userModel.firstName,
                            style: Bold.copyWith(
                                fontSize: 14, color: Colors.white),
                          ),
                          Text(
                           userModel.username,
                            style: Regular.copyWith(
                                fontSize: 13, color: Color(0xff808185)),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}