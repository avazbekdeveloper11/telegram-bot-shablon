
import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/services/chat/chat_model/chat_model.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';

class ReplyMessageWidget extends StatelessWidget {
  final SocketMessageModel message;
  final String firstName;
  final VoidCallback onCancelReply;
  final bool input;

  const ReplyMessageWidget({
    @required this.message,
    this.onCancelReply,
    Key key,
    this.firstName,
    this.input,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) => IntrinsicHeight(
    child: Container(
      margin: EdgeInsets.only(bottom: 8),
      color: Colors.transparent,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            color: Color(0xff262626),
            width: 4,
          ),
          const SizedBox(width: 8),
          buildReplyMessage(context, input),
        ],
      ),
    ),
  );

  Widget buildReplyMessage(BuildContext context, bool input) {
  return  !input
      ? Container(
    width: screenWidth(context) - 100,
    padding: EdgeInsets.all(8),
    decoration: BoxDecoration(color: Color(0xff18181A), borderRadius: BorderRadius.circular(12)),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      mainAxisSize: MainAxisSize.min,
      children: [
        Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              firstName,
              style: Regular.copyWith(color: Color(0xffAAABAD), fontSize: 13),
            ),
            const SizedBox(height: 8),
            message.replyUrl!='' ? Container(
              constraints: BoxConstraints(maxHeight: screenHeight(context)/10, maxWidth: screenWidth(context)/5),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: CachedNetworkImage(
                  imageUrl: message.replyUrl,
                  fit: BoxFit.contain,
                  placeholder: (context, url) => Container(height: screenHeight(context)/10,width: screenWidth(context)/5),
                ),
              ),
            ) :   ConstrainedBox(
                constraints: BoxConstraints(minWidth: 30, maxWidth: screenWidth(context) - (input ? 130 : 170)),
                child: Text(
                  message.message,
                  style: Regular.copyWith(color: Color(0xffAAABAD), fontSize: 13),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                )),
          ],
        ),
        Visibility(
          visible: onCancelReply != null,
          child: IconButton(
            icon: Icon(
              Icons.close,
              size: 24,
              color: Color(0xffAAABAD),
            ),
            onPressed: onCancelReply,
          ),
        )
      ],
    ),
  )
      :  message.replyUrl!='' ? Container(
    constraints: BoxConstraints(maxHeight: screenHeight(context)/10, maxWidth: screenWidth(context)/5),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: CachedNetworkImage(
        imageUrl: message.replyUrl,
        fit: BoxFit.contain,
        placeholder: (context, url) => Container(height: screenHeight(context)/10,width: screenWidth(context)/5),
      ),
    ),
  ) :  Container(
    padding: EdgeInsets.all(8),
    decoration: BoxDecoration(color: Color(0xff18181A), borderRadius: BorderRadius.circular(12)),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      mainAxisSize: MainAxisSize.min,
      children: [
        Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              firstName,
              style: Regular.copyWith(color: Color(0xffAAABAD), fontSize: 13),
            ),
            const SizedBox(height: 8),
             ConstrainedBox(
                constraints: BoxConstraints(minWidth: 30, maxWidth: screenWidth(context) - (input ? 130 : 170)),
                child: Text(
                  message.message,
                  style: Regular.copyWith(color: Color(0xffAAABAD), fontSize: 13),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                )),
          ],
        ),
        Visibility(
          visible: onCancelReply != null,
          child: IconButton(
            icon: Icon(
              Icons.close,
              size: 24,
              color: Color(0xffAAABAD),
            ),
            onPressed: onCancelReply,
          ),
        )
      ],
    ),
  );
}}