import 'package:extended_image/extended_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/services/chat/chat_model/chat_model.dart';
import 'package:facetap/services/chat/widgets/reply_message_widget.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart' as intl;
import 'package:scroll_to_index/scroll_to_index.dart';

class MessagesItem extends StatelessWidget {
  final SocketMessageModel message;
  final SocketMessageModel replyMessage;
  final UserModel recipientModel;
  final bool isUserMassage;
  final bool replyMe;
  final bool isGroup;
  final bool read;
  final bool bottom;
  final bool top;
  final int index;
  final AutoScrollController pageController;
  final String imagePath;

  const MessagesItem({
    this.message,
    this.isUserMassage,
    this.recipientModel,
    this.isGroup,
    this.replyMessage,
    this.replyMe,
    this.read,
    this.bottom,
    this.top,
    this.index,
    this.pageController,
    this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 3),
      child: Column(
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            textDirection: isUserMassage ? TextDirection.rtl : TextDirection.ltr,
            children: <Widget>[
              isUserMassage
                  ? SizedBox()
                  : isGroup
                      ? SizedBox(
                          width: 32,
                          height: 32,
                        )
                      : recipientModel.profilePhoto != null
                          ? Container(
                              height: 32,
                              width: 32,
                              child: ClipRRect(
                                child: ExtendedImage.network(
                                  recipientModel.profilePhoto,
                                  fit: BoxFit.contain,
                                  clearMemoryCacheWhenDispose: false,
                                  cache: true,
                                  loadStateChanged: (ExtendedImageState state) {
                                    switch (state.extendedImageLoadState) {
                                      case LoadState.loading:
                                        return Container(
                                          color: Color(0xff202021),
                                          child: Center(
                                              child: Text(
                                            "${recipientModel.firstName.substring(0, 1)}${recipientModel.firstName.contains(' ') ? recipientModel.firstName.substring(recipientModel.firstName.lastIndexOf(" ") + 1, recipientModel.firstName.lastIndexOf(" ") + 2) : ""}",
                                            style: Bold.copyWith(color: Colors.white),
                                          )),
                                        );
                                        break;
                                      case LoadState.completed:
                                        return ExtendedRawImage(
                                          image: state.extendedImageInfo?.image,
                                        );
                                        break;
                                      case LoadState.failed:
                                        return Container(
                                          color: Color(0xff202021),
                                          child: Center(
                                              child: Text(
                                            "${recipientModel.firstName.substring(0, 1)}${recipientModel.firstName.contains(' ') ? recipientModel.firstName.substring(recipientModel.firstName.lastIndexOf(" ") + 1, recipientModel.firstName.lastIndexOf(" ") + 2) : ""}",
                                            style: Bold.copyWith(color: Colors.white),
                                          )),
                                        );
                                        break;
                                      default:
                                        return Container();
                                    }
                                  },
                                ),
                                borderRadius: BorderRadius.circular(200),
                              ),
                            )
                          : Container(
                              width: 32,
                              height: 32,
                              alignment: Alignment.center,
                              child: Text(
                                recipientModel.firstName.substring(0, 1).toUpperCase(),
                                style: Bold.copyWith(
                                  color: Color(0xffFFffff),
                                  fontSize: 16,
                                ),
                              ),
                            ),
              SizedBox(width: 12),
              Container(
                width: MediaQuery.of(context).size.width * .75,
                child: Align(
                  alignment: isUserMassage ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    child: buildMessage(replyMessage, context, index, pageController),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget buildRead(String status) {
    switch (status) {
      case "new":
        return Icon(
          Icons.check,
          color: Color(0x64ffffff),
          size: 14,
        );
      case "read":
        return Icon(
          Icons.done_all,
          color: Color(0x64ffffff),
          size: 14,
        );
      case "unsent":
        return Icon(
          Icons.lock_clock,
          color: Color(0x64ffffff),
          size: 14,
        );
      default:
        return Icon(
          Icons.report_gmailerrorred_outlined,
          color: Color(0x64ffffff),
          size: 14,
        );
    }
  }

  Widget buildMessage(
      SocketMessageModel replyMessage, BuildContext context, int index, AutoScrollController pageController) {
    final messageWidget = message.mediaUrl != ''
        ? message.mediaType != "photo"
            ? Column(
                crossAxisAlignment: isUserMassage ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: EdgeInsets.fromLTRB(4, 4, 4, 0),
                    decoration: BoxDecoration(
                      color: Color(0xffFF5F0E),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ImageShow(
                                        imageUrl: message.mediaUrl,
                                        tag: message.messageId,
                                      )),
                            );
                          },
                          child: Hero(
                            tag: message.messageId,
                            child: Container(
                              constraints: BoxConstraints(
                                  maxHeight: screenHeight(context) / 4, maxWidth: screenWidth(context) / 2.5),
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xffFF5F0E)),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(11),
                                child: ExtendedImage.network(
                                  message.mediaUrl,
                                  fit: BoxFit.contain,
                                  clearMemoryCacheWhenDispose: false,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SvgPicture.asset(Assets.svgFeedRating),
                              SizedBox(width: 8.0),
                              Text("+${message.giftPoints}", style: Bold.copyWith(color: WhiteColor, fontSize: 16.0)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        gradient: LinearGradient(begin: Alignment.centerLeft, stops: [
                          0.5,
                          1
                        ], colors: [
                          isUserMassage ? Color(0xffFF5F0E) : Color(0xff262626),
                          isUserMassage ? Color(0xffBA480F) : Color(0xff262626),
                        ])),
                    child: Wrap(
                      crossAxisAlignment: WrapCrossAlignment.end,
                      alignment: WrapAlignment.end,
                      // crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text(
                          message.message ?? "",
                          style: Regular.copyWith(color: Colors.white, fontSize: 15),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 8),
                              child: Text(
                                "${intl.DateFormat(MediaQuery.of(context).alwaysUse24HourFormat ? 'HH:mm' : 'h:mm a').format(message.time)}",
                                textAlign: TextAlign.end,
                                style: Regular.copyWith(
                                    color: isUserMassage ? Color(0x64ffffff) : Color(0xff808185), fontSize: 11),
                              ),
                            ),
                            isUserMassage ? buildRead(message.status) : Container()
                          ],
                        )
                      ],
                    ),
                  )
                ],
              )
            : GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ImageShow(
                              imageUrl: message.mediaUrl,
                              tag: message.messageId,
                            )),
                  );
                },
                child: Hero(
                  tag: message.messageId,
                  child: Container(
                    constraints:
                        BoxConstraints(maxHeight: screenHeight(context) / 3, maxWidth: screenWidth(context) / 2),
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xffFF5F0E)),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(11),
                      child: ExtendedImage.network(
                        message.mediaUrl,
                        clearMemoryCacheWhenDispose: false,
                        fit: BoxFit.contain,
                        cache: true,
                        loadStateChanged: (ExtendedImageState state) {
                          switch (state.extendedImageLoadState) {
                            case LoadState.loading:
                              return Center(
                                child: CircularProgressIndicator(),
                              );
                              break;
                            case LoadState.completed:
                              return ExtendedRawImage(
                                image: state.extendedImageInfo?.image,
                              );
                              break;
                            case LoadState.failed:
                              return GestureDetector(
                                child: Center(
                                  child: CircularProgressIndicator(),
                                ),
                              );
                              break;
                            default:
                              return Container();
                          }
                        },
                      ),
                    ),
                  ),
                ),
              )
        : Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(isUserMassage
                      ? top
                          ? 12
                          : 4
                      : 12),
                  bottomRight: Radius.circular(isUserMassage
                      ? bottom
                          ? 12
                          : 4
                      : 12),
                  topLeft: Radius.circular(isUserMassage
                      ? 12
                      : top
                          ? 12
                          : 4),
                  bottomLeft: Radius.circular(isUserMassage
                      ? 12
                      : bottom
                          ? 12
                          : 4),
                ),
                gradient: LinearGradient(begin: Alignment.centerLeft, stops: [
                  0.5,
                  1
                ], colors: [
                  isUserMassage ? Color(0xffFF5F0E) : Color(0xff262626),
                  isUserMassage ? Color(0xffBA480F) : Color(0xff262626),
                ])),
            child: Wrap(
              crossAxisAlignment: WrapCrossAlignment.end,
              alignment: WrapAlignment.end,
              // crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(
                  message.message ?? "",
                  style: Regular.copyWith(color: Colors.white, fontSize: 15),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        "${intl.DateFormat(MediaQuery.of(context).alwaysUse24HourFormat ? 'HH:mm' : 'h:mm a').format(message.time)}",
                        textAlign: TextAlign.end,
                        style: Regular.copyWith(
                            color: isUserMassage ? Color(0x64ffffff) : Color(0xff808185), fontSize: 11),
                      ),
                    ),
                    isUserMassage ? buildRead(message.status) : Container()
                  ],
                )
              ],
            ),
          );

    if (replyMessage == null) {
      return messageWidget;
    } else {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: isUserMassage ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: <Widget>[
          GestureDetector(
              onTap: () async {
                await pageController.scrollToIndex(index, preferPosition: AutoScrollPosition.middle);
                pageController.highlight(index);
              },
              child: buildReplyMessage(replyMessage)),
          messageWidget,
        ],
      );
    }
  }

  Widget buildReplyMessage(SocketMessageModel replyMessage) {
    final isReplying = replyMessage != null;

    if (!isReplying) {
      return Container();
    } else {
      return Container(
        color: Colors.transparent,
        child: ReplyMessageWidget(
          message: replyMessage,
          firstName: replyMe ? "you" : recipientModel.firstName,
          input: true,
        ),
      );
    }
  }
}

class ImageShow extends StatelessWidget {
  final String imageUrl;
  final String tag;

  const ImageShow({Key key, this.imageUrl, this.tag}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff0A0A0A),
      body: Stack(
        children: [
          ExtendedImageGesturePageView.builder(
            itemBuilder: (BuildContext context, int index) {
              Widget image = ExtendedImage.network(
                imageUrl,
                fit: BoxFit.contain,
                mode: ExtendedImageMode.gesture,
              );
              image = Container(
                child: image,
                padding: EdgeInsets.all(5.0),
              );

              return Hero(
                tag: tag,
                child: image,
              );
            },
            itemCount: 1,
            onPageChanged: (int index) {},
            controller: ExtendedPageController(
              initialPage: 0,
            ),
            scrollDirection: Axis.horizontal,
          ),
          Align(
            alignment: Alignment.topLeft,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 28),
              child: IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: Icon(
                    Icons.arrow_back_ios,
                    color: Colors.white,
                  )),
            ),
          )
        ],
      ),
    );
  }
}
