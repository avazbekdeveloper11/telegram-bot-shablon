import 'dart:async';

import 'package:facetap/apis/errors.dart';
import 'package:facetap/global_widgets/views/infinite_list_empty.dart';
import 'package:facetap/global_widgets/views/search_widget.dart';
import 'package:facetap/models/create_chat_model.dart';
import 'package:facetap/models/error_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/services/chat/chat_model/chat_model.dart';
import 'package:facetap/services/chat/chat_page.dart';
import 'package:facetap/services/chat/widgets/new_chat_card.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/dependancy_injection.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class NewChat extends StatefulWidget {
  final String userId;

  const NewChat({
    Key key,
    this.userId,
  }) : super(key: key);

  @override
  _NewChatState createState() => _NewChatState();
}

class _NewChatState extends State<NewChat> {
  PagingController pagingController = PagingController<int, UserModel>(firstPageKey: 1);
  final UserModel _userModel = locator<UserModel>();
  bool loading = false;
  String _search;
  Timer _searchTimer;
  TextEditingController searchController = TextEditingController();


  @override
  void initState() {
    print(widget.userId);
    pagingController.addPageRequestListener((pageKey) {
      print(pageKey);
      fetchFollowing(pageKey);
    }); // TODO: implement initState
    super.initState();
  }

  void onSearchChanged(String value) {
    if (_searchTimer != null) _searchTimer.cancel();
    _searchTimer = Timer(Duration(milliseconds: 500), () {
      _search = value;
      fetchFollowing(1);
    });
  }

  fetchFollowing(int pageKey) async {
    if (pageKey == 1) pagingController?.itemList?.clear();
    try {
      final _response = await UserService()
          .userFollowing(userId: widget.userId, page: pageKey, limit: 20, search: _search ?? '')
          .onError((error, stackTrace) => onError(error));
      final isLastPage =
          (pagingController.itemList ?? []).length == _response.count || (_response.results ?? []).isEmpty;
      isLastPage
          ? pagingController.appendLastPage(_response.results)
          : pagingController.appendPage(_response.results, pageKey + 1);
    } catch (error) {
      pagingController.error = error;
    }
  }

  Future<T> onError<T extends Object>(dynamic error) {
    if (error is ErrorModel) showSnackbar(error.error.message);

    if (error == ApiClientErrors.UNKNOWN_ERROR) showSnackbar('Error occured, please try again.');
    if (error == ApiClientErrors.NOT_FOUND) showSnackbar('Error occured, please try again.');
    if (error == ApiClientErrors.SERVER_ERROR) showSnackbar('We are experiencing server side error, please try again.');
    return null;
  }

  void showSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(
            message,
            style: Regular.copyWith(color: BlackColor),
          ),
          backgroundColor: WhiteColor),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff0A0A0A),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios,
            size: 16,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        actions: [
          SizedBox(
            width: 48,
          )
        ],
        title: Center(child: Text("New chat")),
      ),
      body: loading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      "Following",
                      style: Regular.copyWith(color: Color(0xff808185), fontSize: 13),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 16),
                    width: double.infinity,
                    height: 42.0,
                    child: SearchWidget(
                      controller: searchController,
                      onEditingComplete: () {},
                      onTap: () {onSearchChanged(''); searchController.clear(); },
                      hintText: 'Search',
                      onChangedSuffix: (value) => onSearchChanged(value),
                    ),
                  ),
                  buildAllChatList(),
                ],
              ),
            ),
    );
  }

  onMessageTap(UserModel profile) async {
    setState(() {
      loading = true;
    });
    CreateChatModel _response =
        await UserService().createChatService(receiverId: profile.id).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => ChatPage(
              SocketMessageModel(
                  roomId: _response.roomId,
                  newChat: _response.newCreated,
                  recipientId: profile.id,
                  senderId: _userModel.id),
              profile,
              _userModel.accessToken)));
    } else {}
    setState(() {
      loading = false;
    });
  }

  Widget buildAllChatList() {
    return PagedListView<int, UserModel>(
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      pagingController: pagingController,
      builderDelegate: PagedChildBuilderDelegate<UserModel>(
        itemBuilder: (context, item, index) => NewChatCard(
          onTap: () {
            onMessageTap(item);
          },
          userModel: item,
        ),
        firstPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
        newPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
        noItemsFoundIndicatorBuilder: (_) => InfiniteListEmptyItem(),
      ),
    );
  }
}
