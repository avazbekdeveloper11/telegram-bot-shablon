import 'package:facetap/apis/errors.dart';
import 'package:facetap/global_widgets/views/infinite_list_empty.dart';
import 'package:facetap/models/error_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/notification_page/views/notification_page.dart';
import 'package:facetap/services/chat/chat_model/chat_model.dart';
import 'package:facetap/services/chat/chat_page.dart';
import 'package:facetap/services/chat/new_chat.dart';
import 'package:facetap/services/chat/widgets/conversation_list.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class AllChatsPage extends StatefulWidget {
  final String accessToken;
  final String userId;
  final String roomId;

  const AllChatsPage({
    Key key,
    @required this.accessToken,
    @required this.userId,
    this.roomId,
  }) : super(key: key);

  @override
  _AllChatsPageState createState() => _AllChatsPageState();
}

class _AllChatsPageState extends State<AllChatsPage> {
  PagingController pagingController = PagingController<int, RoomModel>(firstPageKey: 1);
  PostsService postsService = PostsService();
String roomId='';
  @override
  void initState() {
    if(roomId!=""){
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.push(context, MaterialPageRoute(builder: (_)=>NotificationPage()));
      });
    }
    roomId=widget.roomId;
    pagingController.addPageRequestListener((pageKey) {
      onWebSocket(pageKey);
    });
    super.initState();
  }

  @override
  void dispose() {
    pagingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff0A0A0A),
      appBar: AppBar(
        bottom: PreferredSize(
            child: Container(
              color: Color(0xff272727),
              height: 1.0,
            ),
            preferredSize: Size.fromHeight(4.0)),
        elevation: 0,
        backgroundColor: Colors.transparent,
        leading: IconButton(onPressed:(){
         Navigator.push(context, MaterialPageRoute(builder: (_)=> NotificationPage(
         ),));
        }, icon: SizedBox(
          height: 24, width: 24,
          child: Stack(
            children: [
              Align(
                  alignment: Alignment.bottomCenter,
                  child: SvgPicture.asset("assets/svg/message.svg", height: 20, width: 30,)),
              Visibility(
                visible: false,
                child: Align(
                  alignment: Alignment.topRight,
                  child: Container(
                    height: 8,
                    width: 8,
                    decoration: BoxDecoration(
                        color: Color(0xffEE505A),
                        shape: BoxShape.circle
                    ),
                  ),
                ),
              )
            ],
          ),
        )),
        centerTitle: true,
        actions: [
          IconButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => NewChat(
                          userId: widget.userId,
                        )));
              },
              icon: Icon(Icons.add)),
        ],
        title: Center(child: Text("Messages")),
      ),
      body: buildAllChatList(),
    );
  }

  void showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(
            message,
            style: Regular.copyWith(color: BlackColor),
          ),
          backgroundColor: WhiteColor),
    );
  }

  Future<T> onError<T extends Object>(dynamic error) {
    if (error is ErrorModel) showSnackBar(error.error.message);

    if (error == ApiClientErrors.UNKNOWN_ERROR) showSnackBar('Error occured, please try again.');
    if (error == ApiClientErrors.NOT_FOUND) showSnackBar('Error occured, please try again.');
    if (error == ApiClientErrors.SERVER_ERROR) showSnackBar('We are experiencing server side error, please try again.');
    return null;
  }

  onWebSocket(int pageKey) async {
    List<RoomModel> rooms = [];
    print(1);
    if (pageKey == 1) {
      pagingController?.itemList?.clear();
    }
    final _response = await postsService.getChatRooms(pageKey, 20).onError((error, stackTrace) => onError(error));

    print(2);
    pageKey++;
    if (_response != null) {
      rooms = _response.rooms;
      rooms.length != 0 ? pagingController.appendLastPage(rooms) : pagingController.appendPage(rooms, pageKey + 1);
    } else {
      pagingController.appendLastPage(rooms);
    }
  }

  Widget buildAllChatList() {
    return PagedListView<int, RoomModel>(
      pagingController: pagingController,
      builderDelegate: PagedChildBuilderDelegate<RoomModel>(
        itemBuilder: (context, item, index) {
          if (roomId == item.id) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => ChatPage(
                      SocketMessageModel(
                          roomId: item.id,
                          newChat: false,
                          recipientId: item.userId,
                          senderId: widget.userId,
                          replyUrl: item.replyUrl,
                          mediaType: item.mediaType),
                      UserModel(profilePhoto: item.profilePhoto, firstName: item.fullName, id: item.userId),
                      widget.accessToken))).then((value) {
                        roomId="";
                print(677667);
                pagingController.refresh();
              });
            });
          }
          return ConversationList(
            onTap: () {
              print(item.profilePhoto);
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => ChatPage(
                          SocketMessageModel(
                              roomId: item.id,
                              newChat: false,
                              recipientId: item.userId,
                              senderId: widget.userId,
                              replyUrl: item.replyUrl,
                              mediaType: item.mediaType),
                          UserModel(profilePhoto: item.profilePhoto, firstName: item.fullName, id: item.userId),
                          widget.accessToken))).then((value) {
                print(677667);
                pagingController.refresh();
              });
            },
            unReadMessageCount: item.unreadCount,
            name: item.fullName,
            messageText: item.lastMessage,
            imageUrl: item.profilePhoto,
            time: item.lastMessage.time,
          );
        },
        firstPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
        newPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
        noItemsFoundIndicatorBuilder: (_) => InfiniteListEmptyItem(),
      ),
    );
  }
}
