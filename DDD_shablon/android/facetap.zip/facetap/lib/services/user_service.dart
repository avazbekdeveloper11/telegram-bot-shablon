import 'dart:convert';

import 'package:facetap/apis/apis.dart';
import 'package:facetap/apis/errors.dart';
import 'package:facetap/models/blocked_users_model.dart';
import 'package:facetap/models/create_chat_model.dart';
import 'package:facetap/models/error_model.dart';
import 'package:facetap/models/follows_model.dart';
import 'package:facetap/models/interest_model.dart';
import 'package:facetap/models/notifications_model.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/register_model.dart';
import 'package:facetap/models/reports_model.dart';
import 'package:facetap/models/share_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/models/vote_cards_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';

class UserService {
  final ApiClient _apiClient = locator<ApiClient>();

  Future<T> _onApiCallback<T extends Object>(
      {@required Response response,
      Future<T> Function(ErrorModel) onError,
      @required Future<T> Function(Map<String, dynamic>) onSuccess,
      int successCode = 200}) async {
    print('\n=====\nresponse => ${response.statusCode} ${response.request}');
    print('${response.body}');
    print('=====\n\n');
    if (response.statusCode == successCode)
      return onSuccess != null ? onSuccess.call(jsonDecode(response.body)) : Future.error(ApiClientErrors.NO_SUCCESS_BODY_FOUND);

    return onError.call(ErrorModel.fromJson(jsonDecode(response.body)));
  }

  Future<UserModel> getProfile({@required String userId}) async {
    try {
      Response response = await _apiClient.getProfile(userId);

      Future<UserModel> _onSuccess(Map<String, dynamic> body) async {
        UserModel model = UserModel.fromProfileJson(body);
        return model;
      }

      Future<UserModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<UserModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<CreateChatModel> createChatService({@required String receiverId}) async {
    try {
      Response response = await _apiClient.createUserChat(receiverId);

      Future<CreateChatModel> _onSuccess(Map<String, dynamic> body) async {
        CreateChatModel model = CreateChatModel.fromJson(body);
        return model;
      }

      Future<CreateChatModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<CreateChatModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<UserModel> getProfileByLink({@required Uri uri}) async {
    try {
      Response response = await _apiClient.getProfileByLink(uri);

      Future<UserModel> _onSuccess(Map<String, dynamic> body) async {
        UserModel model = UserModel.fromProfileJson(body);
        return model;
      }

      Future<UserModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<UserModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<UserModel> updateProfile({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.updateProfile(data);

      Future<UserModel> _onSuccess(Map<String, dynamic> body) async {
        UserModel model = UserModel.fromUpdateJson(body);
        return model;
      }

      Future<UserModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<UserModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<RegisterModel> updateEmail({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.updateEmail(data);

      Future<RegisterModel> _onSuccess(Map<String, dynamic> body) async {
        RegisterModel model = RegisterModel.fromJson(body);
        return model;
      }

      Future<RegisterModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<RegisterModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<FollowersModel> userFollowers({@required String userId, @required int page, @required int limit, @required String search}) async {
    try {
      Response response = await _apiClient.userFollowers(userId, page, limit, search);

      Future<FollowersModel> _onSuccess(Map<String, dynamic> body) async {
        FollowersModel model = FollowersModel.fromJson(body);
        print(model);
        return model;
      }

      Future<FollowersModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<FollowersModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<FollowingModel> userFollowing({@required String userId, @required int page, @required int limit, @required String search}) async {
    try {
      Response response = await _apiClient.userFollowing(userId, page, limit, search);

      Future<FollowingModel> _onSuccess(Map<String, dynamic> body) async {
        FollowingModel model = FollowingModel.fromJson(body);
        return model;
      }

      Future<FollowingModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<FollowingModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> follow({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.follow(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> unfollow({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.unfollow(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> removeFollower({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.removeFollower(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> block({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.block(data);
      print(response.statusCode);
      if (response.statusCode == 200) {
        return true;
      }
      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> unblock({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.unblock(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<BlockedUsersModel> getBlockedUsers({@required int page, @required int limit, @required String search}) async {
    try {
      Response response = await _apiClient.getBlockedUsers(page, limit, search);

      Future<BlockedUsersModel> _onSuccess(Map<String, dynamic> body) async {
        BlockedUsersModel model = BlockedUsersModel.fromJson(body);
        return model;
      }

      Future<BlockedUsersModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<BlockedUsersModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<PostsModel> getUserPosts({@required String userId, @required int page, @required int limit}) async {
    try {
      Response response = await _apiClient.getUserPosts(userId, page, limit);

      Future<PostsModel> _onSuccess(Map<String, dynamic> body) async {
        PostsModel model = PostsModel.fromJson(body);
        return model;
      }

      Future<PostsModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<PostsModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<NotificationsModel> getNotifications({@required int page, @required int limit}) async {
    try {
      Response response = await _apiClient.getNotifications(page, limit);

      Future<NotificationsModel> _onSuccess(Map<String, dynamic> body) async {
        NotificationsModel model = NotificationsModel.fromJson(body);
        return model;
      }

      Future<NotificationsModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<InterestListModel> getInterestService() async {
    try {
      Response response = await _apiClient.getInterestGet();

      Future<InterestListModel> _onSuccess(Map<String, dynamic> body) async {
        InterestListModel model = InterestListModel.fromJson(body);
        return model;
      }

      Future<InterestListModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<InterestListModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> updateInterests({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.updateInterests(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<ShareModel> getProfileLink({@required String userId}) async {
    try {
      Response response = await _apiClient.getProfileLink(userId);

      Future<ShareModel> _onSuccess(Map<String, dynamic> body) async {
        ShareModel model = ShareModel.fromJson(body);
        return model;
      }

      Future<ShareModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<ShareModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<ShareModel> getPostLink({@required String postId}) async {
    try {
      Response response = await _apiClient.getPostLink(postId);

      Future<ShareModel> _onSuccess(Map<String, dynamic> body) async {
        ShareModel model = ShareModel.fromJson(body);
        return model;
      }

      Future<ShareModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<ShareModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<ReportTypesModel> reportUserTypes({@required int page, @required int limit}) async {
    try {
      Response response = await _apiClient.reportUserTypes(page, limit);

      Future<ReportTypesModel> _onSuccess(Map<String, dynamic> body) async {
        ReportTypesModel model = ReportTypesModel.fromJson(body);
        return model;
      }

      Future<ReportTypesModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<ReportTypesModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> reportUser({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.reportUser(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<VoteCardsModel> getVoteCards({@required int page, @required int limit}) async {
    try {
      Response response = await _apiClient.getVoteCards(page, limit);

      Future<VoteCardsModel> _onSuccess(Map<String, dynamic> body) async {
        return VoteCardsModel.fromJson(body);
      }

      Future<VoteCardsModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> createPayment(Map<String, dynamic> data) async {
    try {
      Response response = await _apiClient.createPayment(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<UserVotes> getUserVotes() async {
    try {
      Response response = await _apiClient.getUserVotes();

      Future<UserVotes> _onSuccess(Map<String, dynamic> body) async {
        return UserVotes.fromJson(body);
      }

      Future<UserVotes> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }
}
