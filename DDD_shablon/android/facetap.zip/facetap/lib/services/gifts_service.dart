import 'dart:convert';

import 'package:facetap/apis/apis.dart';
import 'package:facetap/apis/errors.dart';
import 'package:facetap/models/error_model.dart';
import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';

class GiftsService {
  final ApiClient _apiClient = locator<ApiClient>();

  Future<T> _onApiCallback<T extends Object>(
      {@required Response response,
      Future<T> Function(ErrorModel) onError,
      @required Future<T> Function(Map<String, dynamic>) onSuccess,
      int successCode = 200}) async {
    print('\n=====\nresponse => ${response.statusCode} ${response.request}');
    print('${response.body}');
    print('=====\n\n');
    if (response.statusCode == successCode)
      return onSuccess != null ? onSuccess.call(jsonDecode(response.body)) : Future.error(ApiClientErrors.NO_SUCCESS_BODY_FOUND);

    return onError.call(ErrorModel.fromJson(jsonDecode(response.body)));
  }

  Future<AllGiftsModel> getAllGifts({@required int categories, @required int items}) async {
    try {
      Response response = await _apiClient.getAllGifts(categories, items);

      Future<AllGiftsModel> _onSuccess(Map<String, dynamic> body) async {
        AllGiftsModel model = AllGiftsModel.fromJson(body);
        return model;
      }

      Future<AllGiftsModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<AllGiftsModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<UserGiftsModel> getUserGifts({@required String userId, @required int page, @required int limit}) async {
    try {
      Response response = await _apiClient.getUserGifts(userId, page, limit);

      Future<UserGiftsModel> _onSuccess(Map<String, dynamic> body) async {
        UserGiftsModel model = UserGiftsModel.fromJson(body);
        return model;
      }

      Future<UserGiftsModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<UserGiftsModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<BoughtGiftModel> buyGift({@required String giftTempId}) async {
    try {
      Response response = await _apiClient.buyGift(giftTempId);

      Future<BoughtGiftModel> _onSuccess(Map<String, dynamic> body) async {
        BoughtGiftModel model = BoughtGiftModel.fromJson(body);
        return model;
      }

      Future<BoughtGiftModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<BoughtGiftModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<bool> sendGift({@required Map<String, dynamic> data}) async {
    try {
      Response response = await _apiClient.sendGift(data);

      Future<bool> _onSuccess(Map<String, dynamic> body) async {
        return true;
      }

      Future<bool> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<bool>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }

  Future<MyGiftModel> getGift({@required String giftId}) async {
    try {
      Response response = await _apiClient.getGift(giftId);

      Future<MyGiftModel> _onSuccess(Map<String, dynamic> body) async {
        MyGiftModel model = MyGiftModel.fromJson(body);
        return model;
      }

      Future<MyGiftModel> _error(ErrorModel error) async {
        return Future.error(error);
      }

      return _onApiCallback<MyGiftModel>(response: response, onSuccess: _onSuccess, onError: _error);
    } catch (e) {
      return Future.error(ApiClientErrors.UNKNOWN_ERROR);
    }
  }
}
