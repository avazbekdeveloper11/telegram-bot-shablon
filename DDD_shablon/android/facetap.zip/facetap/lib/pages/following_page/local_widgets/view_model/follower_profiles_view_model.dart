import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/profile_page/views/profile_page.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class FollowerProfilesViewModel extends BaseViewModel {
  final UserModel _userModel = locator<UserModel>();

  onNavigationProfilePage(String id) {
    navigationService.push(MaterialPageRoute(builder: (_) => ProfilePage(userId: id, isNavigatorPop: true)));
  }

  bool isMyProfile(String id) => id == _userModel.id;
}
