import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class FollowingViewModel extends BaseViewModel {
  TabController tabController;

  onBackPressed() => navigationService.pop();

  void initData(int index, _followingPageState) {
    tabController = TabController(length: 2, vsync: _followingPageState);
    tabController.index = index;
    super.initState();
  }
}
