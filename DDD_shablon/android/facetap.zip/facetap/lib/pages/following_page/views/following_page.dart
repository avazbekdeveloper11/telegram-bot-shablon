import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/following_page/view_model/following_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '../local_widgets/views/follower_screen.dart';
import '../local_widgets/views/following_screen.dart';

class FollowingPage extends StatefulWidget {
  final UserModel profile;
  final int index;

  FollowingPage({Key key, this.profile, this.index}) : super(key: key);

  @override
  _FollowingPageState createState() => _FollowingPageState();
}

class _FollowingPageState extends State<FollowingPage> with SingleTickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<FollowingViewModel>.reactive(
      initState: (model) => model.initData(widget.index, this),
      viewModelBuilder: () => FollowingViewModel(),
      builder: (context, model, _) {
        return Scaffold(
          backgroundColor: DarkWindowColor,
          appBar: AppBar(
            centerTitle: true,
            title: Text("@${widget.profile.username}", style: Regular),
            leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
            elevation: 0,
            backgroundColor: Transparent,
            bottom: TabBar(
                isScrollable: false,
                indicatorColor: WhiteColor,
                controller: model.tabController,
                labelStyle: Medium.copyWith(fontSize: 16.0),
                unselectedLabelColor: WhiteColor.withOpacity(0.5),
                tabs: [
                  Tab(text: 'FOLLOWING', iconMargin: EdgeInsets.zero),
                  Tab(text: 'FOLLOWERS', iconMargin: EdgeInsets.zero),
                ]),
          ),
          body: TabBarView(
            controller: model.tabController,
            children: [FollowingScreen(profile: widget.profile), FollowerScreen(profile: widget.profile)],
          ),
        );
      },
    );
  }
}
