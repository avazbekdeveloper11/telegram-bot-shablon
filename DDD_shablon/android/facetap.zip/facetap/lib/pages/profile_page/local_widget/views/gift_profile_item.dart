import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/profile_page/local_widget/view_models/gift_profile_item_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class GiftProfileItem extends StatelessWidget {
  final MyGiftModel gift;
  final UserModel profile;
  final Function updateNeed;

  const GiftProfileItem({Key key, this.gift, this.profile, this.updateNeed}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<GiftProfileItemViewModel>.reactive(
      initState: (model) => model.initData(updateNeed),
      viewModelBuilder: () => GiftProfileItemViewModel(),
      builder: (context, model, _) {
        return GestureDetector(
          onTap: () => model.onGiftPressed(gift, profile),
          child: Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(12.0), color: gift.id.isEmpty ? GrayColor : Transparent),
            height: screenWidth(context) / 2,
            alignment: Alignment.center,
            child: gift.id.isNotEmpty
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12.0),
                          child: CachedNetworkImage(
                            imageUrl: gift.giftTemp.image.mediaUrl,
                            fit: BoxFit.cover,
                            placeholder: (context, url) => Container(color: PrimaryLightColor),
                          ),
                        ),
                      ),
                      SizedBox(height: 4.0),
                      Text(gift.message, style: Regular.copyWith(color: WhiteColor, fontSize: 13.0), maxLines: 1, overflow: TextOverflow.ellipsis),
                      SizedBox(height: 4.0),
                      Text('💥${gift.giftTemp.receiverPoints}', style: Regular.copyWith(color: WhiteColor, fontSize: 13.0)),
                      SizedBox(height: 4.0),
                    ],
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 24.0),
                          child: SvgPicture.asset(Assets.svgTabGifts, width: 32.0, height: 32.0),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(bottomRight: Radius.circular(12.0), bottomLeft: Radius.circular(12.0)),
                          color: AccentColor,
                        ),
                        alignment: Alignment.center,
                        padding: EdgeInsets.symmetric(vertical: 4.0),
                        margin: EdgeInsets.only(top: 12.0),
                        child: Text('Buy gift', style: Medium.copyWith(color: WhiteColor, fontSize: 13.0)),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }
}
