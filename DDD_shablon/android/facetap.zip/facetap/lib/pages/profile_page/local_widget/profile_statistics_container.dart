import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/formatter.dart';
import 'package:flutter/material.dart';

class ProfileStatisticsContainer extends StatelessWidget {
  final int statistics;
  final String nameStatistics;

  const ProfileStatisticsContainer({Key key, this.statistics, this.nameStatistics}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          '${formatAmount(statistics)}',
          style: Medium.copyWith(fontSize: 27.0, color: WhiteColor),
        ),
        Text('$nameStatistics', style: Medium.copyWith(fontSize: 14.0, color: WhiteColor.withOpacity(0.6)))
      ],
    );
  }
}
