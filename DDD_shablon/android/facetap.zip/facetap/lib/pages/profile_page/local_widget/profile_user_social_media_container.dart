import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class ProfileUserSocialMediaContainer extends StatelessWidget {
  final String iconName;
  final String nikiName;

  const ProfileUserSocialMediaContainer({Key key, @required this.iconName, @required this.nikiName}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SvgPicture.asset(iconName),
        Text(
          nikiName,
          style: Medium.copyWith(fontSize: 14.0, color: WhiteColor.withOpacity(0.6)),
        )
      ],
    );
  }
}
