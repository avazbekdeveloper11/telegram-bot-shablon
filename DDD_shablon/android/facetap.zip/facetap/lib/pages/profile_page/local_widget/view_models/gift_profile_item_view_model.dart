import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/gift_page/views/gifts_page.dart';
import 'package:facetap/pages/gift_page/views/view_gift_page.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class GiftProfileItemViewModel extends BaseViewModel {
  Function updateNeed;

  initData(Function updateNeed) {
    this.updateNeed = updateNeed;
    super.initState();
  }

  onGiftPressed(MyGiftModel gift, UserModel profile) async {
    if (gift.id.isNotEmpty) {
      navigationService.push(MaterialPageRoute(builder: (_) => ViewGiftPage(gift: gift)));
    } else {
      GiftTempsModel giftTempsModel = await navigationService.push(MaterialPageRoute(builder: (_) => GiftsPage(profile: profile)));
      updateNeed(giftTempsModel);
    }
  }
}
