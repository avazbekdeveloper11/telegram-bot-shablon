import 'dart:async';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/views/round_button.dart';
import 'package:facetap/models/create_chat_model.dart';
import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/reports_model.dart';
import 'package:facetap/models/scheme_model.dart';
import 'package:facetap/models/share_model.dart';
import 'package:facetap/models/upload_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/content_page/views/view_post_page.dart';
import 'package:facetap/pages/edit_profile_page/views/edit_profile_page.dart';
import 'package:facetap/pages/following_page/views/following_page.dart';
import 'package:facetap/pages/gift_page/views/gifts_page.dart';
import 'package:facetap/pages/saved_posts_page/views/saved_posts_page.dart';
import 'package:facetap/pages/settings_page/local_widget/views/settings_templates.dart';
import 'package:facetap/pages/settings_page/views/settings_page.dart';
import 'package:facetap/providers/base_class_provider.dart';
import 'package:facetap/services/cache_service.dart';
import 'package:facetap/services/chat/chat_model/chat_model.dart';
import 'package:facetap/services/chat/chat_page.dart';
import 'package:facetap/services/gifts_service.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:facetap/utils/validators.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_appavailability/flutter_appavailability.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_uploader/flutter_uploader.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:path/path.dart';
import 'package:share_options/share_options.dart';

class ProfileViewModel extends BaseViewModel {
  final UserModel _userModel = locator<UserModel>();
  final UserService _userService = locator<UserService>();
  final GiftsService _giftsService = locator<GiftsService>();
  final CacheService _cacheService = locator<CacheService>();
  final UploadModel uploadModel = locator<UploadModel>();
  final PostsService _postsService = locator<PostsService>();

  final limit = 20;

  TabController tabController;
  ScrollController scrollController;
  double opacity = 0;
  double opacityTwo = 0;
  double opacityTwoColor = 0;
  String userId;
  UserModel profile = UserModel();
  int tabLength = 2;
  PagingController postsPagingController = PagingController<int, PostModel>(firstPageKey: 1);
  PagingController giftsPagingController = PagingController<int, MyGiftModel>(firstPageKey: 1);
  List<ShareOption> shareOptions = [];
  List<SchemeModel> shareOptionsIOS = [];
  List<String> usersIHaveSubscribed = [];
  List<ReportTypeModel> reportTypes = [];

  FlutterUploader uploader = FlutterUploader();
  StreamSubscription progressSubscription;
  StreamSubscription resultSubscription;
  Map<String, UploadItem> tasks = {};

  void initData(_profilePageState, String userId) async {
    this.userId = userId ?? _userModel.id;
    tabController = TabController(length: tabLength, vsync: _profilePageState);
    scrollController = ScrollController();
    scrollController.addListener(scrollListener);
    isMyProfile() ? profile = _userModel : setState(LoadingState.loading);

    fetchProfile();
    postsPagingController.addPageRequestListener((pageKey) => fetchPosts(pageKey));
    giftsPagingController.addPageRequestListener((pageKey) => fetchGifts(pageKey));
    if (uploadModel != null && uploadModel.mediaUrl != null && uploadModel.mediaUrl.isNotEmpty && uploadModel.mediaUrl != "") {
      progressSubscription = uploader.progress.listen((progress) {
        final task = tasks[progress.tag];
        print("progress: ${progress.progress} , tag: ${progress.tag}");
        if (task == null) return;
        if (task.isCompleted()) return;
          tasks[progress.tag] =
              task.copyWith(progress: progress.progress, status: progress.status);
      notifyListeners();
      });
      resultSubscription = uploader.result.listen((result) {
        print(
            "id: ${result.taskId}, status: ${result.status}, response: ${result.response}, statusCode: ${result.statusCode}, tag: ${result.tag}, headers: ${result.headers}");

        final task = tasks[result.tag];
        if (task == null) return;

          tasks[result.tag] = task.copyWith(status: result.status);
        notifyListeners();
      }, onError: (ex, stacktrace) {
        print("exception: $ex");
        print("stacktrace: $stacktrace" ?? "no stacktrace");
        final exp = ex as UploadException;
        final task = tasks[exp.tag];
        if (task == null) return;
        tasks[exp.tag] = task.copyWith(status: exp.status);
        notifyListeners();
      });
      getImage();
    }
    if (shareOptionsIOS.length <= 1) {
      shareOptionsIOS.clear();
      shareOptionsIOS.add(null);
      schemas.forEach((element) async {
        try {
          var availability = await AppAvailability.checkAvailability(element.scheme);
          print('===== scheme $element: ${availability['package_name']}');
          shareOptionsIOS.add(element);
        } catch (e) {
          print((e as PlatformException).message);
        }
      });
    }
    super.initState();
  }

  @override
  void onDispose() {
    scrollController.removeListener(scrollListener);
    tabController.dispose();
    scrollController.dispose();
    postsPagingController.dispose();
    giftsPagingController.dispose();
    progressSubscription?.cancel();
    resultSubscription?.cancel();
    super.onDispose();
  }

  void scrollListener() {
    opacity = (scrollController.position.pixels) / scrollController.position.maxScrollExtent;
    opacityTwo = (scrollController.position.pixels) / scrollController.position.maxScrollExtent;

    opacity > 0.79 ? opacity = 1 : opacity = 0;

    if (opacityTwo > 0.79) {
      opacityTwoColor = 1;
    } else if (opacityTwo > 0.789) {
      opacityTwoColor = 0.7;
    } else if (opacityTwo > 0.785) {
      opacityTwoColor = 0.5;
    } else if (opacityTwo > 0.781) {
      opacityTwoColor = 0.3;
    } else if (opacityTwo > 0.777) {
      opacityTwoColor = 0.1;
    } else if (opacityTwo > 0.773) {
      opacityTwoColor = 0.05;
    } else if (opacityTwo < 0.773) {
      opacityTwoColor = 0.0;
    }
    notifyListeners();
  }

  onMenuPressed() => isMyProfile() ? navigationService.push(MaterialPageRoute(builder: (_) => SettingsPage())) : shareProfile();

  onViewPostClicked(PostModel post) async {
    bool _isNeedUpdate = await navigationService.push(MaterialPageRoute(builder: (_) => ViewPostPage(isNavigatorPop: true, post: post)));
    if (_isNeedUpdate) fetchProfile();
  }

  shareProfile() async {
    if (profile.share == null) {
      setState(LoadingState.loading);
      ShareModel _response = await _userService.getProfileLink(userId: profile.id).onError((error, stackTrace) => onError(error));
      if (_response != null) {
        profile.share = _response.url;
        notifyListeners();
      }
    }
    if (Platform.isAndroid) {
      if (shareOptions.length <= 1) {
        shareOptions.clear();
        shareOptions.add(null);
        final options = await ShareOptions.getTextShareOptions('Check out facetap profile ${profile.share}', subject: 'Facetap Profile');
        options.forEach((element) {
          if (checkSocialOccurrences(element.activityInfo.packageName) || checkSocialOccurrences(element.activityInfo.className))
            shareOptions.add(element);
        });
      }
    } else {
      if (shareOptionsIOS.length <= 1) {
        shareOptionsIOS.clear();
        shareOptionsIOS.add(null);
        schemas.forEach((element) async {
          try {
            var availability = await AppAvailability.checkAvailability(element.scheme);
            print('===== scheme $element: ${availability['package_name']}');
            shareOptionsIOS.add(element);
          } catch (e) {
            print((e as PlatformException).message);
          }
        });
      }
    }
    setState(LoadingState.idle);
    showProfileBottomSheet();
  }

  showProfileBottomSheet() => showModalBottomSheet(
        backgroundColor: BottomSheetColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(12.0), topRight: Radius.circular(12.0))),
        context: navigationService.currentContext,
        builder: (BuildContext bc) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16, right: 16, top: 12, bottom: 12),
                child: Text('Share on', style: Regular.copyWith(color: WhiteColor, fontSize: 16)),
              ),
              Platform.isIOS
                  ? Container(
                      color: Color(0xff1d1d1d),
                      padding: EdgeInsets.symmetric(vertical: 16.0),
                      child: SizedBox(
                        height: 90.0,
                        child: ListView.builder(
                          itemCount: shareOptionsIOS.length,
                          itemBuilder: (_, index) {
                            var shareOption = shareOptionsIOS[index];
                            return Container(
                              width: 90.0,
                              child: shareOption == null
                                  ? InkWell(
                                      onTap: () => Clipboard.setData(new ClipboardData(text: profile.share)).then((_) {
                                        onBackPressed();
                                        showSnackBar('Link copied to clipboard');
                                      }),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          CircleAvatar(
                                            radius: 24.0,
                                            backgroundColor: RoundButtonColor,
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(24.0),
                                              child: Padding(
                                                padding: const EdgeInsets.all(10.0),
                                                child: SvgPicture.asset(Assets.svgCopy, width: 48.0, height: 48.0),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              'Copy link',
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : InkWell(
                                      onTap: () => shareIos(shareOption, profile.share), //=> shareOption.share(),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          ClipRRect(
                                            borderRadius: BorderRadius.circular(24.0),
                                            child: SvgPicture.asset(shareOption.iconAssets, width: 48, height: 48),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              shareOption.name,
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                            );
                          },
                          scrollDirection: Axis.horizontal,
                          shrinkWrap: false,
                          physics: BouncingScrollPhysics(),
                        ),
                      ),
                    )
                  : Container(
                      color: Color(0xff1d1d1d),
                      padding: EdgeInsets.symmetric(vertical: 16.0),
                      child: SizedBox(
                        height: 90.0,
                        child: ListView.builder(
                          itemCount: shareOptions.length,
                          itemBuilder: (_, index) {
                            var shareOption = shareOptions[index];
                            return Container(
                              width: 90.0,
                              child: shareOption == null
                                  ? InkWell(
                                      onTap: () => Clipboard.setData(new ClipboardData(text: profile.share)).then((_) {
                                        onBackPressed();
                                        showSnackBar('Link copied to clipboard');
                                      }),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          CircleAvatar(
                                            radius: 24.0,
                                            backgroundColor: RoundButtonColor,
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(24.0),
                                              child: Padding(
                                                padding: const EdgeInsets.all(10.0),
                                                child: SvgPicture.asset(Assets.svgCopy, width: 48.0, height: 48.0),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              'Copy link',
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : InkWell(
                                      onTap: () => shareOption.share(),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          ClipRRect(
                                            borderRadius: BorderRadius.circular(24.0),
                                            child: Image.memory(shareOption.icon, width: 48.0, height: 48.0),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              shareOption.name,
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                            );
                          },
                          scrollDirection: Axis.horizontal,
                          shrinkWrap: false,
                          physics: BouncingScrollPhysics(),
                        ),
                      ),
                    ),
              Container(
                padding: EdgeInsets.only(bottom: 32),
                color: Color(0xff1d1d1d),
                child: SingleChildScrollView(
                  child: Row(
                    children: [
                      Visibility(
                        visible: !isMyProfile(),
                        child: RoundButton(child: SvgPicture.asset(Assets.svgFlag), title: 'Report', onClick: fetchReportTypes),
                      ),
                      Visibility(
                        visible: !isMyProfile(),
                        child: RoundButton(
                          child: SvgPicture.asset(Assets.svgBlocked),
                          title: profile.isHeBlocked ? 'Unblock' : 'Block',
                          onClick: () => profile.isHeBlocked ? unblockUser(profile.id) : blockUser(profile.id),
                        ),
                      ),
                      RoundButton(child: SvgPicture.asset(Assets.svgTabGifts), title: 'Send gift', onClick: sendGift),
                      Visibility(
                        visible: !isMyProfile() && profile.amIFollowing == 'false',
                        child: RoundButton(
                          child: SvgPicture.asset(Assets.svgMail),
                          title: 'Send message',
                          onClick: () {
                            onBackPressed();
                            onMessageTap();
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          );
        },
      );

  onBackPressed() => navigationService.pop();

  shareIos(SchemeModel shareOption, String url) {
    var launch = '';
    switch (shareOption.scheme) {
      case 'fb://': //fb://post/%s  https://gist.github.com/nhnam/5f106eaebff6366c0e21578c40515094
        launch = 'post/$url';
        break;
      case 'twitter://': //twitter://post?message=[Tweet Text]  https://github.com/yeswasi/URLScheme/wiki/Twitter
        launch = 'post?message=$url';
        break;
      case 'vk://': // not support https://github.com/VKCOM/vk-ios-sdk/issues/545#issuecomment-554340462
        launch = '';
        break;
      case 'whatsapp://': // whatsapp://send?text=xxx
        launch = 'send?text=$url';
        break;
      case 'tg://': // tg://msg?text=Hello
        launch = 'msg?text=$url';
        break;
      case 'viber://': // viber://forward?text=foo
        launch = 'forward?text=$url';
        break;
      case 'wechat://': // no info
        launch = '';
        break;
      case 'line://': // no info
        launch = '';
        break;
      case 'instagram://': //  maybe
        launch = 'send/text=$url';
        break;
      case 'ha://': // no info
        launch = '';
        break;
      case 'linkedin://': //
        launch = '';
        break;
    }
    if (launch.isNotEmpty) AppAvailability.launchApp(shareOption.scheme + launch);
  }

  updateNeed(GiftTempsModel giftTempsModel) {
    if (giftTempsModel != null) fetchGifts(1);
  }

  sendGift() async {
    onBackPressed();
    GiftTempsModel giftTempsModel = await navigationService.push(MaterialPageRoute(builder: (_) => GiftsPage(profile: profile)));
    updateNeed(giftTempsModel);
  }

  unblockUser(String id) async {
    onBackPressed();
    showCustomDialog('Unblock this user?', "They will be able to see your profile or content on FaceTap.", () => _unblock(id));
  }

  _unblock(String id) async {
    onBackPressed();
    Map<String, dynamic> data = serializer.prepareDataToBlock(id: id);
    profile.isHeBlocked = false;
    tabLength = 2;
    notifyListeners();
    bool _response = await _userService.unblock(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print("unblock $id");
  }

  blockUser(String id) {
    onBackPressed();
    showCustomDialog('Block this user?', "They won't be able to see your profile or content on FaceTap.", () => _block(id));
  }

  _block(String id) async {
    onBackPressed();
    Map<String, dynamic> data = serializer.prepareDataToBlock(id: id);
    profile.isHeBlocked = true;
    tabLength = 0;
    notifyListeners();
    bool _response = await _userService.block(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print("block $id");
  }

  showCustomDialog(String title, String message, Function confirmAction) {
    showDialog(
      context: navigationService.currentContext,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Color(0xff1e1e1e),
          title: Text(title, style: Medium.copyWith(color: WhiteColor)),
          content: Text(message, style: Regular.copyWith(color: WhiteColor)),
          actions: [
            TextButton(child: Text('Cancel', style: Medium.copyWith(color: WhiteColor)), onPressed: onBackPressed),
            TextButton(child: Text('Confirm', style: Medium.copyWith(color: AccentColor)), onPressed: confirmAction)
          ],
        );
      },
    );
  }

  onEditProfileTap() => navigationService.push(MaterialPageRoute(builder: (_) => EditProfilePage()));

  onFollowsTap(UserModel profile, int index) =>
      navigationService.push(MaterialPageRoute(builder: (_) => FollowingPage(profile: profile, index: index)));

  userImage() => CircleAvatar(
        radius: 48.0,
        backgroundColor: TextFromFieldHintColor,
        child: (profile.profilePhoto ?? '').isNotEmpty
            ? ClipRRect(
                borderRadius: BorderRadius.circular(50.0),
                child: CachedNetworkImage(
                  imageUrl: profile.profilePhoto,
                  fit: BoxFit.cover,
                  height: 100.0,
                  width: 100.0,
                  placeholder: (context, url) => Container(color: PrimaryLightColor),
                ),
              )
            : SvgPicture.asset(Assets.svgAvatarPlaceholder),
      );

  userBanner() => Container(
      width: screenWidth(navigationService.currentContext),
      height: (screenHeight(navigationService.currentContext) * 0.2) + 20,
      child: (profile.profileBanner ?? '').isNotEmpty
          ? CachedNetworkImage(
              imageUrl: profile.profileBanner,
              fit: BoxFit.cover,
              height: screenHeight(navigationService.currentContext) * 0.2,
              width: screenWidth(navigationService.currentContext),
              placeholder: (context, url) => Container(color: GrayColor),
            )
          : Container(
              color: GrayColor, height: screenHeight(navigationService.currentContext) * 0.2, width: screenWidth(navigationService.currentContext)));

  void fetchProfile() async {
    UserModel _response = await _userService.getProfile(userId: userId).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      profile = _response;
      if (isMyProfile()) {
        _userModel.setProfile(_response);
        _cacheService.saveProfileImage(_response.profilePhoto);
        setProfileImageUrl(_response.profilePhoto, navigationService.currentContext);
      }
      notifyListeners();
    }
    setState(LoadingState.idle);
  }

  void fetchPosts(int pageKey) async {
    if (pageKey == 1) postsPagingController?.itemList?.clear();
    try {
      final _response = await _userService.getUserPosts(userId: userId, page: pageKey, limit: limit).onError((error, stackTrace) => onError(error));
      final isLastPage = (postsPagingController.itemList ?? []).length == _response.count || (_response.results ?? []).isEmpty;
      isLastPage ? postsPagingController.appendLastPage(_response.results) : postsPagingController.appendPage(_response.results, pageKey + 1);
    } catch (error) {
      postsPagingController.error = error;
    }
  }

  void fetchGifts(int pageKey) async {
    if (pageKey == 1) giftsPagingController?.itemList?.clear();
    try {
      final _response = await _giftsService.getUserGifts(userId: userId, page: pageKey, limit: limit).onError((error, stackTrace) => onError(error));
      final isLastPage = (giftsPagingController.itemList ?? []).length - 1 == _response.count || (_response.results ?? []).isEmpty;
      if (isLastPage) {
        giftsPagingController.appendLastPage(_response.results ?? []);
      } else {
        List<MyGiftModel> results = _response.results ?? [];
        if (pageKey == 1 /*&& isMyProfile()*/) results.insert(0, MyGiftModel(id: ''));
        giftsPagingController.appendPage(results, pageKey + 1);
      }
    } catch (error) {
      giftsPagingController.error = error;
    }
  }

  bool isMyProfile() => _userModel.id == userId;

  onSubscribeTap() {
    profile.amIFollowing == 'true' ? unfollowUser() : followUser();
    profile.amIFollowing = profile.amIFollowing == 'true' ? 'false' : 'true';
    notifyListeners();
  }

  onArrowDownTap() {}

  unfollowUser() async {
    Map<String, dynamic> data = serializer.prepareDataToFollow(id: profile.id);
    bool _response = await _userService.unfollow(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print("unfollow ${profile.id}");
  }

  followUser() async {
    Map<String, dynamic> data = serializer.prepareDataToFollow(id: profile.id);
    bool _response = await _userService.follow(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print("follow ${profile.id}");
  }

  double calculateHeightForBio(double bioHeight, int maxLines) {
    final span = TextSpan(text: profile.bio);
    final tp = TextPainter(text: span, maxLines: maxLines, textDirection: TextDirection.ltr);
    tp.layout(maxWidth: screenWidth(navigationService.currentContext) - 32);

    if (tp.didExceedMaxLines) {
      return calculateHeightForBio(bioHeight + 10, maxLines + 1);
    } else {
      return bioHeight;
    }
  }

  onMessageTap() async {
    setState(LoadingState.loading);
    CreateChatModel _response = await _userService.createChatService(receiverId: profile.id).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      navigationService.push(MaterialPageRoute(
          builder: (_) => ChatPage(
              SocketMessageModel(roomId: _response.roomId, newChat: _response.newCreated, recipientId: profile.id, senderId: _userModel.id),
              profile,
              _userModel.accessToken)));
      setState(LoadingState.idle);
    } else {
      setState(LoadingState.idle);
    }
  }

  onSavedPostTap() => navigationService.push(MaterialPageRoute(builder: (_) => SavedPostsPage()));

  fetchReportTypes() async {
    if ((reportTypes ?? []).isEmpty) {
      setState(LoadingState.loading);
      ReportTypesModel _response = await _userService.reportUserTypes(page: 1, limit: 20).onError((error, stackTrace) => onError(error));
      setState(LoadingState.idle);
      if (_response != null) reportTypes.addAll(_response.results);
    }
    onBackPressed();
    showReportBottomSheet();
  }

  reportUser(int reportId) async {
    onBackPressed();
    showSnackBar('Report sent');
    Map<String, dynamic> data = serializer.prepareDataToReportUser(reportId: reportId, userId: profile.id);
    bool _response = await _userService.reportUser(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print('user reported ${profile.id}');
  }

  showReportBottomSheet() => showModalBottomSheet(
        backgroundColor: BottomSheetColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(12.0), topRight: Radius.circular(12.0))),
        context: navigationService.currentContext,
        builder: (BuildContext bc) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16, right: 16, top: 12, bottom: 12),
                child: Text('Report', style: Regular.copyWith(color: WhiteColor, fontSize: 16)),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16, right: 16, bottom: 12),
                child: Text('Why are you reporting this profile?', style: Regular.copyWith(color: TextFromFieldHintColor, fontSize: 14)),
              ),
              Container(
                padding: EdgeInsets.only(left: 16, right: 16, bottom: 32),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      for (var item in reportTypes) SettingsTemplates(name: item.message, onNavigationTap: () => reportUser(item.id)),
                    ],
                  ),
                ),
              )
            ],
          );
        },
      );
  //
  // final Dio _dio = Dio();
  //
  // double progress = 0;
  //
  // FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;
  //
  // Future<void> _onSelectNotification(String json) async {
  //   final obj = jsonDecode(json);
  //
  //   if (obj['isSuccess']) {
  //   } else {
  //     showDialog(
  //       context: navigationService.currentContext,
  //       builder: (_) => AlertDialog(
  //         title: Text('Error'),
  //         content: Text('${obj['error']}'),
  //       ),
  //     );
  //   }
  // }
  //
  // Future<void> _showNotification(Map<String, dynamic> downloadStatus) async {
  //   final android =
  //       AndroidNotificationDetails('channel id', 'channel name', 'channel description', priority: Priority.high, importance: Importance.max);
  //   final iOS = IOSNotificationDetails();
  //   final platform = NotificationDetails(android: android, iOS: iOS);
  //   final json = jsonEncode(downloadStatus);
  //   final isSuccess = downloadStatus['isSuccess'];
  //
  //   await flutterLocalNotificationsPlugin.show(
  //       0, // notification id
  //       isSuccess ? 'Success' : 'Failure',
  //       isSuccess ? 'File has been uploaded successfully!' : 'There was an error while uploading the file.',
  //       platform,
  //       payload: json);
  // }
  //
  // void _onReceiveProgress(int received, int total) {
  //   if (total != -1) {
  //     progress = (received / total * 100);
  //     print(progress);
  //     notifyListeners();
  //   }
  // }
  //
  // Future<void> startDownload(
  //   String savePath,
  //   String _fileUrl,
  //   String contentType,
  //   String metaType,
  //   Map<String, dynamic> data,
  // ) async {
  //   Map<String, dynamic> result = {
  //     'isSuccess': false,
  //     'filePath': null,
  //     'error': null,
  //   };
  //
  //   print(data);
  //   print(savePath);
  //   print(_fileUrl);
  //   print(contentType);
  //   print(metaType);
  //   var len = await File(savePath).length();
  //   try {
  //     final response = await _dio.put(_fileUrl,
  //         data: File(savePath).openRead(),
  //         options: Options(
  //           headers: {Headers.contentLengthHeader: len, HttpHeaders.contentTypeHeader: contentType, 'x-amz-meta-object-type': metaType},
  //         ),
  //         onSendProgress: _onReceiveProgress);
  //
  //     result['isSuccess'] = response.statusCode == 200;
  //     result['filePath'] = savePath;
  //     print(response.statusCode);
  //     print(response.data);
  //   } catch (ex) {
  //     print(ex);
  //     result['error'] = ex.toString();
  //   } finally {
  //     createPost(data);
  //   }
  // }

  createPost(Map<String, dynamic> data,) async {
    print("data $data");
    PostModel _response = await _postsService.createPost(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      uploadModel.setProfile(UploadModel());
      print(_response.medias.first.mediaUrl);
      // await _showNotification(result);
      print("Post Created");
      print(_response.hashtags);
      postsPagingController.refresh();
      notifyListeners();
    }
  }



  Future getImage() async {
      final String filename = basename(uploadModel.mediaPath);
      final String savedDir = dirname(uploadModel.mediaPath);
      final tag =uploadModel.contentType=='video/mp4' ? "video upload" : "image upload";
      var fileItem = FileItem(
        filename: filename,
        savedDir: savedDir,
        fieldname: "file",
      );

      var taskId =  await uploader.enqueueBinary(
        url: uploadModel.mediaUrl,
        file: fileItem,
        method: UploadMethod.PUT,
        headers: {HttpHeaders.contentTypeHeader: uploadModel.contentType, 'x-amz-meta-object-type': uploadModel.metaType},
        tag: tag,
        showNotification: true,
      );


        tasks.putIfAbsent(
            tag,
                () => UploadItem(
              id: taskId,
              tag: tag,
              type: uploadModel.contentType=='video/mp4' ?  MediaType.Video : MediaType.Image,
              status: UploadTaskStatus.enqueued,
            ));
      createPost(uploadModel.data);
   notifyListeners();
    }
  }



class UploadItem {
  final String id;
  final String tag;
  final MediaType type;
  final int progress;
  final UploadTaskStatus status;

  UploadItem({
    this.id,
    this.tag,
    this.type,
    this.progress = 0,
    this.status = UploadTaskStatus.undefined,
  });

  UploadItem copyWith({UploadTaskStatus status, int progress}) => UploadItem(
      id: this.id,
      tag: this.tag,
      type: this.type,
      status: status ?? this.status,
      progress: progress ?? this.progress);

  bool isCompleted() =>
      this.status == UploadTaskStatus.canceled ||
          this.status == UploadTaskStatus.complete ||
          this.status == UploadTaskStatus.failed;
}

enum MediaType { Image, Video }