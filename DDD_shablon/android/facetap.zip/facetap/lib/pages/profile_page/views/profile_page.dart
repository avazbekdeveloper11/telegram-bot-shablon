import 'dart:io';
import 'dart:ui';

import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/views/image_category.dart';
import 'package:facetap/global_widgets/views/infinite_list_empty.dart';
import 'package:facetap/global_widgets/views/menu_button.dart';
import 'package:facetap/global_widgets/views/subscribe_button.dart';
import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/pages/profile_page/local_widget/views/gift_profile_item.dart';
import 'package:facetap/pages/profile_page/view_model/profile_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/formatter.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_uploader/flutter_uploader.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

import '../local_widget/profile_statistics_container.dart';

class ProfilePage extends StatefulWidget {
  final String userId;
  final bool isNavigatorPop;

  const ProfilePage({Key key, this.userId, this.isNavigatorPop = false}) : super(key: key);

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> with SingleTickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ProfileViewModel>.reactive(
      initState: (model) => model.initData(this, widget.userId),
      viewModelBuilder: () => ProfileViewModel(),
      builder: (context, model, _) {
        var expandHeight = 340.0;

        var isNameVisible = model.profile.firstName.isNotEmpty || model.profile.lastName.isNotEmpty;
        var isUsernameVisible = model.profile.username.isNotEmpty;
        var isBioVisible = (model.profile.bio ?? '').isNotEmpty;
        var isBlocked = !model.profile.amIBlocked || !model.profile.isHeBlocked;

        if (isNameVisible) expandHeight += 40.0;
        if (isUsernameVisible) expandHeight += 20.0;
        if (isBlocked) expandHeight += 80.0;
        if (isBioVisible) expandHeight += model.calculateHeightForBio(60.0, 1);

        return BaseClass(
          child: Container(
            color: PrimaryDarkColor.withOpacity(0.7),
            child: Stack(
              children: [
                Scaffold(
                  backgroundColor: PrimaryDarkColor.withOpacity(0.7),
                  body: NestedScrollView(
                    controller: model.scrollController,
                    headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
                      return <Widget>[
                        SliverAppBar(
                          snap: false,
                          backgroundColor: PrimaryDarkColor.withOpacity(model.opacity),
                          expandedHeight: expandHeight,
                          pinned: true,
                          centerTitle: true,
                          automaticallyImplyLeading: false,
                          floating: false,
                          flexibleSpace: FlexibleSpaceBar(
                            centerTitle: true,
                            collapseMode: CollapseMode.pin,
                            background: Column(
                              children: [
                                Stack(
                                  children: [
                                    model.userBanner(),
                                    Align(
                                      alignment: Alignment.center,
                                      child: Padding(
                                        padding: EdgeInsets.only(top: (screenHeight(context) * 0.2) - 30, bottom: 8.0),
                                        child: model.userImage(),
                                      ),
                                    ),
                                  ],
                                ),
                                Visibility(
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 8.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          '${model.profile.firstName} ${model.profile.lastName}',
                                          style: Medium.copyWith(fontSize: 24.0, color: WhiteColor),
                                        ),
                                        model.profile.isVerifiedByAdmin
                                            ? Padding(padding: EdgeInsets.symmetric(horizontal: 8.0), child: SvgPicture.asset(Assets.svgVerified))
                                            : Container(),
                                      ],
                                    ),
                                  ),
                                  visible: isNameVisible,
                                ),
                                Visibility(
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 8.0),
                                    child: Text(
                                      '@${model.profile.username}',
                                      style: Regular.copyWith(fontSize: 16.0, color: WhiteColor.withOpacity(0.5)),
                                    ),
                                  ),
                                  visible: isUsernameVisible,
                                ),
                                Padding(
                                  padding: EdgeInsets.symmetric(vertical: 16.0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      ProfileStatisticsContainer(nameStatistics: 'Rating', statistics: model.profile.rating),
                                      Container(width: 1.0, height: 50.0, color: WhiteColor.withOpacity(0.2)),
                                      GestureDetector(
                                        child: ProfileStatisticsContainer(nameStatistics: 'Following', statistics: model.profile.followingCount),
                                        onTap: () => isBlocked ? model.onFollowsTap(model.profile, 0) : null,
                                      ),
                                      Container(width: 1.0, height: 50.0, color: WhiteColor.withOpacity(0.2)),
                                      GestureDetector(
                                        child: ProfileStatisticsContainer(nameStatistics: 'Followers', statistics: model.profile.followersCount),
                                        onTap: () => isBlocked ? model.onFollowsTap(model.profile, 1) : null,
                                      ),
                                    ],
                                  ),
                                ),
                                Visibility(
                                  child: Padding(
                                    padding: EdgeInsets.all(12.0),
                                    child: Text(
                                      model.profile.bio ?? '',
                                      style: Regular.copyWith(fontSize: 14.0, color: WhiteColor),
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                  visible: isBioVisible,
                                ),
                                model.isMyProfile()
                                    ? Padding(
                                        padding: EdgeInsets.all(16.0),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Container(
                                              width: 200.0,
                                              height: 48.0,
                                              child: SubscribeButton(
                                                fontSize: 16.0,
                                                text: 'Edit Profile',
                                                onTap: model.onEditProfileTap,
                                                buttonColor: GrayColor,
                                              ),
                                            ),
                                            Container(
                                              height: 48.0,
                                              width: 48.0,
                                              margin: EdgeInsets.only(left: 8.0),
                                              child: MenuButton(
                                                icon: Padding(padding: EdgeInsets.all(10.0), child: SvgPicture.asset(Assets.svgBookmark)),
                                                onTap: model.onSavedPostTap,
                                                isFilled: true,
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                    : isBlocked
                                        ? Padding(
                                            padding: EdgeInsets.all(16.0),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Container(
                                                  width: 200.0,
                                                  height: 48.0,
                                                  child: SubscribeButton(
                                                    fontSize: 16.0,
                                                    text: model.profile.amIFollowing == 'true' ? 'Message' : 'Follow',
                                                    onTap: model.profile.amIFollowing == 'true' ? model.onMessageTap : model.onSubscribeTap,
                                                    buttonColor: model.profile.amIFollowing == 'true' ? GrayColor : AccentColor,
                                                    isBorderColored: true,
                                                  ),
                                                ),
                                                Visibility(
                                                  child: Container(
                                                    height: 48.0,
                                                    width: 48.0,
                                                    margin: EdgeInsets.only(left: 8.0),
                                                    child: MenuButton(
                                                      icon: Padding(padding: EdgeInsets.all(10.0), child: SvgPicture.asset(Assets.svgUserChecked)),
                                                      onTap: model.onSubscribeTap,
                                                      isFilled: true,
                                                    ),
                                                  ),
                                                  visible: model.profile.amIFollowing == 'true',
                                                ),
                                                // Container(
                                                //   height: 48.0,
                                                //   width: 48.0,
                                                //   margin: EdgeInsets.only(left: 8.0),
                                                //   child: MenuButton(
                                                //     icon: Padding(padding: EdgeInsets.all(10.0), child: SvgPicture.asset(Assets.svgArrowDown)),
                                                //     onTap: model.onArrowDownTap,
                                                //     isFilled: true,
                                                //   ),
                                                // ),
                                              ],
                                            ),
                                          )
                                        : Container(),
                              ],
                            ),
                          ),
                          leading: Row(
                            children: [
                              widget.isNavigatorPop
                                  ? IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed)
                                  : Container(),
                              Padding(
                                padding: EdgeInsets.only(left: widget.isNavigatorPop ? 0 : 24.0),
                                child: Text(
                                  '💥 ${formatAmount(model.profile.points)}',
                                  style: Medium.copyWith(color: WhiteColor, fontSize: 16.0),
                                ),
                              ),
                            ],
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                          ),
                          actions: [IconButton(icon: SvgPicture.asset(Assets.svgMoreHorizontal), onPressed: model.onMenuPressed)],
                          title: model.opacityTwo > 0.6
                              ? Container(
                                  child: Text(
                                    '@${model.profile.username}',
                                    style: Medium.copyWith(fontSize: 20.0, color: WhiteColor.withOpacity(model.opacityTwoColor)),
                                  ),
                                )
                              : Container(),
                          bottom: TabBar(
                            isScrollable: false,
                            indicatorColor: WhiteColor,
                            controller: model.tabController,
                            tabs: [
                              Tab(icon: SvgPicture.asset(Assets.svgTabFeed)),
                              Tab(icon: SvgPicture.asset(Assets.svgTabGifts)),
                            ],
                          ),
                        ),
                      ];
                    },
                    body: model.profile.amIBlocked || model.profile.isHeBlocked
                        ? Container(
                            padding: EdgeInsets.all(24.0),
                            alignment: Alignment.topCenter,
                            child: Column(
                              children: [
                                Padding(padding: EdgeInsets.all(8.0), child: Icon(Icons.lock_outline_rounded, color: WhiteColor)),
                                Text(
                                  model.profile.isHeBlocked ? 'This user is blocked.' : 'The user has blocked you.',
                                  style: Medium.copyWith(color: WhiteColor, fontSize: 16.0),
                                ),
                              ],
                            ),
                          )
                        : TabBarView(
                            controller: model.tabController,
                            children: [
                              PagedGridView<int, PostModel>(
                                padding: EdgeInsets.only(bottom: 8.0, top: 8.0),
                                shrinkWrap: true,
                                pagingController: model.postsPagingController,
                                builderDelegate: PagedChildBuilderDelegate<PostModel>(
                                    itemBuilder: (context, item, index) {
                                      if ( model.tasks.values.isEmpty ? false : model.tasks.values.first.status==UploadTaskStatus.running && index == 0) {
                                        print("thubnail ${model.uploadModel.thumbnailPath}");
                                        return  Center(
                                                child: Container(
                                                  height: screenWidth(context) / 3 - 4,
                                                  width: screenWidth(context) / 3 - 4,
                                                  decoration: BoxDecoration(
                                                      color: Colors.black,
                                                      image: DecorationImage(
                                                          fit: BoxFit.cover, image: FileImage(File(model.uploadModel.thumbnailPath)))),
                                                  child: Center(
                                                    child: Container(
                                                      color: Color(0x24000000),
                                                      padding: EdgeInsets.all(screenWidth(context) / 12),
                                                      height: screenWidth(context) / 3 - 4,
                                                      width: screenWidth(context) / 3 - 4,
                                                      child: Stack(
                                                        children: [
                                                          Container(
                                                            height: screenWidth(context) / 4 - 4,
                                                            width: screenWidth(context) / 4 - 4,
                                                            child: CircularProgressIndicator(
                                                              strokeWidth: 8,
                                                              backgroundColor: Color(0x24ffffff),
                                                              valueColor: new AlwaysStoppedAnimation<Color>(Colors.white),
                                                              value: model.tasks.values.first.progress / 100,
                                                            ),
                                                          ),
                                                          Center(
                                                            child: Text(
                                                              "${model.tasks.values.first.progress}%",
                                                              style: Medium.copyWith(color: Colors.white, fontSize: 17),
                                                            ),
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                        );
                                      } else {
                                        return ImageTemplate(
                                          post: item,
                                          onViewPostClicked: () => model.onViewPostClicked(item),
                                        );
                                      }
                                    },
                                    firstPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                                    newPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                                    noItemsFoundIndicatorBuilder: (_) {
                                      if (model.tasks.values.first.status==UploadTaskStatus.running) {
                                        return Center(
                                                child: Container(
                                                  height: screenWidth(context) / 3 - 4,
                                                  width: screenWidth(context) / 3 - 4,
                                                  decoration: BoxDecoration(
                                                    color: Colors.black,
                                                    image: DecorationImage(
                                                      fit: BoxFit.cover,
                                                      image: FileImage(File(model.uploadModel.thumbnailPath)),
                                                    ),
                                                  ),
                                                  child: Center(
                                                    child: Container(
                                                      color: Color(0x24000000),
                                                      padding: EdgeInsets.all(screenWidth(context) / 12),
                                                      height: screenWidth(context) / 3 - 4,
                                                      width: screenWidth(context) / 3 - 4,
                                                      child: Stack(
                                                        children: [
                                                          Container(
                                                            height: screenWidth(context) / 4 - 4,
                                                            width: screenWidth(context) / 4 - 4,
                                                            child: CircularProgressIndicator(
                                                              strokeWidth: 8,
                                                              backgroundColor: Color(0x24ffffff),
                                                              valueColor: new AlwaysStoppedAnimation<Color>(Colors.white),
                                                              value: model.tasks.values.first.progress / 100,
                                                            ),
                                                          ),
                                                          Center(
                                                            child: Text(
                                                              "${model.tasks.values.first.progress}%",
                                                              style: Medium.copyWith(color: Colors.white, fontSize: 17),
                                                            ),
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              );
                                      } else {
                                        return InfiniteListEmptyItem();
                                      }
                                    }),
                                gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 150, mainAxisSpacing: 2.0),
                              ),
                              PagedGridView<int, MyGiftModel>(
                                padding: EdgeInsets.all(8.0),
                                shrinkWrap: true,
                                pagingController: model.giftsPagingController,
                                builderDelegate: PagedChildBuilderDelegate<MyGiftModel>(
                                  itemBuilder: (context, item, index) => GiftProfileItem(
                                    gift: item,
                                    profile: model.profile,
                                    updateNeed: (bool) => model.updateNeed(bool),
                                  ),
                                  firstPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                                  newPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                                  noItemsFoundIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                                ),
                                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 4,
                                  childAspectRatio: 0.7,
                                  mainAxisSpacing: 4.0,
                                  crossAxisSpacing: 4.0,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
                model.isloading ? Loading() : Container()
              ],
            ),
          ),
        );
      },
    );
  }
}
