import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/models/places_model.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/models/verification_code_model.dart';
import 'package:facetap/pages/camera_page/views/camera_page.dart';
import 'package:facetap/pages/content_page/views/view_post_page.dart';
import 'package:facetap/pages/home_page/views/home_screen.dart';
import 'package:facetap/pages/interests_page/views/interests_page.dart';
import 'package:facetap/pages/login_page/views/login_page.dart';
import 'package:facetap/pages/profile_page/views/profile_page.dart';
import 'package:facetap/pages/settings_page/security_page/views/password_page.dart';
import 'package:facetap/providers/base_class_provider.dart';
import 'package:facetap/services/authentication_service.dart';
import 'package:facetap/services/cache_service.dart';
import 'package:facetap/services/chat/all_chats_page.dart';
import 'package:facetap/services/places_service.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/base_view_model.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:location/location.dart' as DeviceLocation;
import 'package:pedantic/pedantic.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeViewModel extends BaseViewModel {
  final UserModel _userModel = locator<UserModel>();
  final PostsService _postsService = locator<PostsService>();
  final AuthenticationService _authService = locator<AuthenticationService>();
  final UserService _userService = locator<UserService>();
  final CacheService _cacheService = locator<CacheService>();
  int selectedIndex = 0;
  Timer _timer;
  Widget widget = Scaffold(backgroundColor: PrimaryDarkColor);
  bool hasMessage = false;
  String roomId = '';

  checkHasMessage() async {
    print("_response.exist");
    try {
      final _response = await _postsService.hasUnreadMessage().onError((error, stackTrace) => onError(error));
      if (_response != null) {
        print("_response.exist ${_response.exist}");
        hasMessage = _response.exist;
        notifyListeners();
      }
    } catch (e) {
      print("_response.exist e $e");
    }
  }

  gotoCamera() async {
    var status = await Permission.storage.status;
    if (status.isDenied) {
      await [Permission.storage].request();
      gotoCamera();
    } else {
      _gotoCamera();
    }

    /*
    var status = await Permission.storage.status;
    var status1 = await Permission.manageExternalStorage.status;
    if (status.isDenied || status1.isDenied) {
      print('storage : $status');
      print('external : $status1');
      List<Permission> permissions = [];
      if (status.isDenied) permissions.add(Permission.storage);
      if (status1.isDenied) permissions.add(Permission.manageExternalStorage);
      await permissions.request();
      _gotoCamera();
    } else {
      _gotoCamera();
    }
    */
  }

  _gotoCamera() async {
    navigationService.push(MaterialPageRoute(builder: (_) => CameraPage(withVideo: true)));
  }

  gotoLogin() {
    navigationService.push(MaterialPageRoute(builder: (_) => LoginPage()));
  }

  bool isLogin() {
    return _userModel.accessToken.isNotEmpty;
  }

  userImage(bool isSelected) => _userModel.profilePhoto.isNotEmpty
      ? Stack(
          alignment: Alignment.center,
          children: [
            CircleAvatar(
              radius: 16.5,
              backgroundColor: isSelected ? WhiteColor : WhiteColor.withOpacity(0.5),
            ),
            ClipRRect(
              borderRadius: BorderRadius.circular(32.0),
              child: CachedNetworkImage(
                imageUrl: getProfileImageUrl(navigationService.currentContext),
                fit: BoxFit.cover,
                height: 32.0,
                width: 32.0,
                placeholder: (context, url) => Container(color: TextFromFieldHintColor),
              ),
            ),
          ],
        )
      : Icon(
          Icons.person_outline_rounded,
          size: 30.0,
          color: isSelected ? WhiteColor : WhiteColor.withOpacity(0.5),
        );

  getIndex(index) {
    selectedIndex = index;
    unawaited(checkHasMessage());
    notifyListeners();
  }

  final PlacesService _placesService = locator<PlacesService>();
  Position _currentPosition;

  initData(int defaultIndex, String _roomId) {
    roomId = _roomId;
    selectedIndex = defaultIndex;
    initApp(defaultIndex);
    super.initState();
  }

  Future<String> _determinePosition() async {
    LocationPermission permission;
    String _currentAddress = '';

    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      if (!await Geolocator.openLocationSettings()) {
        showDialog(
          context: navigationService.currentContext,
          builder: (BuildContext context) {
            return AlertDialog(
              backgroundColor: Color(0xff1e1e1e),
              title: Text('Location Service disabled', style: Regular.copyWith(color: WhiteColor)),
              content: Text('Please, enable Location service in app settings or in Privacy', style: Regular.copyWith(color: WhiteColor)),
              actions: [
                TextButton(
                    child: Text('Cancel', style: Regular.copyWith(color: WhiteColor)), onPressed: () => navigationService.pop()), //=> exit(0)),
                TextButton(
                    child: Text('Confirm', style: Regular.copyWith(color: AccentColor)),
                    onPressed: () async {
                      navigationService.pop();
                      await Future.delayed(const Duration(seconds: 1), () async {
                        bool locationSettings = await Geolocator.openLocationSettings();
                        if (!locationSettings) {
                          return '';
                        }
                      });
                    })
              ],
            );
          },
        );
        //exit(0);
      }
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return Future.error('Location permissions are denied');
    }

    if (permission == LocationPermission.deniedForever)
      return Future.error('Location permissions are permanently denied, we cannot request permissions.');

    _currentPosition = await Geolocator.getCurrentPosition();
    PlacesModel _response = await _placesService.getNearbyPlaces(lat: _currentPosition.latitude, long: _currentPosition.longitude);
    if (_response != null) {
      _currentAddress = _response.results.first.formattedAddress ?? _response.results.first.name ?? 'default';
    } else {
      try {
        List<Placemark> placemarks = await placemarkFromCoordinates(_currentPosition.latitude, _currentPosition.longitude);
        _currentAddress = '${placemarks[0].locality}';
      } catch (e) {
        print(e);
      }
    }
    return _currentAddress;
  }

  initApp(int defaultIndex) async {
    bool service = await checkLocationService();
    if (service) checkPermission();

    await SharedPreferences.getInstance().then((prefs) async {
      selectedIndex = defaultIndex;
      UserModel _userModel = locator<UserModel>();
      _userModel.setToken = prefs.getString('access_token') ?? '';
      _userModel.setRefreshToken = prefs.getString('refresh_token') ?? '';
      _userModel.id = prefs.getString('id') ?? '';
      _userModel.profilePhoto = prefs.getString('image') ?? '';
      _userModel.locationName = await _determinePosition();
      print('''\n=====
        access_token: ${_userModel.accessToken}
        refresh_token: ${_userModel.refreshToken}
        id: ${_userModel.id}
        profile_photo: ${_userModel.profilePhoto}
        locationName:  ${_userModel.locationName}
        =====\n''');
    });

    _retrieveDynamicLink("init");
    // if (isLogin() && getProfileImageUrl(navigationService.currentContext).isEmpty)
    //   setProfileImageUrl(_userModel.profilePhoto, navigationService.currentContext);
    if (isLogin()) {
      fetchProfile();
    }
  }

  checkLocationService() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    print('service: $serviceEnabled');
    if (!serviceEnabled) {
      showDialog(
        context: navigationService.currentContext,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: Color(0xff1e1e1e),
            title: Text('Location Service disabled', style: Regular.copyWith(color: WhiteColor)),
            content: Text('Please, enable Location service in app settings or in Privacy', style: Regular.copyWith(color: WhiteColor)),
            actions: [
              TextButton(child: Text('Cancel', style: Regular.copyWith(color: WhiteColor)), onPressed: () => navigationService.pop()), //=> exit(0)),
              TextButton(
                  child: Text('Confirm', style: Regular.copyWith(color: AccentColor)),
                  onPressed: () async {
                    navigationService.pop();
                    await Future.delayed(const Duration(seconds: 1), () async {
                      bool locationSettings = await Geolocator.openLocationSettings();
                      if (!locationSettings) {
                        checkLocationService();
                      }
                    });
                  })
            ],
          );
        },
      );
    }
    return serviceEnabled;
  }

  checkPermission() async {
    DeviceLocation.Location location = new DeviceLocation.Location();
    DeviceLocation.PermissionStatus _permissionGranted = await location.hasPermission();
    if (_permissionGranted == DeviceLocation.PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      print('permission: $_permissionGranted');
      if (_permissionGranted != DeviceLocation.PermissionStatus.granted) {
        showDialog(
          context: navigationService.currentContext,
          builder: (BuildContext context) {
            return AlertDialog(
              backgroundColor: Color(0xff1e1e1e),
              title: Text('Location Service disabled', style: Regular.copyWith(color: WhiteColor)),
              content: Text('Please, enable Location service in app settings or in Privacy', style: Regular.copyWith(color: WhiteColor)),
              actions: [
                TextButton(
                    child: Text('Cancel', style: Regular.copyWith(color: WhiteColor)), onPressed: () => navigationService.pop()), //=> exit(0)),
                TextButton(
                    child: Text('Confirm', style: Regular.copyWith(color: AccentColor)),
                    onPressed: () async {
                      navigationService.pop();
                      await Future.delayed(const Duration(seconds: 1), () async {
                        bool appSettings = await Geolocator.openAppSettings();
                        if (!appSettings) {
                          checkPermission();
                        }
                      });
                    })
              ],
            );
          },
        );
      }
    }
  }

  @override
  onDispose() {
    if (_timer != null) _timer.cancel();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    print("===== state: $state");
    if (state == AppLifecycleState.resumed) _timer = Timer(Duration(milliseconds: 500), () => _retrieveDynamicLink("state"));
  }

  _retrieveDynamicLink(String s) async {
    await Future.delayed(Duration(seconds: 2));
    if (s == "init") {
      final PendingDynamicLinkData data = await FirebaseDynamicLinks.instance.getInitialLink();
      final Uri deepLink = data?.link;
      print("====== $s deep link: $deepLink");
      if (deepLink != null) _gotoByDeepLink(deepLink);
    } else {
      FirebaseDynamicLinks.instance.onLink(
        onSuccess: (PendingDynamicLinkData dynamicLink) async {
          final Uri deepLink = dynamicLink?.link;
          print("====== $s deep link: $deepLink");
          if (deepLink != null) _gotoByDeepLink(deepLink);
        },
        onError: (OnLinkErrorException e) async {
          print('onLinkError');
          print(e.message);
        },
      );
    }
  }

  void _gotoByDeepLink(Uri deepLink) async {
    print("deepLink.path ${deepLink.path}");
    if (deepLink.path.contains('verify')) {
      // deepLink = https://facetap.test.uzpos.uz/v1/verify/kabes56504@tripaco.com/126542/signup/
      // deepLink.path = /v1/verify/kedepa4865@tripaco.com/547897/signup/
      setState(LoadingState.loading);
      VerificationCodeModel _response = await _authService.verifyByLink(uri: deepLink).onError((error, stackTrace) => onError(error));
      setState(LoadingState.idle);
      if (_response != null) {
        _userModel.setProfile(UserModel(accessToken: _response.accessToken, refreshToken: _response.refreshToken, id: _response.id));
        if (deepLink.path.contains('signup')) {
          navigationService.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => InterestsPage()));
        } else if (deepLink.path.contains('forgot')) {
          navigationService.pushAndRemoveUntil(MaterialPageRoute(
              builder: (_) => PasswordPage(
                    resetPassword: true,
                  )));
        }
      }
    } else if (deepLink.path.contains('profile')) {
      // deepLink = https://facetap.test.uzpos.uz/v1/users/83db7f7d-2ac7-4c18-92a0-a6f6ca1abf10/profile/
      // deepLink.path = /v1/users/83db7f7d-2ac7-4c18-92a0-a6f6ca1abf10/profile/
      setState(LoadingState.loading);
      UserModel _response = await _userService.getProfileByLink(uri: deepLink).onError((error, stackTrace) => onError(error));
      setState(LoadingState.idle);
      if (_response != null) {
        if (_response.id == _userModel.id)
          navigationService.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => HomePage(defaultIndex: 4)));
        else
          navigationService.push(MaterialPageRoute(builder: (_) => ProfilePage(userId: _response.id, isNavigatorPop: true)));
      }
    } else if (deepLink.path.contains('posts')) {
      // deepLink = https://facetap.test.uzpos.uz/v1/posts/96233ef1-3902-4ef1-aa8e-6f02049f25ef/
      // deepLink.path = /v1/posts/96233ef1-3902-4ef1-aa8e-6f02049f25ef/
      setState(LoadingState.loading);
      PostModel _response = await _postsService.getPostByLink(uri: deepLink).onError((error, stackTrace) => onError(error));
      setState(LoadingState.idle);
      if (_response != null) navigationService.push(MaterialPageRoute(builder: (_) => ViewPostPage(post: _response, isNavigatorPop: true)));
    }
  }

  void fetchProfile() async {
    UserModel _response = await _userService.getProfile(userId: _userModel.id).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      _userModel.setProfile(_response);
      _cacheService.saveProfileImage(_response.profilePhoto);
      setProfileImageUrl(_response.profilePhoto, navigationService.currentContext);
      notifyListeners();
    }
    setState(LoadingState.idle);
    checkHasMessage();
    widget = AllChatsPage(
      accessToken: _userModel.accessToken,
      userId: _userModel.id,
      roomId: roomId,
    );
  }
}
