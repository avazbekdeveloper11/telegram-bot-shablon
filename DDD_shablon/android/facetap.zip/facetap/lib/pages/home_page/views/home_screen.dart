import 'package:facetap/generated/assets.dart';
import 'package:facetap/pages/content_page/views/content_page.dart';
import 'package:facetap/pages/hash_tag_page/views/hash_tag_page.dart';
import 'package:facetap/pages/home_page/view_model/home_page_view_model.dart';
import 'package:facetap/pages/profile_page/views/profile_page.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_svg/flutter_svg.dart';

class HomePage extends StatefulWidget {
  final int defaultIndex;
  final String roomId;

  const HomePage({Key key, this.defaultIndex = 0, this.roomId = ""}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final NavigationService navigationService = locator<NavigationService>();
  String roomId = "";

  getMessageData(Map<String, dynamic> map, bool app, int messageId) async {
    await flutterLocalNotificationsPlugin.cancel(messageId);
    if (map['type'] == "chat") {
      roomId = map['objectID'];
      if (app) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => HomePage(defaultIndex: 3, roomId: roomId)), (route) => false);
        });
      }
    } else {
      if (app) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => HomePage(defaultIndex: 3, roomId: "")), (route) => false);
        });
      }
    }
  }

  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    FirebaseMessaging.instance
        .requestPermission(alert: true, announcement: true, badge: true, carPlay: true, criticalAlert: false, provisional: false, sound: true);

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print(message.ttl);
      print(message.data);
      print(message.senderId);
      RemoteNotification notification = message.notification;
      AndroidNotification android = message.notification?.android;
      if (message.data.isNotEmpty) {
        if (notification != null && android != null) {
          showNotification(notification.title, notification.body, message.data["type"]);
          getMessageData(message.data, false, message.ttl);
          print("message2 ${message.data}");
        }
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) async {
      print(message.messageType);
      print(message.data);
      if (message.data.isNotEmpty) {
        getMessageData(message.data, true, 0);
        print("message1 ${message.data}");
      }
    });

    FirebaseMessaging.onBackgroundMessage((message) async {
      print(message.messageType);
      print(message.data);
      if (message.data.isNotEmpty) {
        getMessageData(message.data, true, 0);
        print("message3 ${message.data}");
      }
    });

    var initializationSettingsAndroid = new AndroidInitializationSettings('@mipmap/ic_launcher');
    var initializationSettingsIOS = new IOSInitializationSettings();

    var initializationSettings = new InitializationSettings(android: initializationSettingsAndroid, iOS: initializationSettingsIOS);
    flutterLocalNotificationsPlugin.initialize(initializationSettings, onSelectNotification: onSelectNotification);

    super.initState();
  }

  Future onSelectNotification(String payload) async {
    getMessageData({"requestId": payload}, true, 0);
  }

  void showNotification(String title, String body, String id) async {
    await _demoNotification(title, body, id);
  }

  Future<void> _demoNotification(String title, String body, String id) async {
    var androidPlatformChannelSpecifics = AndroidNotificationDetails('channel_ID', 'channel name', channelDescription: 'channel description',
        importance: Importance.max,
        playSound: true,
        // sound: 'sound',
        showProgress: true,
        
        priority: Priority.high,
        ticker: 'test ticker');

    var iOSChannelSpecifics = IOSNotificationDetails();
    var platformChannelSpecifics = NotificationDetails(android: androidPlatformChannelSpecifics, iOS: iOSChannelSpecifics);
    await flutterLocalNotificationsPlugin.show(0, title, body, platformChannelSpecifics, payload: id);
  }

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<HomeViewModel>.reactive(
        initState: (model) => model.initData(widget.defaultIndex, widget.roomId),
        onDispose: (model) => model.onDispose(),
        didChangeAppLifecycleState: (model, state) => model.didChangeAppLifecycleState(state),
        viewModelBuilder: () => HomeViewModel(),
        builder: (context, model, _) {
          List<Widget> _widgetOptions = [ContentPage(), HashTagPage(), null, model.widget, ProfilePage()];

          return Scaffold(
              resizeToAvoidBottomInset: false,
              bottomNavigationBar: BottomNavigationBar(
                type: BottomNavigationBarType.fixed,
                currentIndex: model.selectedIndex,
                showSelectedLabels: false,
                showUnselectedLabels: false,
                backgroundColor: PrimaryDarkColor,
                items: [
                  BottomNavigationBarItem(
                      icon: SvgPicture.asset(Assets.svgBottomBarHome, color: model.selectedIndex == 0 ? WhiteColor : WhiteColor.withOpacity(0.5)),
                      label: 'Content',
                      backgroundColor: PrimaryDarkColor),
                  BottomNavigationBarItem(
                      icon: SvgPicture.asset(Assets.svgBottomBarHashtag, color: model.selectedIndex == 1 ? WhiteColor : WhiteColor.withOpacity(0.5)),
                      label: 'Hash tags',
                      backgroundColor: PrimaryDarkColor),
                  BottomNavigationBarItem(
                      icon: SvgPicture.asset(Assets.svgBottomBarNewPost, color: model.selectedIndex == 2 ? WhiteColor : WhiteColor.withOpacity(0.5)),
                      label: 'Add',
                      backgroundColor: PrimaryDarkColor),
                  BottomNavigationBarItem(
                      icon: Stack(
                        children: [
                          Align(
                              alignment: Alignment.bottomCenter,
                              child: SvgPicture.asset(Assets.svgBottomBarChatIcon,
                                  color: model.selectedIndex == 3 ? WhiteColor : WhiteColor.withOpacity(0.5))),
                          Visibility(
                            visible: model.hasMessage,
                            child: Align(
                              alignment: Alignment.topCenter,
                              child: Container(
                                margin: EdgeInsets.only(left: 16),
                                height: 8,
                                width: 8,
                                decoration: BoxDecoration(color: Color(0xffEE505A), shape: BoxShape.circle),
                              ),
                            ),
                          )
                        ],
                      ),
                      label: 'Notification',
                      backgroundColor: PrimaryDarkColor),
                  BottomNavigationBarItem(
                    icon: model.userImage(model.selectedIndex == 4),
                    label: 'Profile',
                    backgroundColor: PrimaryDarkColor,
                  ),
                ],
                onTap: (index) => model.isLogin()
                    ? (index == 2 ? model.gotoCamera() : model.getIndex(index))
                    : (index < 1 ? model.getIndex(index) : model.gotoLogin()),
              ),
              body: _widgetOptions[model.selectedIndex]);
        });
  }
}
