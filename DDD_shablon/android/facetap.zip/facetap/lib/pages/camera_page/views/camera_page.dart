import 'dart:io';
import 'dart:math' as math;

import 'package:camera/camera.dart';
import 'package:facetap/Pages/camera_page/views/indicator/circular_step_progress_indicator.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/pages/camera_page/view_model/camera_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CameraPage extends StatefulWidget {
  final bool withVideo;

  const CameraPage({Key key, @required this.withVideo}) : super(key: key);

  @override
  _CameraPageState createState() => _CameraPageState();
}

class _CameraPageState extends State<CameraPage> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<CameraViewModel>.reactive(
      initState: (model) => model.initData(this, screenWidth(context), widget.withVideo),
      onDispose: (model) => model.onDisposeData(this),
      didChangeAppLifecycleState: (model, state) => model.didChangeAppLifecycleState(state),
      viewModelBuilder: () => CameraViewModel(),
      builder: (context, model, _) {
        var circleBorder = BorderSide(width: 5.0, color: AccentColor);
        return SafeArea(
          child: Scaffold(
            backgroundColor: PrimaryColor,
            body: Stack(
              children: [
                FutureBuilder<void>(
                  future: model.initializeControllerFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.done) {
                      return ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: Container(
                          height: screenHeight(context) - 90,
                          child: Transform.scale(
                            scale: math.pow(model.cameraController.value.aspectRatio, -1) /
                                ((screenWidth(context) - 100) / (screenHeight(context) - 100)), //size.aspectRatio,
                            child: Center(
                              child: AspectRatio(
                                aspectRatio: math.pow(model.cameraController.value.aspectRatio, -1),
                                child: CameraPreview(model.cameraController),
                              ),
                            ),
                          ),
                        ),
                      );
                    } else
                      return Loading();
                  },
                ),
                CircleAvatar(
                  child: IconButton(
                      padding: EdgeInsets.all(10.0), icon: Icon(Icons.close, size: 30.0, color: WhiteColor), onPressed: model.onCloseButton),
                  backgroundColor: Transparent,
                  radius: 30.0,
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Visibility(
                      visible: model.videoStart && widget.withVideo,
                      child: GestureDetector(child: SvgPicture.asset(model.flashIcon), onTap: model.onFlash),
                    ),
                  ),
                ),
                Container(
                  width: screenWidth(context),
                  height: screenHeight(context),
                  alignment: Alignment.bottomCenter,
                  padding: EdgeInsets.only(bottom: 14.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Visibility(
                            visible: model.videoStart && widget.withVideo,
                            child: GestureDetector(child: model.lastImageFromGallery, onTap: model.openGallery),
                          ),
                          GestureDetector(
                            child: model.isImageCapture
                                ? Padding(
                                    padding: EdgeInsets.symmetric(vertical: 24.0, horizontal: 8.0),
                                    child: Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        Container(
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(60.0),
                                            border: Border(top: circleBorder, bottom: circleBorder, left: circleBorder, right: circleBorder),
                                          ),
                                          child: Icon(Icons.circle, size: 75.0, color: Transparent),
                                        ),
                                        Icon(Icons.circle, size: 85.0, color: AccentColor),
                                      ],
                                    ),
                                  )
                                : Container(
                                    margin: EdgeInsets.symmetric(vertical: 24.0, horizontal: 8.0),
                                    child: CircularStepProgressIndicator(
                                      padding: math.pi / 85,
                                      stepSize: 5,
                                      totalSteps: 30,
                                      currentStep: model.start,
                                      selectedColor: AccentColor,
                                      unselectedColor: Transparent,
                                      width: 85,
                                      height: 85,
                                      child: Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Icon(Icons.circle, size: 85.0, color: AccentColor),
                                          AnimatedIcon(
                                            icon: AnimatedIcons.play_pause,
                                            size: 40,
                                            color: WhiteColor,
                                            progress: model.animationController,
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                            onTap: model.onPhotoButton,
                          ),
                          Visibility(
                            visible: model.videoStart && widget.withVideo,
                            child: GestureDetector(
                                child: Column(
                                  children: [
                                    SizedBox(height: 16),
                                    SvgPicture.asset(Assets.svgChangeCamera, width: 36.0, height: 36.0),
                                    SizedBox(height: 4),
                                    Text('Flip', style: Regular.copyWith(color: WhiteColor, fontSize: 12.0)),
                                  ],
                                ),
                                onTap: model.changeCamera),
                          ),
                        ],
                      ),
                      Visibility(
                        visible: model.videoStart && widget.withVideo,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextButton(
                              style: ButtonStyle(overlayColor: MaterialStateProperty.all<Color>(WhiteColor.withOpacity(0.3))),
                              onPressed: model.changePhoto,
                              child: Text(
                                "Photo",
                                style: Medium.copyWith(color: model.isImageCapture ? WhiteColor : TextFromFieldHintColor, fontSize: 16.0),
                              ),
                            ),
                            TextButton(
                              style: ButtonStyle(overlayColor: MaterialStateProperty.all<Color>(WhiteColor.withOpacity(0.3))),
                              onPressed: model.changeVideo,
                              child: Text(
                                "Video",
                                style: Medium.copyWith(color: !model.isImageCapture ? WhiteColor : WhiteColor.withOpacity(0.5), fontSize: 16.0),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                model.isloading ? Loading() : Container()
              ],
            ),
          ),
        );
      },
    );
  }
}

// A widget that displays the picture taken by the user.
class DisplayPictureScreen extends StatelessWidget {
  final String imagePath;

  const DisplayPictureScreen({Key key, this.imagePath}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Display the Picture')),
      // The image is stored as a file on the device. Use the `Image.file`
      // constructor with the given path to display the image.
      body: Image.file(File(imagePath)),
    );
  }
}
