import 'dart:async';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/pages/new_post_page/views/new_post_page.dart';
import 'package:facetap/pages/video_trimmer/video_trimmer.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/extensions.dart';
import 'package:facetap/utils/fonts.dart' as font;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_exif_rotation/flutter_exif_rotation.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:video_thumbnail/video_thumbnail.dart' as thumbnail;

class CameraViewModel extends BaseViewModel {
  CameraController cameraController;
  Future<void> initializeControllerFuture;
  String flashIcon = Assets.svgFlash;
  List<CameraDescription> cameras = [];
  CameraDescription selectedCamera;
  bool videoStart = true;
  bool isImageCapture = true;
  Timer _timer;
  int start = 30;
  AnimationController animationController;
  XFile imageFile;
  XFile videoFile;
  Widget lastImageFromGallery = Container(padding: EdgeInsets.all(4.0), width: 36.0, height: 36.0);

  bool isEdit = true;

  void initData(vc, width, bool _isEdit) {
    isEdit = _isEdit;
    WidgetsBinding.instance?.addObserver(vc);
    animationController = AnimationController(vsync: vc, duration: Duration(milliseconds: 450));
    _initCamera();
    _initGallery();
    super.initState();
  }

  _initCamera() async {
    cameras = await availableCameras();
    _initNewCamera(cameras.first);
  }

  _initGallery() async {
    var result = await PhotoManager.requestPermissionExtend();
    if (result.isAuth) {
      List<AssetPathEntity> list = await PhotoManager.getAssetPathList();
      var path = list.first;
      // list.forEach((element) {
      //   if (element.name == 'Recents' || element.name == 'All') path = element;
      // });
      print('=== album: ${path.name}');
      final assets = await path.getAssetListPaged(0, 1);
      final file = await assets.first.file;
      print('=== all: ${file.path}');
      final thumbnail = !file.path.isImage() ? await _getThumbnailFile(file.path) : file;
      lastImageFromGallery = Column(
        children: [
          Container(
            margin: EdgeInsets.only(bottom: 8.0, top: 16.0),
            width: 36.0,
            height: 36.0,
            decoration:
                BoxDecoration(borderRadius: BorderRadius.circular(4.0), border: Border.all(color: WhiteColor, width: 2.0, style: BorderStyle.solid)),
            child: ClipRRect(borderRadius: BorderRadius.circular(4.0), child: Image.file(thumbnail, fit: BoxFit.cover)),
          ),
          Text('Upload', style: font.Regular.copyWith(color: WhiteColor, fontSize: 12.0)),
        ],
      );
      notifyListeners();
    } else {
      // fail ; if result is fail, you can call `PhotoManager.openSetting();`  to open android/ios applicaton's setting to get permission
      PhotoManager.openSetting();
    }
  }

  Future<File> _getThumbnailFile(String path) async {
    final thumbnailPath =
        await thumbnail.VideoThumbnail.thumbnailFile(video: path, imageFormat: thumbnail.ImageFormat.JPEG, maxWidth: 128, quality: 25);
    return File(thumbnailPath);
  }

  _initNewCamera(CameraDescription camera) {
    selectedCamera = camera;
    var resolution = ResolutionPreset.high;
    cameraController = CameraController(selectedCamera, resolution, imageFormatGroup: ImageFormatGroup.yuv420);
    initializeControllerFuture = cameraController.initialize();
    _initFlashIcon(cameraController?.value?.flashMode);
  }

  _initFlashIcon(FlashMode flashMode) {
    if (flashMode == FlashMode.off) {
      flashIcon = Assets.svgFlashOff;
    } else if (flashMode == FlashMode.always) {
      flashIcon = Assets.svgFlash;
    } else if (flashMode == FlashMode.auto) {
      flashIcon = Assets.svgFlashAuto;
    }
    notifyListeners();
  }

  void onDisposeData(vc) {
    cameraController?.dispose();
    animationController?.dispose();
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(vc);
    super.onDispose();
  }

  @override
  didChangeAppLifecycleState(AppLifecycleState state) {
    final CameraController _cameraController = cameraController;

    // App state changed before we got the chance to initialize.
    if (_cameraController == null || !_cameraController.value.isInitialized) return;

    if (state == AppLifecycleState.inactive) {
      _cameraController.dispose();
    } else if (state == AppLifecycleState.resumed) {
      _initNewCamera(selectedCamera ?? cameras.first);
    }
  }

  openGallery() async {
    setState(LoadingState.loading);
    FilePickerResult result = await FilePicker.platform.pickFiles(type: FileType.media);
    if (result != null) {
      _returnValueBack(result.files.single.path, isImageCapture, isFromGallery: true);
    } else {
      setState(LoadingState.idle);
      print('No image selected.');
    }
    notifyListeners();
  }

  onPhotoButton() async {
    isImageCapture ? _takePhoto() : _takeVideo();
  }

  _takeVideo() async {
    // Take the Picture in a try / catch block. If anything goes wrong, catch the error.
    try {
      await initializeControllerFuture;
      videoStart ? _startVideo() : _finishVideo();
    } catch (e) {
      print(e);
    }
  }

  _finishVideo() async {
    print(1);
    if (cameraController != null && cameraController.value.isInitialized && cameraController.value.isRecordingVideo) {
      stopVideoRecording().then((file) {
        if (file != null) {
          print(2);
          animationController.reverse();
          videoStart = true;
          _returnValueBack(file.path, isImageCapture);
          notifyListeners();
        }
      });
    }
  }

  Future<XFile> stopVideoRecording() async {
    final CameraController cameraController2 = cameraController;
    if (cameraController2 == null || !cameraController2.value.isRecordingVideo) return null;
    try {
      return cameraController2.stopVideoRecording();
    } on CameraException catch (e) {
      print(e);
      return null;
    }
  }

  _startVideo() async {
    if (cameraController != null && cameraController.value.isInitialized && !cameraController.value.isRecordingVideo) {
      final CameraController cameraController2 = cameraController;
      if (cameraController2 == null || !cameraController2.value.isInitialized) return;
      if (cameraController2.value.isRecordingVideo) return;
      try {
        await cameraController2.startVideoRecording().then((value) {
          animationController.forward();
          const oneDecimal = const Duration(seconds: 1);
          _timer = new Timer.periodic(oneDecimal, (Timer timer) {
            start < 1 ? _finishVideo() : start = start - 1;
            notifyListeners();
          });
          videoStart = false;
        });
      } on CameraException catch (e) {
        print(e);
        return;
      }
    }
  }

  _takePhoto() async {
    try {
      await initializeControllerFuture;
      if (cameraController != null && cameraController.value.isInitialized && !cameraController.value.isRecordingVideo) {
        takePicture().then((XFile file) async {
          File rotatedImage = await FlutterExifRotation.rotateImage(path: file.path);
          _returnValueBack(rotatedImage.path, isImageCapture);
          imageFile = file;
        });
      }
    } catch (e) {
      print(e);
    }
  }

  Future<XFile> takePicture() async {
    final CameraController cameraController2 = cameraController;
    if (cameraController2 == null || !cameraController2.value.isInitialized) return null;
    if (cameraController2.value.isTakingPicture) return null; // A capture is already pending, do nothing.
    try {
      XFile file = await cameraController2.takePicture();
      return file;
    } on CameraException catch (e) {
      print(e);
      return null;
    }
  }

  _returnValueBack(String filePath, bool isImageCapture, {bool isFromGallery = false}) async {
    Map<String, dynamic> _map = {"path": filePath, "bool": !isImageCapture};
    File file;
    if (_map != null && _map.isNotEmpty) {
      bool isVideo = false;
      if (_map['path'].toString().isImage()) {
        setState(LoadingState.idle);
        if (isEdit) file = await _cropImage(_map['path']);
        isVideo = false;
      } else {
        var _file = File(_map['path']);
        setState(LoadingState.idle);
        if (isFromGallery) {
          String path = await navigationService.push(MaterialPageRoute(builder: (_) => VideoTrimmer(file: _file)));
          print('======= trim path : $path');
          if (path != null) file = File(path);
        } else {
          file = _file;
        }
        isVideo = true;
      }
      if (isEdit && file != null) {
        Navigator.of(navigationService.currentContext).push(MaterialPageRoute(builder: (_) => NewPostPage(filePath: file.path, isVideo: isVideo)));
      } else {
        navigationService.pop(_map);
      }
    }
  }

  _cropImage(String filePath) async {
    return await ImageCropper.cropImage(
        sourcePath: filePath,
        // aspectRatio: CropAspectRatio(ratioX: screenWidth(navigationService.currentContext), ratioY: screenHeight(navigationService.currentContext)),
        aspectRatio: CropAspectRatio(ratioX: 9, ratioY: 16),
        androidUiSettings: AndroidUiSettings(
          toolbarTitle: 'Crop Image',
          toolbarColor: PrimaryColor,
          toolbarWidgetColor: WhiteColor,
          hideBottomControls: true,
        ),
        iosUiSettings: IOSUiSettings(minimumAspectRatio: 1.0));
  }

  onCloseButton() => navigationService.pop();

  onFlash() {
    var flashMode = cameraController?.value?.flashMode;
    var mode = (flashMode == FlashMode.off)
        ? FlashMode.auto
        : (flashMode == FlashMode.always)
            ? FlashMode.off
            : /*(flashMode == FlashMode.auto) ?*/ FlashMode.always;
    setFlashMode(mode).then((value) => _initFlashIcon(mode));
  }

  changeCamera() {
    var direction = (selectedCamera.lensDirection == CameraLensDirection.back) ? CameraLensDirection.front : CameraLensDirection.back;
    for (var camera in cameras) {
      if (camera.lensDirection == direction) {
        _initNewCamera(camera);
        break;
      }
    }
  }

  changePhoto() {
    isImageCapture = true;
    notifyListeners();
  }

  changeVideo() {
    isImageCapture = false;
    notifyListeners();
  }

  Future<void> setFlashMode(FlashMode mode) async {
    if (cameraController == null) return;
    try {
      await cameraController.setFlashMode(mode);
    } on CameraException catch (e) {
      print(e);
      rethrow;
    }
  }
}
