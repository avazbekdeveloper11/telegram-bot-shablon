import 'package:facetap/models/posts_model.dart';
import 'package:facetap/pages/content_page/views/view_post_page.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class SavedPostsViewModel extends BaseViewModel {
  final PostsService _postsService = locator<PostsService>();
  List<PostModel> savedPosts = [];
  PagingController pagingController = PagingController<int, PostModel>(firstPageKey: 1);

  @override
  void initState() {
    pagingController.addPageRequestListener((pageKey) => fetchSaved(pageKey));
    super.initState();
  }

  @override
  void onDispose() {
    pagingController.dispose();
    super.onDispose();
  }

  onBackPressed() => navigationService.pop();

  fetchSaved(int pageKey) async {
    if (pageKey == 1) {
      pagingController?.itemList?.clear();
      notifyListeners();
    }
    try {
      final _response = await _postsService.getSavedPosts(pageKey, 20).onError((error, stackTrace) => onError(error));
      final isLastPage = (pagingController.itemList ?? []).length == _response.count || (_response.results ?? []).isEmpty;
      isLastPage ? pagingController.appendLastPage(_response.results) : pagingController.appendPage(_response.results, pageKey + 1);
    } catch (error) {
      pagingController.error = error;
    }
  }

  onViewPostClicked(PostModel post) async {
    bool _isNeedUpdate = await navigationService.push(MaterialPageRoute(builder: (_) => ViewPostPage(isNavigatorPop: true, post: post)));
    print('======= upd : $_isNeedUpdate');
    if (_isNeedUpdate) fetchSaved(1);
  }
}
