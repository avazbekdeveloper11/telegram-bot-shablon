import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/views/image_category.dart';
import 'package:facetap/global_widgets/views/infinite_list_empty.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/pages/saved_posts_page/view_model/saved_posts_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class SavedPostsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SavedPostsViewModel>.reactive(
      initState: (model) => model.initState(),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => SavedPostsViewModel(),
      builder: (context, model, _) {
        return Scaffold(
          backgroundColor: DarkWindowColor,
          appBar: AppBar(
            centerTitle: true,
            title: Text('Favorites', style: Regular),
            leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
            elevation: 0,
            backgroundColor: Transparent,
          ),
          body: Stack(
            children: [
              NoScrollGlow(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 8.0, right: 16.0, left: 16.0),
                    child: PagedGridView<int, PostModel>(
                      padding: EdgeInsets.only(bottom: 8.0, top: 8.0),
                      shrinkWrap: true,
                      pagingController: model.pagingController,
                      builderDelegate: PagedChildBuilderDelegate<PostModel>(
                        itemBuilder: (context, item, index) => ImageTemplate(post: item, onViewPostClicked: () => model.onViewPostClicked(item)),
                        firstPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                        newPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                        noItemsFoundIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                      ),
                      gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 150, mainAxisSpacing: 2.0),
                    ),
                  ),
                ),
              ),
              model.isloading ? Loading() : Container()
            ],
          ),
        );
      },
    );
  }
}
