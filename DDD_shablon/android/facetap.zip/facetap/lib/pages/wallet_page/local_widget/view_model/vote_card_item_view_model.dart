import 'package:facetap/state_manager/manager.dart';

class VoteCardViewModel extends BaseViewModel {}
