import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/vote_cards_model.dart';
import 'package:facetap/pages/wallet_page/local_widget/view_model/vote_card_item_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class VoteCardItem extends StatelessWidget {
  final VoteCardModel voteCard;

  const VoteCardItem({Key key, this.voteCard}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<VoteCardViewModel>.reactive(
      viewModelBuilder: () => VoteCardViewModel(),
      builder: (context, model, _) {
        return Container(
          decoration: BoxDecoration(border: Border.all(color: GrayColor, width: 1.0), borderRadius: BorderRadius.circular(8.0), color: Transparent),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsets.only(right: 10.0),
                    child: SvgPicture.asset(Assets.svgDiamond, width: 24, height: 24),
                  ),
                  Text('${voteCard.qty}', style: Bold.copyWith(color: WhiteColor, fontSize: 20.0)),
                ],
              ),
              Padding(
                padding: EdgeInsets.only(top: 8.0),
                child: Text('for ${voteCard.price} US\$', style: Regular.copyWith(color: Color(0xFFAAABAD), fontSize: 14.0)),
              ),
            ],
          ),
        );
      },
    );
  }
}
