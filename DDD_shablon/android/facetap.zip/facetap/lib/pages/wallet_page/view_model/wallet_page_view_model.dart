import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:facetap/models/user_model.dart';
import 'package:facetap/models/vote_cards_model.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_ios/store_kit_wrappers.dart';

class WalletViewModel extends BaseViewModel {
  final UserModel _userModel = locator<UserModel>();
  final UserService _userService = locator<UserService>();
  List<VoteCardModel> voteCardsList = [];

  int votes = 0;
  Set<String> _productIds;

  // InAppPurchaseConnection _connection = InAppPurchaseConnection.instance; // IAP interface
  List<ProductDetails> _products = []; // products for sale
  StreamSubscription<List<PurchaseDetails>> _subscription; // updates to purchases
  VoteCardModel selectedVote;
  static const platform = MethodChannel('samples.flutter.dev/in_app_purchase');

  @override
  void initState() {
    votes = _userModel.votes;
    fetchUserVotes();
    super.initState();
  }

  @override
  void onDispose() {
    _subscription?.cancel();
    super.onDispose();
  }

  fetchUserVotes() async {
    setState(LoadingState.loading);
    UserVotes _response = await _userService.getUserVotes().onError((error, stackTrace) => onError(error));
    if (_response != null) {
      _userModel.votes = _response.votes;
      votes = _userModel.votes;
      fetchVoteCards();
    }
    notifyListeners();
  }

  void onBackPressed() => navigationService.pop();

  fetchVoteCards() async {
    VoteCardsModel _response = await _userService.getVoteCards(page: 1, limit: 20).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      voteCardsList.addAll(_response.results);
      List<String> mIds = [];
      voteCardsList.forEach((element) => mIds.add(element.purchaseId));
      _productIds = Set.from(mIds);
      _initIAP();
      setState(LoadingState.idle);
    }
    notifyListeners();
  }

  onCardPressed(int index) {
    if (_products.isNotEmpty) {
      _products.forEach((element) {
        if (element.id == _productIds.elementAt(index)) {
          selectedVote = voteCardsList[index];
          defaultTargetPlatform == TargetPlatform.android ? _buyProductForAndroid(element.id) : _buyProduct(element);
        }
      });
    }
  }

  Future<void> getResult() async {
    // final String result = await platform.invokeMethod('a');
    // print("===== $result");
    List<String> _ids = [];
    _productIds.forEach((element) {
      _ids.add(element);
    });
    final String result = await platform.invokeMethod('init_payment', {"product_ids": _ids});
    List<dynamic> products = jsonDecode(result);
    print("=====value $result");
    _products.clear();
    for (Map skuDetails in products) {
      ProductDetails prod = ProductDetails(
          rawPrice: skuDetails['rawPrice'],
          id: skuDetails['productId'],
          description: skuDetails['description'],
          title: skuDetails['title'],
          currencyCode: skuDetails['currencyCode'],
          price: skuDetails['price']);
      _products.add(prod);
    }
    // Map<String, dynamic> productsMap = jsonDecode(result);
    // SkuDetails.fromJson(productsMap);
    // Map<String, dynamic> user = jsonDecode(jsonString);
  }

  _initIAP() async {
    print('===== start iap');
    if (defaultTargetPlatform == TargetPlatform.android) {
      getResult();
    } else {
      await initStoreInfo();
      _subscription = InAppPurchase.instance.purchaseStream.listen(
        (data) {
          _listenToPurchaseUpdated(data);
          notifyListeners();
        },
        onDone: () => _subscription.cancel(),
        onError: (error) => print('purchase error => $error'),
      );
    }
  }

  _listenToPurchaseUpdated(List<PurchaseDetails> purchaseDetailsList) {
    purchaseDetailsList.forEach((PurchaseDetails purchaseDetails) async {
      if (purchaseDetails.status == PurchaseStatus.pending) {
        setState(LoadingState.loading);
      } else {
        if (purchaseDetails.status == PurchaseStatus.error) {
          setState(LoadingState.idle);
          print('error');
        } else if (purchaseDetails.status == PurchaseStatus.purchased) {
          setState(LoadingState.idle);
          fetchVotesPayed();
        }
        if (purchaseDetails.pendingCompletePurchase) {
          await InAppPurchase.instance.completePurchase(purchaseDetails);
        }
      }
    });
  }

  initStoreInfo() async {
    // bool available = await InAppPurchaseConnection.instance.isAvailable();
    // print('available: $available');
    ProductDetailsResponse productDetailResponse = await InAppPurchase.instance.queryProductDetails(_productIds);
    productDetailResponse.notFoundIDs.forEach((element) {
      print('Purchase $element not found');
    });
    // if (productDetailResponse.error == null) {
    _products = productDetailResponse.productDetails;
    print(' _products length : ${_products.length}');

    for (var value in voteCardsList) {
      List<VoteCardModel> voteCards = [];
      _products.forEach((element) {
        if (element.id == value.purchaseId) {
          value.price = element.rawPrice;
          voteCards.add(value);
        } else {
          voteCards.add(value);
        }
      });
    }
    notifyListeners();
    // }
  }

  _buyProductForAndroid(String id) async {
    print('buy_android');
    final String result = await platform.invokeMethod('launchPayment', {"id": id});
    if (result == "success") {
      fetchVotesPayed();
    } else {
      print("canceled");
    }
  }

  _buyProduct(ProductDetails prod) async {
    print('buy');
    InAppPurchase.instance.buyConsumable(purchaseParam: PurchaseParam(productDetails: prod));
    var transactions = await SKPaymentQueueWrapper().transactions();
    transactions.forEach((skPaymentTransactionWrapper) => SKPaymentQueueWrapper().finishTransaction(skPaymentTransactionWrapper));
  }

  void fetchVotesPayed() async {
    Map<String, dynamic> data =
        serializer.prepareDataToPay(method: Platform.isIOS ? 'apple_pay' : 'google_pay', userId: _userModel.id, voteCardId: selectedVote?.id);
    bool _response = await _userService.createPayment(data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      // print('success ${selectedVote?.qty}');
      // showSnackbar('success');
    }
    print('success ${selectedVote?.qty}');
    votes += selectedVote?.qty;
    selectedVote = null;
    _userModel.votes = votes;
    notifyListeners();
  }
}
