import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/pages/wallet_page/local_widget/views/vote_card_item.dart';
import 'package:facetap/pages/wallet_page/view_model/wallet_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class WalletPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<WalletViewModel>.reactive(
      initState: (model) => model.initState(),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => WalletViewModel(),
      builder: (context, model, _) {
        return Stack(
          children: [
            Scaffold(
              backgroundColor: DarkWindowColor,
              appBar: AppBar(
                leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
                backgroundColor: Transparent,
                elevation: 0,
                centerTitle: true,
                title: Text('Wallet', style: Regular),
              ),
              body: NoScrollGlow(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        color: Color(0xff1d1d1d),
                        child: Column(
                          children: [
                            Padding(
                              padding: EdgeInsets.only(left: 16, top: 24, bottom: 16),
                              child: Text('Balance', style: Regular.copyWith(color: WhiteColor, fontSize: 13.0)),
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 16, bottom: 24),
                              child: Row(
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(right: 10.0),
                                    child: SvgPicture.asset(Assets.svgDiamond, width: 32, height: 32),
                                  ),
                                  Text('${model.votes}', style: Bold.copyWith(color: WhiteColor, fontSize: 32.0)),
                                ],
                              ),
                            ),
                          ],
                          crossAxisAlignment: CrossAxisAlignment.start,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 16.0, top: 24.0),
                        child: Text('Redeem', style: Medium.copyWith(color: WhiteColor, fontSize: 17.0)),
                      ),
                      GridView.builder(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 3 / 2,
                          mainAxisSpacing: 12.0,
                          crossAxisSpacing: 12.0,
                        ),
                        padding: EdgeInsets.only(left: 16.0, right: 16.0, top: 16.0),
                        itemCount: model.voteCardsList.length,
                        itemBuilder: (_, index) => GestureDetector(
                          onTap: () => model.onCardPressed(index),
                          child: VoteCardItem(voteCard: model.voteCardsList[index]),
                        ),
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        physics: BouncingScrollPhysics(),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            model.isloading ? Loading() : Container()
          ],
        );
      },
    );
  }
}
