import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class PersonalInformationViewModel extends BaseViewModel {
  TextEditingController emailController;
  TextEditingController numberController;
  TextEditingController genderController;
  TextEditingController dataController;

  @override
  void initState() {
    super.initState();
    dataController = TextEditingController();
    emailController = TextEditingController();
    numberController = TextEditingController();
    genderController = TextEditingController();
  }

  @override
  void onDispose() {
    emailController.dispose();
    numberController.dispose();
    genderController.dispose();
    dataController.dispose();
    super.onDispose();
  }
}
