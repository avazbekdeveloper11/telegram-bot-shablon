import 'dart:convert';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/places_model.dart';
import 'package:facetap/models/register_model.dart';
import 'package:facetap/models/upload_url_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/camera_page/views/camera_page.dart';
import 'package:facetap/pages/edit_profile_page/local_widgets/views/image_preview_page.dart';
import 'package:facetap/pages/edit_profile_page/views/personal_information_page.dart';
import 'package:facetap/pages/home_page/views/home_screen.dart';
import 'package:facetap/pages/new_post_page/views/add_location_page.dart';
import 'package:facetap/providers/base_class_provider.dart';
import 'package:facetap/services/media_upload_service.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/base_view_model.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

class EditProfileViewModel extends BaseViewModel {
  final UserModel _userModel = locator<UserModel>();
  final UserService _userService = locator<UserService>();
  final MediaUploadService _uploadService = locator<MediaUploadService>();

  GlobalKey<FormState> infoKey = GlobalKey<FormState>();
  TextEditingController firstNameController;
  TextEditingController lastNameController;
  TextEditingController usernameController;
  TextEditingController emailController;
  TextEditingController bioController;

  File editAvatar;
  File editBanner;
  String avatarFileId = '';
  String bannerFileId = '';
  String metadata;

  @override
  void initState() {
    firstNameController = TextEditingController(text: _userModel.firstName);
    lastNameController = TextEditingController(text: _userModel.lastName);
    usernameController = TextEditingController(text: _userModel.username);
    emailController = TextEditingController(text: _userModel.email);
    bioController = TextEditingController(text: _userModel.bio);
    super.initState();
  }

  @override
  void dispose() {
    firstNameController.dispose();
    lastNameController.dispose();
    usernameController.dispose();
    emailController.dispose();
    bioController.dispose();
    super.dispose();
  }

  onBackPressed() => navigationService.pop();

  imgFromCamera() async {
    onBackPressed();
    Map<String, dynamic> _map = await navigationService.push(MaterialPageRoute(builder: (_) => CameraPage(withVideo: false)));
    if (_map['path'] != null && _map['path'].isNotEmpty) {
      File croppedFile = await _cropImage(_map['path']);
      if (croppedFile != null) {
        metadata == 'avatar' ? editAvatar = croppedFile : editBanner = croppedFile;
        generateUrl(metadata == 'avatar' ? editAvatar : editBanner);
        // uploadFile(metadata == 'avatar' ? editAvatar : editBanner);
      }
    }
    notifyListeners();
  }

  imgFromGallery() async {
    onBackPressed();
    AssetPicker.pickAssets(
      navigationService.currentContext,
      maxAssets: 1,
      textDelegate: EnglishTextDelegate(),
      requestType: RequestType.image,
    ).then((List<AssetEntity> _assets) async {
      if (_assets != null) {
        _assets.first.file.then((value) async {
          File croppedFile = await _cropImage(value.path);
          if (croppedFile != null) {
            metadata == 'avatar' ? editAvatar = croppedFile : editBanner = croppedFile;
            generateUrl(metadata == 'avatar' ? editAvatar : editBanner);
            // uploadFile(metadata == 'avatar' ? editAvatar : editBanner);
          } else {
            print('No image selected.');
          }
        });
      }
    });
    notifyListeners();
  }

  _cropImage(String filePath) async {
    return await ImageCropper.cropImage(
        compressQuality: 50,
        sourcePath: filePath,
        aspectRatio: metadata == 'avatar'
            ? CropAspectRatio(ratioX: screenWidth(navigationService.currentContext), ratioY: screenWidth(navigationService.currentContext))
            : CropAspectRatio(
                ratioX: screenWidth(navigationService.currentContext) * (5 / 3), ratioY: screenWidth(navigationService.currentContext) * (3 / 5)),
        aspectRatioPresets: [metadata == 'avatar' ? CropAspectRatioPreset.square : CropAspectRatioPreset.ratio5x3],
        androidUiSettings: AndroidUiSettings(
          toolbarTitle: metadata == 'avatar' ? 'Crop Avatar' : 'Crop Banner',
          toolbarColor: PrimaryColor,
          toolbarWidgetColor: WhiteColor,
          hideBottomControls: true,
        ),
        iosUiSettings: IOSUiSettings(
          aspectRatioLockDimensionSwapEnabled: true,
          aspectRatioPickerButtonHidden: true,
          aspectRatioLockEnabled: true,
          rotateButtonsHidden: true,
        ));
  }

  removeImage() {
    onBackPressed();
    if (metadata == 'avatar') {
      avatarFileId = 'delete';
      editAvatar = null;
      _userModel.profilePhoto = '';
    } else {
      bannerFileId = 'delete';
      editBanner = null;
      _userModel.profileBanner = '';
    }
    notifyListeners();
  }

  onNavigatorPersonalInformationPage() => navigationService.push(MaterialPageRoute(builder: (_) => PersonalInformationPage()));

  onSaveButton() async {
    if (!infoKey.currentState.validate()) return;
    setState(LoadingState.loading);
    Map<String, dynamic> data = serializer.prepareDataToUpdateProfile(
      bio: bioController.text,
      firstName: firstNameController.text,
      lastName: lastNameController.text,
      profilePhoto: avatarFileId,
      profileBanner: bannerFileId,
      username: usernameController.text,
      locationName: _userModel.locationName,
    );

    UserModel _response = await _userService.updateProfile(data: data).onError((error, stackTrace) => onError(error));

    if (_response != null) {
      showSnackBar('User information saved');
      _userModel.bio = bioController.text;
      _userModel.firstName = firstNameController.text;
      _userModel.lastName = lastNameController.text;
      _userModel.username = usernameController.text;
    }
    _userModel.email == emailController.text ? onSaveEnd() : updateEmail();
  }

  Widget userImage() => Stack(
        children: [
          CircleAvatar(
            radius: 50.0,
            backgroundColor: TextFromFieldHintColor,
            child: editAvatar != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Image.file(editAvatar, width: 100, height: 100, fit: BoxFit.cover),
                  )
                : _userModel.profilePhoto.isNotEmpty
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(50.0),
                        child: CachedNetworkImage(
                          imageUrl: getProfileImageUrl(navigationService.currentContext),
                          fit: BoxFit.cover,
                          height: 100.0,
                          width: 100.0,
                          placeholder: (context, url) => Container(color: TextFromFieldHintColor),
                        ),
                      )
                    : SvgPicture.asset(Assets.svgAvatarPlaceholder),
          ),
          CircleAvatar(
            radius: 50.0,
            backgroundColor: DarkWindowColor.withOpacity(0.3),
            child: SvgPicture.asset(Assets.svgCameraEdit),
          ),
        ],
      );

  final double bannerHeight = 240.0;

  Widget userBanner() => Container(
        width: screenWidth(navigationService.currentContext),
        height: bannerHeight,
        color: WhiteColor.withOpacity(0.1),
        child: Stack(
          children: [
            ClipRRect(
              child: editBanner != null
                  ? Image.file(editBanner, fit: BoxFit.cover, height: bannerHeight, width: screenWidth(navigationService.currentContext))
                  : _userModel.profileBanner.isNotEmpty
                      ? CachedNetworkImage(
                          imageUrl: _userModel.profileBanner,
                          fit: BoxFit.cover,
                          height: bannerHeight,
                          width: screenWidth(navigationService.currentContext),
                          placeholder: (context, url) => Container(color: TextFromFieldHintColor),
                        )
                      : Container(),
            ),
            Container(
              height: bannerHeight,
              width: screenWidth(navigationService.currentContext),
              color: DarkWindowColor.withOpacity(0.3),
            )
          ],
        ),
      );

  updateEmail() async {
    Map<String, dynamic> data = serializer.prepareDataToUpdateEmail(email: emailController.text);

    RegisterModel _response = await _userService.updateEmail(data: data).onError((error, stackTrace) => onError(error));

    if (_response != null) {
      showSnackBar(_response.result);
      _userModel.email = emailController.text;
    }
    onSaveEnd();
  }

  onSaveEnd() {
    setState(LoadingState.idle);
    navigationService.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => HomePage(defaultIndex: 4)));
  }

  generateUrl(File file) async {
    setState(LoadingState.loading);
    GenerateUrlListModel files = GenerateUrlListModel(list: [GenerateUrlModel(contentType: 'image/jpeg', metadata: metadata)]);

    UploadUrlModel _response = await _uploadService.generateUploadUrl(json: jsonEncode(files)).onError((error, stackTrace) => onError(error));
    _response != null ? uploadToServer(_response, file) : showSnackBar('Error occurred');
  }

  uploadToServer(UploadUrlModel uploadUrlModel, File file) async {
    UrlModel urlModel = uploadUrlModel.uploadUrls.first;
    bool _response = await _uploadService
        .uploadToServer(url: urlModel.url, contentType: 'image/jpeg', metaType: urlModel.metadata, data: file.readAsBytesSync())
        .onError((error, stackTrace) => onError(error));

    metadata == 'avatar' ? avatarFileId = urlModel.filename : bannerFileId = urlModel.filename;
    if (_response != null) showSnackBar('File uploaded');
    setState(LoadingState.idle);
    notifyListeners();
  }

  uploadFile(File file) async {
    setState(LoadingState.loading);
    Map<String, dynamic> data = serializer.prepareDataToUploadFile(content: file.readAsBytesSync(), contentType: 'image/jpeg', metadata: metadata);
    UploadFile _response = await _uploadService.uploadFile(data: data).onError((error, stackTrace) => onError(error));
    metadata == 'avatar' ? avatarFileId = _response.filename : bannerFileId = _response.filename;
    if (_response != null) showSnackBar('File uploaded');
    setState(LoadingState.idle);
    notifyListeners();
  }

  openImagePreview() {
    onBackPressed();
    navigationService.push(MaterialPageRoute(
      builder: (_) => ImagePreviewPage(url: metadata == 'avatar' ? _userModel.profilePhoto : _userModel.profileBanner),
    ));
  }

  onImageChange(String title, String metadata) {
    this.metadata = metadata;
    showModalBottomSheet(
      backgroundColor: BottomSheetColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(12.0), topRight: Radius.circular(12.0))),
      context: navigationService.currentContext,
      builder: (BuildContext bc) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Center(child: Text(title, style: Regular.copyWith(fontSize: 16.0, color: TextFromFieldHintColor))),
              onTap: openImagePreview,
            ),
            ListTile(
              title: Center(child: Text('Photo Library', style: Regular.copyWith(fontSize: 16.0, color: TextFromFieldHintColor))),
              onTap: imgFromGallery,
            ),
            ListTile(
              title: Center(child: Text('Camera', style: Regular.copyWith(fontSize: 16.0, color: TextFromFieldHintColor))),
              onTap: imgFromCamera,
            ),
            ListTile(
              title: Center(child: Text('Remove $metadata', style: Regular.copyWith(fontSize: 16.0, color: AccentColor))),
              onTap: removeImage,
            ),
            ListTile(
              title: Center(child: Text('Cancel', style: Regular.copyWith(fontSize: 16.0, color: TextFromFieldHintColor))),
              onTap: onBackPressed,
            ),
          ],
        );
      },
    );
  }

  Position currentPosition;

  onAddAddressClicked() async {
    setState(LoadingState.loading);
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      /* Location services are not enabled don't continue accessing the position
      and request users of the App to enable the location services.*/
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        /* Permissions are denied, next time you could try requesting permissions again (this is also where
        Android's shouldShowRequestPermissionRationale returned true. According to Android guidelines
        your App should show an explanatory UI now. */
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error('Location permissions are permanently denied, we cannot request permissions.');
    }

    // When we reach here, permissions are granted and we can continue accessing the position of the device.
    currentPosition = await Geolocator.getCurrentPosition();
    gotoLocationPage();
  }

  gotoLocationPage() async {
    setState(LoadingState.idle);
    PlaceModel selectedPlace = await navigationService.push(MaterialPageRoute(builder: (_) => AddLocationPage(position: currentPosition)));
    if (selectedPlace != null) {
      _userModel.locationName = selectedPlace.formattedAddress ?? selectedPlace.name ?? 'default';
      notifyListeners();
    }
  }

  getLocationName() => Text(
        (_userModel.locationName ?? '').isNotEmpty ? _userModel.locationName : 'Select location',
        style: Regular.copyWith(color: WhiteColor.withOpacity(0.5)),
      );
}
