import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/content_loader.dart';
import 'package:facetap/pages/edit_profile_page/local_widgets/view_model/image_preview_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class ImagePreviewPage extends StatelessWidget {
  final String url;

  const ImagePreviewPage({Key key, @required this.url}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ImagePreviewViewModel>.reactive(
      viewModelBuilder: () => ImagePreviewViewModel(),
      builder: (context, model, _) {
        return Scaffold(
          backgroundColor: DarkWindowColor,
          body: Stack(
            children: [
              CachedNetworkImage(
                imageUrl: url,
                height: screenHeight(context),
                width: screenWidth(context),
                placeholder: (context, url) => ContentLoader(),
              ),
              AppBar(
                leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
                elevation: 0,
                backgroundColor: Transparent,
              ),
            ],
          ),
        );
      },
    );
  }
}
