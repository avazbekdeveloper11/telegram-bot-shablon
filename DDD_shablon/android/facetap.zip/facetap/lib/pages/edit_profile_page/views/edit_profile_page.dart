import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/scrollable_footer_layout.dart';
import 'package:facetap/global_widgets/views/changed_text_form_field.dart';
import 'package:facetap/global_widgets/views/subscribe_button.dart';
import 'package:facetap/pages/edit_profile_page/view_model/edit_profile_page_view_model.dart';
import 'package:facetap/pages/new_post_page/local_widget/views/new_post_template.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/validators.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class EditProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<EditProfileViewModel>.reactive(
      initState: (model) => model.initState(),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => EditProfileViewModel(),
      builder: (context, model, _) {
        return Stack(
          children: [
            Scaffold(
              backgroundColor: DarkWindowColor,
              body: NoScrollGlow(
                child: ScrollableFooterLayout(
                  children: [
                    Stack(
                      children: [
                        Stack(
                          alignment: Alignment.bottomCenter,
                          children: [
                            Padding(padding: EdgeInsets.only(bottom: 50.0), child: model.userBanner()),
                            GestureDetector(
                              onTap: () => model.onImageChange('Show profile picture', 'avatar'),
                              child: Padding(padding: EdgeInsets.symmetric(horizontal: 16.0), child: model.userImage()),
                            ),
                          ],
                        ),
                        AppBar(
                          centerTitle: true,
                          title: Text('Edit Profile', style: Regular),
                          leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
                          actions: [
                            IconButton(
                              icon: Icon(Icons.image_outlined, color: WhiteColor, size: 28.0),
                              onPressed: () => model.onImageChange('View profile cover picture', 'banner'),
                            ),
                          ],
                          elevation: 0,
                          backgroundColor: Transparent,
                        ),
                      ],
                    ),
                    Form(
                      key: model.infoKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ChangedTextFormField(
                            controller: model.firstNameController,
                            labelText: 'First name',
                            textInputType: TextInputType.text,
                            validator: (value) {
                              if (value.isEmpty) return 'Please enter First name';
                              return null;
                            },
                          ),
                          ChangedTextFormField(
                            controller: model.lastNameController,
                            labelText: 'Last name',
                            textInputType: TextInputType.text,
                            validator: (value) {
                              if (value.isEmpty) return 'Please enter Last name';
                              return null;
                            },
                          ),
                          ChangedTextFormField(
                            controller: model.usernameController,
                            labelText: 'Username',
                            textInputType: TextInputType.text,
                            validator: (value) {
                              if (value.isEmpty) return 'Please enter Username';
                              return null;
                            },
                          ),
                          ChangedTextFormField(
                            controller: model.emailController,
                            labelText: 'Email',
                            textInputType: TextInputType.text,
                            validator: (value) {
                              if (value.isEmpty) return 'Please enter Email';
                              if (!isEmailValidate(value)) return 'Please enter correct Email';
                              return null;
                            },
                          ),
                          ChangedTextFormField(
                            controller: model.bioController,
                            labelText: 'Bio',
                            textInputType: TextInputType.text,
                            inputFormatters: [LengthLimitingTextInputFormatter(200)],
                          ),
                          SwitchTemplate(
                            title: 'Location',
                            isBorderVisible: false,
                            onTap: model.onAddAddressClicked,
                            child: Row(
                              children: [
                                model.getLocationName(),
                                Icon(Icons.keyboard_arrow_right, color: WhiteColor),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  footer: Padding(
                    padding: EdgeInsets.only(left: 16.0, right: 16.0, bottom: 24.0),
                    child: SubscribeButton(
                      onTap: model.onSaveButton,
                      buttonColor: WhiteColor,
                      isBorderColored: true,
                      text: 'Save',
                      isColorText: false,
                      fontSize: 16.0,
                    ),
                  ),
                ),
              ),
            ),
            model.isloading ? Loading() : Container(),
          ],
        );
      },
    );
  }
}
