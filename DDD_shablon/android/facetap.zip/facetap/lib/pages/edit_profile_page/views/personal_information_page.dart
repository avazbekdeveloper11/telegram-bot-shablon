import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/views/changed_text_form_field.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/pages/edit_profile_page/view_model/personal_information_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class PersonalInformationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PersonalInformationViewModel>.reactive(
      initState: (model) => model.initState(),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => PersonalInformationViewModel(),
      builder: (context, model, _) {
        return BaseClass(
          child: Container(
            color: PrimaryDarkColor.withOpacity(0.5),
            child: Scaffold(
              backgroundColor: PrimaryDarkColor.withOpacity(0.7),
              appBar: AppBar(elevation: 0, backgroundColor: Transparent),
              body: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                          child: Text("Personal Information",
                              style: Medium.copyWith(fontSize: 32.0, color: WhiteColor))),
                      ChangedTextFormField(
                          labelBehavior: true,
                          controller: model.emailController,
                          labelText: "Email address",
                          hintText: "Enter your email address",
                          textInputType: TextInputType.text),
                      ChangedTextFormField(
                          labelBehavior: true,
                          controller: model.numberController,
                          labelText: "Phone number",
                          hintText: "+998995375611",
                          textInputType: TextInputType.phone),
                      ChangedTextFormField(
                          labelBehavior: true,
                          controller: model.genderController,
                          labelText: "Gender",
                          hintText: "Male",
                          textInputType: TextInputType.text),
                      ChangedTextFormField(
                          labelBehavior: true,
                          controller: model.dataController,
                          labelText: "Data of birth",
                          hintText: "19 Jun 2001",
                          textInputType: TextInputType.text),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
