import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/views/image_category.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/view_model/hash_tag_grid_page_view_model.dart';
import 'package:facetap/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:facetap/state_manager/manager.dart';

class HashTagGridPage extends StatelessWidget {
  final String hashTagName;

  const HashTagGridPage({Key key, this.hashTagName}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<HashTagGridViewModel>.reactive(
      viewModelBuilder: () => HashTagGridViewModel(),
      builder: (context, model, _) {
        return BaseClass(
          child: Container(
              color: PrimaryDarkColor.withOpacity(0.5),
              child: Stack(
                children: [
                  Scaffold(
                    backgroundColor: PrimaryDarkColor.withOpacity(0.7),
                    appBar: AppBar(
                      elevation: 0,
                      backgroundColor: Transparent,
                      title: Text(hashTagName),
                    ),
                    body: GridView.builder(
                      padding: EdgeInsets.only(bottom: 8.0, top: 8.0),
                      shrinkWrap: true,
                      gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                        maxCrossAxisExtent: 150,
                        mainAxisSpacing: 2.0,
                      ),
                      itemCount: 20,
                      itemBuilder: (BuildContext ctx, index) {
                        return ImageTemplate();
                      },
                    ),
                  ),
                  // model.isloading ? Loading() : Container(),
                ],
              )),
        );
      },
    );
  }
}
