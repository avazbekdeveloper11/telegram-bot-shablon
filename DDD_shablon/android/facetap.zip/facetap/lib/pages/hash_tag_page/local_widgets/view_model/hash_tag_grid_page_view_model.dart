import 'package:facetap/state_manager/manager.dart';

class HashTagGridViewModel extends BaseViewModel {}
