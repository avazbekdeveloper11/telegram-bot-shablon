import 'package:facetap/global_widgets/views/image_category.dart';
import 'package:facetap/global_widgets/views/infinite_list_empty.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/search_model.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/view_model/location_view_model.dart';
import 'package:facetap/state_manager/src/view_model_builder.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class LocationPostSearch extends StatelessWidget {
  final  SearchPost searchModel;
  const LocationPostSearch({Key key, @required this.searchModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LocationViewModel>.reactive(
        initState: (model) => model.initData(searchModel),
        viewModelBuilder: () => LocationViewModel(),
        builder: (context, model, _) {
          return  Scaffold(
            backgroundColor: PrimaryDarkColor.withOpacity(0.7),
            body: searchModel == null
                ? Container()
                : Container(
              padding: EdgeInsets.all(8),
              color: Colors.transparent,
              width: screenWidth(context),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 36, 0, 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(onPressed: ()=>model.popLocation(), icon: Icon(Icons.arrow_back_ios,color: WhiteColor)),
                          Text(searchModel.title,
                              style: Medium.copyWith(color: WhiteColor, fontSize: 24), textAlign: TextAlign.center),
                          SizedBox(width: 32,)
                        ],
                      ),
                    ),
                    PagedGridView<int, PostModel>(
                      padding: EdgeInsets.only(bottom: 8.0, top: 8.0),
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      pagingController: model.pagingController,
                      builderDelegate: PagedChildBuilderDelegate<PostModel>(
                        itemBuilder: (context, item, index) => ImageTemplate(post: item,  onViewPostClicked: () => model.onViewPostClicked(item),),
                        firstPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                        newPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                        noItemsFoundIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                      ),
                      gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 150, mainAxisSpacing: 2.0),
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }
}
