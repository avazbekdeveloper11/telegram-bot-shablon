import 'package:facetap/models/search_model.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/views/location.dart';
import 'package:facetap/pages/profile_page/views/profile_page.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class UserSearchViewModel extends BaseViewModel {
  final PostsService _postsService = locator<PostsService>();

  onNavigationProfilePage(SearchPosts searchModel, int index) async {
    await createPost(searchModel.res[index]);
    switch (searchModel.res[index].type) {
      case 'user':
        navigationService.push(MaterialPageRoute(builder: (_) => ProfilePage(userId: searchModel.res[index].id, isNavigatorPop: true)));
        break;
      case 'location':
        navigationService.push(MaterialPageRoute(builder: (_) => LocationPostSearch(searchModel: searchModel.res[index])));
        break;
      case 'hashtag':
        navigationService.push(MaterialPageRoute(builder: (_) => LocationPostSearch(searchModel: searchModel.res[index])));
        break;
    }
  }

  createPost(SearchPost searchPost) async {
    SearchPost _response = await _postsService.userSearchPosts(data: {
      "description": searchPost.description,
      "id": searchPost.id,
      "profile_photo": searchPost.profilePhoto,
      "title": searchPost.title,
      "type": searchPost.type
    }).onError((error, stackTrace) => onError(error));

    if (_response != null) {}
    setState(LoadingState.idle);
  }
}
