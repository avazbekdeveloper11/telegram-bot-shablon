import 'package:facetap/apis/errors.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/search_model.dart';
import 'package:facetap/pages/content_page/views/view_post_page.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class LocationViewModel extends BaseViewModel {
  final PostsService _postService = locator<PostsService>();
  final limit = 20;


  PagingController pagingController = PagingController<int, PostModel>(firstPageKey: 1);

  popLocation() {
    navigationService.pop();
  }

  void initData(SearchPost searchModel) {
    pagingController.addPageRequestListener((pageKey) {
      print(1234567);
      fetchPosts(pageKey, searchModel);
    });

    super.initState();
  }

  @override
  void onDispose() {
    pagingController.dispose();
    super.onDispose();
  }

  onViewPostClicked(PostModel post) async {
 await navigationService.push(MaterialPageRoute(builder: (_) => ViewPostPage(isNavigatorPop: true, post: post)));
  }

  void fetchPosts(int pageKey, SearchPost searchModel) async {
    print(pageKey);
    try {
      final _response = await _postService
          .locationPosts(locationName: searchModel.title, page: pageKey, limit: limit, isLocation: searchModel.type == 'location')
          .onError((error, stackTrace) => onError(error));
      final isLastPage = (pagingController.itemList ?? []).length == _response.count || (_response.results ?? []).isEmpty;
      isLastPage ? pagingController.appendLastPage(_response.results) : pagingController.appendPage(_response.results, pageKey + 1);
    } catch (error) {
      pagingController.error = error;
    }
  }

  @override
  Future<T> onError<T extends Object>(error) {
    if (error == ApiClientErrors.BAD_REQUEST) showSnackBar('Invalid credentials');
    return super.onError(error);
  }
}
