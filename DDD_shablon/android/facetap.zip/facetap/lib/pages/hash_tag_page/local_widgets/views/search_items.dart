import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/models/search_model.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/view_model/post_search_view_model.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/view_model/user_search_view_model.dart';
import 'package:facetap/state_manager/src/view_model_builder.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class TopSearch extends StatelessWidget {
  final SearchModel searchModel;
  final bool resent;

  const TopSearch({Key key, @required this.searchModel, this.resent}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: screenWidth(context),
      padding: EdgeInsets.all(16),
      child: SingleChildScrollView(
        child: Column(
          children: [
            resent
                ? Container()
                : Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Users',
                        style: Bold.copyWith(fontSize: 16, color: WhiteColor),
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            'More',
                            style: Medium.copyWith(fontSize: 14, color: Color(0xffAAABAD)),
                          ),
                          SizedBox(
                            width: 8,
                          ),
                          Icon(Icons.arrow_forward_ios_rounded, size: 15, color: Color(0xffAAABAD))
                        ],
                      )
                    ],
                  ),
            UserSearch(
              searchPost: searchModel.users,
            ),
            Visibility(
              visible: !resent,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Ratings',
                    style: Bold.copyWith(fontSize: 16, color: WhiteColor),
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'More',
                        style: Medium.copyWith(fontSize: 14, color: Color(0xffAAABAD)),
                      ),
                      SizedBox(
                        width: 8,
                      ),
                      Icon(Icons.arrow_forward_ios_rounded, size: 15, color: Color(0xffAAABAD))
                    ],
                  )
                ],
              ),
            ),
            UserSearch(
              searchPost: searchModel.hashtags,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Places',
                  style: Bold.copyWith(fontSize: 16, color: WhiteColor),
                ),
                Text(
                  'More',
                  style: Medium.copyWith(fontSize: 14, color: Colors.transparent),
                )
              ],
            ),
            UserSearch(
              searchPost: searchModel.locations,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Posts',
                  style: Bold.copyWith(fontSize: 16, color: WhiteColor),
                ),
                Text(
                  'More',
                  style: Medium.copyWith(fontSize: 14, color: Colors.transparent),
                )
              ],
            ),
            SizedBox(
              height: 24,
            ),
            PostSearch(
              searchPost: searchModel.posts,
            )
          ],
        ),
      ),
    );
  }
}

class UserSearch extends StatelessWidget {
  final SearchPosts searchPost;

  const UserSearch({Key key, @required this.searchPost}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<UserSearchViewModel>.reactive(
        viewModelBuilder: () => UserSearchViewModel(),
        builder: (context, model, _) {
          return searchPost.res == null
              ? Container(
                  height: 60,
                )
              : Container(
                  width: screenWidth(context) - 32,
                  child: ListView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: searchPost.res.length,
                      itemBuilder: (BuildContext context, int index) {
                        double numberOfPosts = searchPost.res[index].type == 'hashtag' ? double.parse(searchPost.res[index].description) : 0;
                        return GestureDetector(
                          onTap: () => model.onNavigationProfilePage(searchPost, index),
                          child: Container(
                            color: Colors.transparent,
                            child: buildContainer(
                                context,
                                searchPost.res[index].type == 'user'
                                    ? searchPost.res[index].profilePhoto
                                    : searchPost.res[index].type == 'hashtag'
                                        ? 'assets/svg/hash_tag.svg'
                                        : 'assets/svg/geoIcon.svg',
                                searchPost.res[index].type == 'user',
                                searchPost.res[index].title,
                                searchPost.res[index].type == 'hashtag'
                                    ? "${numberOfPosts >= 1000000 ? '${(numberOfPosts / 1000000).ceil()} M' : numberOfPosts >= 1000 ? '${(numberOfPosts / 1000).ceil()} K' : numberOfPosts.toInt()} posts"
                                    : searchPost.res[index].description),
                          ),
                        );
                      }),
                );
        });
  }
}

class PostSearch extends StatelessWidget {
  final SearchPosts searchPost;

  const PostSearch({Key key, @required this.searchPost}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PostSearchViewModel>.reactive(
        viewModelBuilder: () => PostSearchViewModel(),
        builder: (context, model, _) {
          return searchPost.res == null
              ? Container()
              : Container(
                  color: Colors.transparent,
                  width: screenWidth(context),
                  child: GridView.builder(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: searchPost.res.length,
                    gridDelegate:
                        SliverGridDelegateWithFixedCrossAxisCount(childAspectRatio: 0.6, mainAxisSpacing: 6, crossAxisSpacing: 6, crossAxisCount: 2),
                    itemBuilder: (BuildContext context, int index) {
                      print(searchPost.res[index].description);
                      double numberOfPosts =
                          double.parse(searchPost.res[index].description.substring(0, searchPost.res[index].description.indexOf(',')));
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GestureDetector(
                            onTap: () => model.onNavigationPostPage(searchPost.res[index].id),
                            child: new Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                              ),
                              width: screenWidth(context) / 2 - 14,
                              child: Stack(
                                children: [
                                  CachedNetworkImage(
                                    imageUrl: searchPost.res[index].profilePhoto,
                                    fit: BoxFit.cover,
                                    width: screenWidth(context) / 2 - 14,
                                    height: (screenWidth(context) / 2 - 14) * 1.1,
                                    placeholder: (context, url) => Container(color: PrimaryLightColor),
                                  ),
                                  Container(
                                    width: screenWidth(context) / 2 - 14,
                                    height: (screenWidth(context) / 2 - 14) * 1.1,
                                    child: Align(
                                      alignment: Alignment.bottomRight,
                                      child: Padding(
                                        padding: const EdgeInsets.all(12),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              '${numberOfPosts >= 1000000 ? '${(numberOfPosts / 1000000).ceil()} M' : numberOfPosts >= 1000 ? '${(numberOfPosts / 1000).ceil()} K' : numberOfPosts.toInt()}',
                                              style: Bold.copyWith(fontSize: 16, color: WhiteColor),
                                            ),
                                            SizedBox(
                                              width: 4,
                                            ),
                                            SvgPicture.asset(
                                              'assets/svg/like_icon.svg',
                                              color: WhiteColor,
                                              height: 12,
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 12,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Text(
                                searchPost.res[index].title,
                                style: Medium.copyWith(fontSize: 15, color: WhiteColor),
                              ),
                              SizedBox(
                                height: 8,
                              ),
                              Row(
                                children: [
                                  CircleAvatar(
                                      radius: 9.0,
                                      backgroundColor: TextFromFieldHintColor,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(18.0),
                                        child: CachedNetworkImage(
                                          imageUrl:
                                              searchPost.res[index].description.substring(searchPost.res[index].description.lastIndexOf(',') + 1),
                                          fit: BoxFit.cover,
                                          height: 18,
                                          width: 18.0,
                                          placeholder: (context, url) => Container(color: PrimaryLightColor),
                                        ),
                                      )),
                                  SizedBox(
                                    width: 12,
                                  ),
                                  Text(
                                    searchPost.res[index].description.substring(
                                        searchPost.res[index].description.indexOf(',') + 1, searchPost.res[index].description.lastIndexOf(',')),
                                    style: Medium.copyWith(fontSize: 13, color: Color(0xff808185)),
                                  ),
                                ],
                              )
                            ],
                          )
                        ],
                      );
                    },
                  ),
                );
        });
  }
}

Container buildContainer(BuildContext context, String image, bool user, String title, String desc) {
  print(user);
  return Container(
    margin: EdgeInsets.symmetric(vertical: 12),
    width: screenWidth(context) - 32,
    height: 50,
    child: Row(
      children: [
        CircleAvatar(
          radius: 24.0,
          backgroundColor: TextFromFieldHintColor,
          child: user
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(48.0),
                  child: CachedNetworkImage(
                    imageUrl: image,
                    fit: BoxFit.cover,
                    height: 48,
                    width: 48.0,
                    placeholder: (context, url) => Container(color: PrimaryLightColor),
                  ),
                )
              : SvgPicture.asset(image),
        ),
        SizedBox(
          width: 12,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: screenWidth(context) - 100,
              child: Text(
                title,
                overflow: TextOverflow.ellipsis,
                style: Medium.copyWith(fontSize: 15, color: WhiteColor),
              ),
            ),
            Visibility(
              visible: desc != '',
              child: Container(
                width: screenWidth(context) - 100,
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  desc,
                  overflow: TextOverflow.ellipsis,
                  style: Medium.copyWith(fontSize: 14, color: Color(0xffAAABAD)),
                ),
              ),
            ),
          ],
        )
      ],
    ),
  );
}
