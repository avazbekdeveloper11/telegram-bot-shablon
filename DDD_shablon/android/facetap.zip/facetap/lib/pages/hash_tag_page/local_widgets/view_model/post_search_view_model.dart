
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/pages/content_page/views/view_post_page.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class PostSearchViewModel extends BaseViewModel {
  final PostsService _postsService = locator<PostsService>();


  onNavigationPostPage(String postId) async {
    var post = await getPost(postId);
    if (post != null)
      navigationService.push(MaterialPageRoute(builder: (_) => ViewPostPage(isNavigatorPop: true, post: post)));
    else
      showSnackBar('Post not available');
  }


  Future<PostModel> getPost(String postId) async {
    setState(LoadingState.loading);
    PostModel _response = await _postsService.getPost(postId: postId).onError((error, stackTrace) => onError(error));
    PostModel post;
    if (_response != null) {
      post = _response;
      notifyListeners();
    }
    setState(LoadingState.idle);
    return post;
  }
}