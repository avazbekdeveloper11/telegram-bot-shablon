import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/views/search_widget.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/view_model/search_suggest_view_model.dart';
import 'package:facetap/state_manager/src/view_model_builder.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class SearchSuggest extends StatefulWidget {
  const SearchSuggest({Key key}) : super(key: key);

  @override
  _SearchSuggestState createState() => _SearchSuggestState();
}

class _SearchSuggestState extends State<SearchSuggest> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SearchSuggestViewModel>.reactive(
      initState: (model) => model.initData(),
      viewModelBuilder: () => SearchSuggestViewModel(),
      builder: (context, model, _) {
        return BaseClass(
          child: Scaffold(
            resizeToAvoidBottomInset: false,
            backgroundColor: PrimaryDarkColor.withOpacity(0.7),
            body: Container(
              height: screenHeight(context),
              width: screenWidth(context),
              color: PrimaryDarkColor.withOpacity(0.7),
              child: NoScrollGlow(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.fromLTRB(16, 58, 16, 0),
                        height: 44,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              child: SearchWidget(
                                onEditingComplete: () {
                                  model.pop(model.searchController.text);
                                },
                                autofocus: true,
                                controller: model.searchController,
                                onTap: () {
                                  model.clearText();
                                },
                                hintText: 'Discover any topic',
                                onChangedSuffix: (v) {
                                  model.fetchSearch(v);
                                },
                              ),
                              width: screenWidth(context) * 5 / 7,
                            ),
                            SizedBox(
                              width: 12,
                            ),
                            TextButton(
                                onPressed: () => model.pop('a'),
                                child: Text(
                                  'Cancel',
                                  style: Regular.copyWith(fontSize: 15, color: Colors.white),
                                )),
                          ],
                        ),
                      ),
                      model.isloading
                          ? Loading()
                          : model.posts.isEmpty
                              ? Container()
                              : ListView.builder(
                                  padding: EdgeInsets.all(8),
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemCount: model.posts.length,
                                  itemBuilder: (context, index) => ListTile(
                                        onTap: () => model.pop(model.posts[index]),
                                        minLeadingWidth: 20,
                                        leading: Icon(Icons.search, color: Colors.white),
                                        title: Text(
                                          model.posts[index],
                                          style: Medium.copyWith(fontSize: 15, color: Colors.white),
                                        ),
                                        trailing: SvgPicture.asset('assets/svg/arrow_dioganal.svg'),
                                      ))
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
