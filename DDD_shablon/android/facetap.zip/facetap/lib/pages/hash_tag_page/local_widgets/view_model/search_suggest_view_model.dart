import 'package:facetap/models/search_model.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class SearchSuggestViewModel extends BaseViewModel {

  final PostsService _postsService = locator<PostsService>();

  TextEditingController searchController = TextEditingController();

  List<String> posts;


  initData() {
    fetchSearch('');
  }

  clearText(){
    searchController?.clear();
    notifyListeners();
  }

  onTab(index){
    notifyListeners();
  }

  pop(String text){
  Navigator.pop(navigationService.currentContext, text);
  }

  popSearch(BuildContext context){
    navigationService.pop();
  }

  void fetchSearch(String search,) async {
    setState(LoadingState.loading);
    SearchSuggestModel _response = await _postsService.suggestSearch(search: search).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      print('1');
      print(_response.count);
    posts=_response.searchTitles;
    }else{
      posts=[];
    }

    setState(LoadingState.idle);
    notifyListeners();
  }
}