import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/search_model.dart';
import 'package:facetap/pages/content_page/views/view_post_page.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/views/location.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class HashTagTemplateViewModel extends BaseViewModel {
  onHashTagHeaderTap(String hashTagName) =>
      navigationService.push(MaterialPageRoute(
          builder: (_) =>
              LocationPostSearch(searchModel: SearchPost(title: hashTagName, type: 'hashtag'))));


  onViewPostClicked(PostModel post) async {
   await navigationService.push(MaterialPageRoute(builder: (_) => ViewPostPage(isNavigatorPop: true, post: post)));
  }
}
