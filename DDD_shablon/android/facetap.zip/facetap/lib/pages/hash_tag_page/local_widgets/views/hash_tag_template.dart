import 'package:facetap/global_widgets/views/image_category.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/view_model/hash_tag_template_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class HashTagTemplate extends StatelessWidget {
  final String hashTagName;
  final int numberOfPosts;
  final int ratingNumber;
  final String imagePath;
  final List<PostModel> post;

  const HashTagTemplate({
    Key key,
    @required this.hashTagName,
    @required this.numberOfPosts,
    @required this.ratingNumber,
    @required this.imagePath,
    @required this.post,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<HashTagTemplateViewModel>.reactive(
      viewModelBuilder: () => HashTagTemplateViewModel(),
      builder: (context, model, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 25),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(right: 20.0),
                    child: SvgPicture.asset('assets/svg/bottom_bar_hash_tag_icon.svg',
                        color: WhiteColor),
                  ),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => model.onHashTagHeaderTap(hashTagName),
                      child: Container(
                        color: Colors.transparent,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              hashTagName,
                              style: Medium.copyWith(color: WhiteColor, fontSize: 16),
                            ),
                            SizedBox(height: 4),
                            Text(
                              '${numberOfPosts >= 1000000 ? '${(numberOfPosts / 1000000).ceil()} M' : numberOfPosts >= 1000 ? '${(numberOfPosts / 1000).ceil()} K' : numberOfPosts}  posts',
                              style: Regular.copyWith(color: SearchTextColor, fontSize: 14),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  Text(
                    'No. ${ratingNumber == 0 ? '-' : ratingNumber}',
                    style: Medium.copyWith(color: WhiteColor, fontSize: 16),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 25),
              child: NoScrollGlow(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      for (int i = 0; i < post.length; i++)
                        ImageTemplate(
                          post: post[i],
                          onViewPostClicked: () => model.onViewPostClicked(post[i]),
                        ),
                      Visibility(visible: post.length>7,child: Container(color: Colors.transparent,child: ImageTemplate(isImage: false, hashTagName: hashTagName,)))
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
