import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';

class FilterContainers extends StatelessWidget {
  final bool hasPrefix;
  final String title;
  final bool color;

  const FilterContainers({Key key, @required this.hasPrefix, @required this.title, this.color=false}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  Container(
          decoration: BoxDecoration(color: color ? Color(0xffFF5F0E) : SearchBackgroundColor, borderRadius: BorderRadius.all(Radius.circular(20))),
          padding: EdgeInsets.all(7),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              this.hasPrefix ? Icon(Icons.location_on, color: SearchTextColor) : Container(),
              SizedBox(width: 2),
              Text(title, style: Regular.copyWith(color: color ? Colors.white : SearchTextColor)),
            ],
          ),
          width: screenWidth(context) / 3 - 20,
          height: 36,
        );
  }
}
