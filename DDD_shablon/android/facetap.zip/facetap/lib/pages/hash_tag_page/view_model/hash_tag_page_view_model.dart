import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/rating_model.dart';
import 'package:facetap/models/top_user_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/hash_tag_page/views/search_result.dart';
import 'package:facetap/providers/base_class_provider.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class HashTagViewModel extends BaseViewModel {
  final UserModel userModel = locator<UserModel>();
  final PostsService _postsService = locator<PostsService>();
  List<Map<String, dynamic>> posts = [];
  List<UserModel> topUser = [];
  PagingController pagingController = PagingController<int,Map<String, dynamic>>(firstPageKey: 1);

Widget body=Container();

  bool isTopUser=false;
  bool isFollowing=false;
  bool isLocation=false;

  int type=0;

 static String location;
  changeType(int _type){
    this.type = _type;
  }
  antiLocation(){
    isFollowing=false;
    isTopUser=false;
    isLocation=!isLocation;
    notifyListeners();
  }

  antiFollowing(){
    isLocation=false;
    isTopUser=false;
    isFollowing=!isFollowing;
    notifyListeners();
  }


antiTopUser(){
  isLocation=false;
    isFollowing=false;
  isTopUser=!isTopUser;
  notifyListeners();
}
  initData() {
    location = userModel.locationName;
      print(1234567);
      // fetchSearch("", 1);
    pagingController.addPageRequestListener((pageKey) {
      print(123456);
      fetchSearch( pageKey);
    });
  }


  @override
  void onDispose() {
    pagingController.dispose();
    super.onDispose();
  }

  pushSearch(BuildContext context){
    navigationService.push(MaterialPageRoute(builder: (_) => SearchResult()));
  }

  Widget userImage() => Padding(
        padding: const EdgeInsets.only(right: 22.0),
        child: userModel.profilePhoto.isNotEmpty
            ? CircleAvatar(
                radius: 16.0,
                backgroundImage: CachedNetworkImageProvider(getProfileImageUrl(navigationService.currentContext)),
              )
            : CircleAvatar(
                radius: 16.0,
                backgroundColor: TextFromFieldHintColor,
                child: SvgPicture.asset(Assets.svgAvatarPlaceholder),
              ),
      );

List<String> listSearch=['','following', location,];
  void fetchSearch(int page) async {
    print(page);
    try {
      RatingsListPostsModel _response = await _postsService.getHashTagPosts(page: page, limit: 10, type: listSearch[type]).onError((error, stackTrace) => onError(error));
      final isLastPage = (pagingController.itemList ?? []).length == _response.count || (_response.results ?? []).isEmpty;
      print(_response.results);
      if (isLastPage) {
        pagingController.appendLastPage(_response.results);
      } else {
        final nextPageKey = page + 1;
        pagingController.appendPage(_response.results, nextPageKey);
      }
    } catch (error) {
      pagingController.error = error;
      print(error);
    }
    print(1234567);
notifyListeners();
  }

  void fetchTopUser(
    //   int page,
    // int limit,
      ) async {
    TopUserModel _response = await _postsService.getTopUser( page: 1 , limit: 10).onError((error, stackTrace) => onError(error));
    if (_response != null) {
print(_response.users.length);
      topUser=_response.users;

    }


    notifyListeners();
  }
}
