import 'package:facetap/models/search_model.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/views/search_items.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/views/search_suggest.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';

class SearchResultViewModel extends BaseViewModel {
  static SearchModel searchModel;
  final PostsService _postsService = locator<PostsService>();

  TextEditingController searchController = TextEditingController();
  String text;
  List<Widget> posts;
  TabController tabController;
  List<String> listString = ['Top', 'Users', 'Ratings', 'Posts', 'Places'];

  initData(vsync) {
    tabController = TabController(length: listString.length, vsync: vsync);
    fetchSearch("");
  }

  clearText() {
    searchController?.clear();
    fetchSearch("");
    notifyListeners();
  }

  onTab(index) {
    notifyListeners();
  }

  pushSearch(BuildContext context) {
    final result = navigationService.push(MaterialPageRoute(builder: (_) => SearchSuggest()));
    result.then((value) {
      text = value;
      fetchSearch(value);
      print("12345$value");
    });
    notifyListeners();
  }

  popSearch(BuildContext context) {
    navigationService.pop();
  }

  List<String> list = ["elastic_search", "user_search", "hashtag_search", "post_search", "location_search"];

  void fetchSearch(
    String search,
  ) async {
    setState(LoadingState.loading);
    SearchModel _response = await _postsService
        .elasticSearch(limit: 10, search: search, type: list[tabController.index], page: 1)
        .onError((error, stackTrace) => onError(error));
    print('1237${_response.count}');
    if (_response != null) {
      searchModel = _response;
      posts = [
        TopSearch(
          resent: false,
          searchModel: searchModel,
        ),
        Padding(
          padding: EdgeInsets.all(16),
          child: UserSearch(
            searchPost: searchModel.users,
          ),
        ),
        Padding(
          padding: EdgeInsets.all(16),
          child: UserSearch(
            searchPost: searchModel.hashtags,
          ),
        ),
        Padding(
          padding: EdgeInsets.all(16),
          child: PostSearch(
            searchPost: searchModel.posts,
          ),
        ),
        Padding(
          padding: EdgeInsets.all(16),
          child: UserSearch(
            searchPost: searchModel.locations,
          ),
        ),
      ];
      notifyListeners();
    }

    setState(LoadingState.idle);
    notifyListeners();
  }

  void fetchRecent() async {
    SearchPosts _response = await _postsService.userSearchRecent(limit: 18, page: 1).onError((error, stackTrace) => onError(error));
    print('1237${_response.count}');
    if (_response != null) {
      SearchPosts searchPosts = _response;
      List<SearchPost> listUser = [];
      List<SearchPost> listHashTag = [];
      List<SearchPost> listLocation = [];
      List<SearchPost> listPost = [];
      searchPosts.res.forEach((e) {
        print(e.title);
        if (e.type == 'user') {
          listUser.add(e);
        } else if (e.type == 'post') {
          listPost.add(e);
        } else if (e.type == 'hashtag') {
          listHashTag.add(e);
        } else if (e.type == 'location') {
          listLocation.add(e);
        } else {}
      });
      posts = [
        // Container()
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Recent',
                    style: Medium.copyWith(fontSize: 16, color: Colors.white),
                  ),
                  Text(
                    'See all',
                    style: Medium.copyWith(fontSize: 14, color: Color(0xffAAABaD)),
                  ),
                ],
              ),
            ),
            TopSearch(
              resent: true,
              searchModel: SearchModel(
                users: listUser != null ? SearchPosts(res: listUser, count: listUser.length) : SearchPosts(),
                hashtags: listHashTag != null ? SearchPosts(res: listHashTag, count: listHashTag.length) : SearchPosts(),
                posts: listPost != null ? SearchPosts(res: listPost, count: listPost.length) : SearchPosts(),
                locations: listLocation != null ? SearchPosts(res: listLocation, count: listLocation.length) : SearchPosts(),
              ),
            ),
          ],
        )
      ];
      notifyListeners();
    }

    notifyListeners();
  }
}
