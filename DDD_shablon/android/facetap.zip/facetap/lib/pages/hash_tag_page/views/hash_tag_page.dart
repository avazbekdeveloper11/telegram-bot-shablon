import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/views/infinite_list_empty.dart';
import 'package:facetap/models/search_model.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/views/hash_tag_template.dart';
import 'package:facetap/pages/hash_tag_page/local_widgets/views/search_items.dart';
import 'package:facetap/pages/hash_tag_page/view_model/hash_tag_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

import '../local_widgets/views/filter_containers.dart';

class HashTagPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<HashTagViewModel>.reactive(
      initState: (model) => model.initData(),
      viewModelBuilder: () => HashTagViewModel(),
      builder: (context, model, _) {
        return BaseClass(
          child: Scaffold(
            resizeToAvoidBottomInset: false,
            backgroundColor: PrimaryDarkColor.withOpacity(0.7),
            appBar: AppBar(
              elevation: 0,
              backgroundColor: PrimaryDarkColor.withOpacity(0.7),
              title: Text('Ratings', style: Medium.copyWith(color: WhiteColor, fontSize: 32)),
              actions: [model.userImage()],
            ),
            body: Container(
              height: screenHeight(context),
              color: PrimaryDarkColor.withOpacity(0.7),
              child: NoScrollGlow(
                child: SingleChildScrollView(
                  physics: model.isTopUser
                      ? AlwaysScrollableScrollPhysics()
                      : NeverScrollableScrollPhysics(),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 18, 16, 9),
                        child: GestureDetector(
                          onTap: () => model.pushSearch(context),
                          child: Container(
                            decoration: BoxDecoration(
                                color: SearchBackgroundColor,
                                borderRadius: BorderRadius.all(Radius.circular(20))),
                            padding: EdgeInsets.all(12),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Icon(Icons.search, color: SearchTextColor),
                                SizedBox(width: 16),
                                Text("Discover any topic",
                                    style: Regular.copyWith(color: SearchTextColor)),
                              ],
                            ),
                            width: screenWidth(context) - 32,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                                onTap: () {
                                  model.pagingController?.itemList?.clear();
                                  if (model.isLocation) {
                                    model.changeType(0);
                                    model.fetchSearch(1);
                                  } else {
                                    model.changeType(2);
                                    model.fetchSearch(1);
                                  }
                                  model.antiLocation();
                                },
                                child: FilterContainers(
                                  hasPrefix: false,
                                  title: "My location",
                                  color: model.isLocation,
                                )),
                            GestureDetector(
                                onTap: () {
                                  model.pagingController?.itemList?.clear();
                                  if (model.isFollowing) {
                                    model.changeType(0);
                                    model.fetchSearch(1);
                                  } else {
                                    model.changeType(1);
                                    model.fetchSearch(1);
                                  }
                                  model.antiFollowing();
                                },
                                child: FilterContainers(
                                  hasPrefix: false,
                                  title: "Following",
                                  color: model.isFollowing,
                                )),
                            GestureDetector(
                                onTap: () {
                                  model.pagingController?.itemList?.clear();
                                  if (model.isTopUser) {
                                    model.changeType(0);
                                    model.fetchSearch(1);
                                  } else {
                                    model.changeType(0);
                                    model.fetchTopUser();
                                  }
                                  model.antiTopUser();
                                },
                                child: FilterContainers(
                                    hasPrefix: false, title: "Top 100", color: model.isTopUser)),
                          ],
                        ),
                      ),
                      Visibility(
                        visible: !model.isTopUser,
                        child: Container(
                          height: screenHeight(context),
                          child: PagedGridView<int, Map<String, dynamic>>(
                            padding: EdgeInsets.only(bottom: 300.0, top: 0),
                            shrinkWrap: true,
                            pagingController: model.pagingController,
                            builderDelegate: PagedChildBuilderDelegate<Map<String, dynamic>>(
                              itemBuilder: (context, item, index) {
                                print("item.length ${item.length}");
                                return HashTagTemplate(
                                  imagePath: "",
                                  numberOfPosts: item['post_count'],
                                  ratingNumber: item['user_rating'],
                                  hashTagName: item['slug'],
                                  post: item['posts'],
                                );
                              },
                              firstPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                              newPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                              noItemsFoundIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                            ),
                            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 1, mainAxisSpacing: 2.0, childAspectRatio: 1.6),
                          ),
                        ),
                      ),
                      Visibility(
                        visible: model.isTopUser,
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: UserSearch(
                            searchPost: SearchPosts(
                                res: model.topUser
                                    .map((e) => SearchPost(
                                        id: e.id,
                                        title: e.username,
                                        description: e.bio,
                                        profilePhoto: e.profilePhoto,
                                        type: 'user'))
                                    .toList()),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
