import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/tab_bar.dart';
import 'package:facetap/pages/hash_tag_page/view_model/search_result_view_model.dart';
import 'package:facetap/state_manager/src/view_model_builder.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class SearchResult extends StatefulWidget {
  @override
  _SearchResultState createState() => _SearchResultState();
}

class _SearchResultState extends State<SearchResult> with SingleTickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SearchResultViewModel>.reactive(
      initState: (model) => model.initData(this),
      viewModelBuilder: () => SearchResultViewModel(),
      builder: (context, model, _) {
        return BaseClass(
          child: model.isloading
              ? Loading()
              : Scaffold(
                  resizeToAvoidBottomInset: false,
                  backgroundColor: PrimaryDarkColor.withOpacity(0.7),
                  body: Container(
                    height: screenHeight(context),
                    width: screenWidth(context),
                    color: PrimaryDarkColor.withOpacity(0.7),
                    child: NoScrollGlow(
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: const EdgeInsets.fromLTRB(16, 58, 16, 9),
                              height: 44,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    child: GestureDetector(
                                      onTap: () => model.pushSearch(context),
                                      child: Container(
                                        decoration: BoxDecoration(color: SearchBackgroundColor, borderRadius: BorderRadius.all(Radius.circular(20))),
                                        padding: EdgeInsets.all(12),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                            Icon(Icons.search, color: SearchTextColor),
                                            SizedBox(width: 16),
                                            Text(model.text ?? "Discover any topic",
                                                style: Regular.copyWith(color: model.text == null ? SearchTextColor : Colors.white)),
                                          ],
                                        ),
                                        width: screenWidth(context) - 32,
                                      ),
                                    ),
                                    width: screenWidth(context) * 5 / 7,
                                  ),
                                  SizedBox(
                                    width: 12,
                                  ),
                                  TextButton(
                                      onPressed: () => model.popSearch(context),
                                      child: Text('Cancel', style: Regular.copyWith(fontSize: 15, color: Colors.white)))
                                ],
                              ),
                            ),
                            CustomTabBar(
                              onTap: (index) => model.onTab(index),
                              tabController: model.tabController,
                              tabs: model.listString,
                            ),
                            model.posts != null ? model.posts[model.tabController.index] : Container()
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
        );
      },
    );
  }
}
