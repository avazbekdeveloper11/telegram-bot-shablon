import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/scrollable_footer_layout.dart';
import 'package:facetap/global_widgets/views/changed_text_form_field.dart';
import 'package:facetap/global_widgets/views/subscribe_button.dart';
import 'package:facetap/pages/registration_page/view_models/registration_page_view_model.dart';
import 'package:facetap/state_manager/src/view_model_builder.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/validators.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class RegistrationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<RegistrationViewModel>.reactive(
      initState: (model) => model.initState(),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => RegistrationViewModel(),
      builder: (context, model, _) {
        return BaseClass(
          child: Container(
            color: PrimaryDarkColor.withOpacity(0.5),
            child: Stack(
              children: [
                Scaffold(
                  backgroundColor: PrimaryDarkColor.withOpacity(0.5),
                  appBar: AppBar(elevation: 0, backgroundColor: PrimaryDarkColor.withOpacity(0.5)),
                  body: Container(
                    color: PrimaryDarkColor.withOpacity(0.5),
                    child: NoScrollGlow(
                      child: ScrollableFooterLayout(
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                            child: Text('Registration', style: Medium.copyWith(fontSize: 32.0, color: WhiteColor)),
                          ),
                          Form(
                            key: model.regKey,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ChangedTextFormField(
                                    controller: model.emailController,
                                    labelText: 'Email',
                                    // focusNode: model.emailFocus,
                                    // onFieldSubmitted: (text) => model.fieldFocusChange(
                                    //     model.emailFocus, model.firstNameFocus),
                                    validator: (value) {
                                      if (value.isEmpty) return 'Please enter Email';
                                      if (!isEmailValidate(value)) return 'Please enter correct Email';
                                      return null;
                                    },
                                    textInputType: TextInputType.emailAddress),
                                ChangedTextFormField(
                                    controller: model.firstNameController,
                                    labelText: 'First name',
                                    validator: (value) {
                                      if (value.isEmpty) return 'Please enter First name';
                                      return null;
                                    },
                                    textInputType: TextInputType.text),
                                ChangedTextFormField(
                                    controller: model.lastNameController,
                                    labelText: 'Last name',
                                    validator: (value) {
                                      if (value.isEmpty) return 'Please enter Last name';
                                      return null;
                                    },
                                    textInputType: TextInputType.text),
                                ChangedTextFormField(
                                    controller: model.userNameController,
                                    labelText: 'Username',
                                    validator: (value) {
                                      if (value.isEmpty) return 'Please enter Username';
                                      return null;
                                    },
                                    textInputType: TextInputType.text),
                                ChangedTextFormField(
                                  controller: model.passwordController,
                                  labelText: 'Password',
                                  validator: (value) {
                                    if (value.length < 8) return 'Password should be minimum 8 characters';
                                    // if (!isPasswordValidate(value)) return 'Min 8 characters including one capital letter, symbol and a number';
                                    return null;
                                  },
                                  obscureText: model.isPasswordHidden,
                                  textInputType: TextInputType.visiblePassword,
                                  suffixIcon: IconButton(
                                    onPressed: model.togglePasswordView,
                                    icon: SvgPicture.asset(
                                      model.isPasswordHidden ? Assets.svgEyeOpened : Assets.svgEyeClosed,
                                      width: 18.0,
                                      height: 18.0,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                        footer: Padding(
                          padding: const EdgeInsets.only(bottom: 16.0),
                          child: Column(
                            children: [
                              Padding(
                                padding: EdgeInsets.only(left: 16.0, right: 16.0, bottom: 24.0),
                                child: SubscribeButton(
                                  onTap: model.onSignUpButton,
                                  text: 'Sign Up',
                                  buttonColor: WhiteColor,
                                  isColorText: false,
                                  fontSize: 16.0,
                                  isBorderColored: true,
                                ),
                              ),
                              Center(
                                child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(
                                    text: 'By signing in, I accept FaceTap\n',
                                    style: Regular.copyWith(fontSize: 14.0, color: TextFromFieldHintColor),
                                    children: <TextSpan>[
                                      TextSpan(
                                        text: 'Terms of Service',
                                        style: Medium.copyWith(fontSize: 14.0, color: WhiteColor),
                                        recognizer: TapGestureRecognizer()..onTap = model.onTermOfService,
                                      ),
                                      TextSpan(
                                        text: ' and ',
                                        style: Regular.copyWith(fontSize: 14.0, color: TextFromFieldHintColor),
                                      ),
                                      TextSpan(
                                        text: 'Privacy Policy',
                                        style: Medium.copyWith(fontSize: 14.0, color: WhiteColor),
                                        recognizer: TapGestureRecognizer()..onTap = model.onPrivacyPolicy,
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                model.isloading ? Loading() : Container()
              ],
            ),
          ),
        );
      },
    );
  }
}
