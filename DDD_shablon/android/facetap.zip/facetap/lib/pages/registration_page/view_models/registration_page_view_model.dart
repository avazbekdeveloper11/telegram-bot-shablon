import 'package:facetap/models/register_model.dart';
import 'package:facetap/pages/login_page/views/login_page.dart';
import 'package:facetap/services/authentication_service.dart';
import 'package:facetap/state_manager/base_view_model.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class RegistrationViewModel extends BaseViewModel {
  final AuthenticationService _authService = locator<AuthenticationService>();
  GlobalKey<FormState> regKey = GlobalKey<FormState>();
  TextEditingController emailController;
  TextEditingController firstNameController;
  TextEditingController lastNameController;
  TextEditingController passwordController;
  TextEditingController userNameController;
  bool isPasswordHidden = true;

/*
  FocusNode emailFocus;
  FocusNode firstNameFocus;
  FocusNode lastNameFocus;
  FocusNode passwordFocus;
  FocusNode userNameFocus;
*/

  @override
  void initState() {
    passwordController = TextEditingController();
    firstNameController = TextEditingController();
    lastNameController = TextEditingController();
    emailController = TextEditingController();
    userNameController = TextEditingController();
/*
    emailFocus = FocusNode();
    firstNameFocus = FocusNode();
    lastNameFocus = FocusNode();
    passwordFocus = FocusNode();
    userNameFocus = FocusNode();
*/
    super.initState();
  }

  @override
  void onDispose() {
    passwordController.dispose();
    firstNameController.dispose();
    lastNameController.dispose();
    emailController.dispose();
    userNameController.dispose();
/*
    emailFocus.dispose();
    firstNameFocus.dispose();
    lastNameFocus.dispose();
    passwordFocus.dispose();
    userNameFocus.dispose();
*/
    super.onDispose();
  }

  fieldFocusChange(FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(navigationService.currentContext).requestFocus(nextFocus);
  }

  togglePasswordView() {
    isPasswordHidden = !isPasswordHidden;
    notifyListeners();
  }

  // button.
  onLoginButton() {
    navigationService.push(MaterialPageRoute(builder: (_) => LoginPage()));
  }

  onSignUpButton() async {
    if (!regKey.currentState.validate()) return;
    setState(LoadingState.loading);
    Map<String, dynamic> data = serializer.prepareDataToRegister(
      email: emailController.text,
      firstName: firstNameController.text,
      lastName: lastNameController.text,
      password: passwordController.text,
      username: userNameController.text,
    );
    RegisterModel _response = await _authService.register(data: data).onError((error, _) => onError(error));

    if (_response != null && _response.result.isNotEmpty) {
      showSnackBar(_response.result);
      navigationService.pop();
    }
    setState(LoadingState.idle);
  }

  onTermOfService() {}

  onPrivacyPolicy() {}
}
