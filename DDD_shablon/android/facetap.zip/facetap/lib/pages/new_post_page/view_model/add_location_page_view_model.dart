import 'dart:async';

import 'package:facetap/models/places_model.dart';
import 'package:facetap/services/places_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class AddLocationViewModel extends BaseViewModel {
  final PlacesService _placesService = locator<PlacesService>();
  int page = 1;
  String _search;
  Timer _searchTimer;
  List<PlaceModel> listOfPlaces = [];
  String pageToken = '';
  Position position;

  TextEditingController searchController = TextEditingController();

  initData(Position position, List<PlaceModel> listOfPlaces) {
    this.position = position;
    this.listOfPlaces = listOfPlaces;
    (listOfPlaces ?? []).isEmpty ? getNearByPlacesList() : notifyListeners();
    super.initState();
  }

  onBackPressed() => navigationService.pop();

  void onSearchChanged(String value) {
    if (_searchTimer != null) _searchTimer.cancel();
    _searchTimer = Timer(Duration(milliseconds: 500), () {
      _search = value;
      pageToken = '';
      _search.isEmpty ? getNearByPlacesList() : getPlacesByQuery();
    });
  }

  getNearByPlacesList() async {
    setState(LoadingState.loading);
    listOfPlaces = [];
    PlacesModel _response =
        await _placesService.getNearbyPlaces(lat: position.latitude, long: position.longitude).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      listOfPlaces.addAll(_response.results);
      notifyListeners();
    }
    setState(LoadingState.idle);
  }

  getPlacesByQuery() async {
    setState(LoadingState.loading);
    if ((pageToken ?? '').isEmpty) listOfPlaces = [];
    PlacesModel _response =
        await _placesService.getPlacesByQuery(search: _search, pageToken: pageToken ?? '').onError((error, stackTrace) => onError(error));
    if (_response != null) {
      pageToken = _response.nextPageToken;
      listOfPlaces.addAll(_response.results);
      notifyListeners();
    }
    setState(LoadingState.idle);
  }

  void onPlaceClicked(int index) {
    PlaceModel selectedPlace = listOfPlaces[index];
    navigationService.pop(selectedPlace);
  }
}
