import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/content_loader.dart';
import 'package:facetap/models/hashtag_model.dart';
import 'package:facetap/models/location_model.dart';
import 'package:facetap/models/medias_model.dart';
import 'package:facetap/models/places_model.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/upload_model.dart';
import 'package:facetap/models/upload_url_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/home_page/views/home_screen.dart';
import 'package:facetap/pages/new_post_page/views/add_location_page.dart';
import 'package:facetap/providers/base_class_provider.dart';
import 'package:facetap/services/media_upload_service.dart';
import 'package:facetap/services/places_service.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:geolocator/geolocator.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

class NewPostViewModel extends BaseViewModel {
  final MediaUploadService _uploadService = locator<MediaUploadService>();
  final PostsService _postsService = locator<PostsService>();
  final PlacesService _placesService = locator<PlacesService>();
  final UserModel _userModel = locator<UserModel>();
  final UploadModel uploadModel = locator<UploadModel>();

  TextEditingController captionController;
  File postMedia;
  bool isVideo;
  String mediaId;
  Widget videoThumbnail = ContentLoader();
  List<PlaceModel> listOfNearByPlaces = [];
  PlaceModel selectedPlace;
  Position currentPosition;
  bool isPlacesLoading = false;
  bool isHashtagLoading = false;
  Timer _searchTimer;
  String _search = '';
  List<HashtagModel> hashtags = [];
  List<Map<String, dynamic>> postHashtags = [];

  // int tagIndex = 0;
  String thumbnailPath;

  initData(String filePath, bool isVideo) {
    this.isVideo = isVideo;
    captionController = TextEditingController();
    postMedia = File(filePath);
    isVideo ? _getThumbnail(filePath) : setImagePath(FileImage(postMedia), navigationService.currentContext);
    _determinePosition();
    fetchHashtags();
    super.initState();
  }

  @override
  void onDispose() {
    captionController.dispose();
    super.onDispose();
  }

  _getThumbnail(String path) async {
    thumbnailPath = await VideoThumbnail.thumbnailFile(video: path, imageFormat: ImageFormat.JPEG, maxWidth: 128, quality: 25);
    videoThumbnail = Image.file(File(thumbnailPath), fit: BoxFit.fitWidth);
    notifyListeners();
  }

  _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      /* Location services are not enabled don't continue accessing the position
      and request users of the App to enable the location services.*/
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        /* Permissions are denied, next time you could try requesting permissions again (this is also where
        Android's shouldShowRequestPermissionRationale returned true. According to Android guidelines
        your App should show an explanatory UI now. */
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error('Location permissions are permanently denied, we cannot request permissions.');
    }

    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    currentPosition = await Geolocator.getCurrentPosition();
    _getNearByPlacesList();
  }

  _getNearByPlacesList() async {
    isPlacesLoading = true;
    notifyListeners();
    PlacesModel _response = await _placesService
        .getNearbyPlaces(lat: currentPosition.latitude, long: currentPosition.longitude)
        .onError((error, stackTrace) => onError(error));
    if (_response != null) listOfNearByPlaces.addAll(_response.results);
    isPlacesLoading = false;
    notifyListeners();
  }

  onNavigatorPop() => navigationService.pop();

  Widget userImage() => CircleAvatar(
        radius: 18.0,
        child: _userModel.profilePhoto.isNotEmpty
            ? ClipRRect(
                borderRadius: BorderRadius.circular(20.0),
                child: CachedNetworkImage(
                  imageUrl: getProfileImageUrl(navigationService.currentContext),
                  fit: BoxFit.cover,
                  height: 35.0,
                  width: 35.0,
                  placeholder: (context, url) => Container(color: TextFromFieldHintColor),
                ),
              )
            : SvgPicture.asset(Assets.svgAvatarPlaceholder),
      );

  onPostButton() {
    this.postHashtags = updateHashtags();
    print('===== p tags to post -> $postHashtags');
    (postHashtags.isNotEmpty) ? /*uploadFile()*/ generateUrl() : showSnackBar("Please add hashtag to post, by typing '#' with hashtag!");
  }

  generateUrl() async {
    setState(LoadingState.loading);
    GenerateUrlListModel files = GenerateUrlListModel(
      list: [GenerateUrlModel(contentType: isVideo ? 'video/mp4' : 'image/jpeg', metadata: isVideo ? 'post_video' : 'post_image')],
    );
    UploadUrlModel _response = await _uploadService.generateUploadUrl(json: jsonEncode(files)).onError((error, stackTrace) => onError(error));
    _response != null ? uploadToServer(_response) : showSnackBar('Error occurred');
  }

  uploadToServer(UploadUrlModel uploadUrlModel) async {
    UrlModel urlModel = uploadUrlModel.uploadUrls.first;
    Map<String, dynamic> data = serializer.prepareDataToCretePost(
      caption: captionController.text,
      hashtags: postHashtags,
      location: LocationModel(lat: selectedPlace?.geometry?.location?.lat, long: selectedPlace?.geometry?.location?.lng),
      medias: [NewPostMediaModel(contentType: isVideo ? 'video/mp4' : 'image/jpeg', mediaId: urlModel.filename)],
      locationName: selectedPlace?.formattedAddress ?? selectedPlace?.name ?? _userModel.locationName,
    );
    uploadModel.setProfile(UploadModel(
      thumbnailPath: isVideo ? thumbnailPath : postMedia.path,
      data: data,
      mediaUrl: urlModel.url,
      mediaPath: postMedia.path,
      metaType: urlModel.metadata,
      contentType: isVideo ? 'video/mp4' : 'image/jpeg',
    ));
    print("thubnail1 ${uploadModel.thumbnailPath}");
    Navigator.of(navigationService.currentContext).pushAndRemoveUntil(
        MaterialPageRoute(
            builder: (_) => HomePage(
                  defaultIndex: 4,
                )),
        (route) => false);
    // bool _response = await _uploadService
    //     .uploadToServer(
    //       url: urlModel.url,
    //       contentType: isVideo ? 'video/mp4' : 'image/jpeg',
    //       metaType: urlModel.metadata,
    //       data: postMedia.readAsBytesSync(),
    //     )
    //     .onError((error, stackTrace) => onError(error));
    //
    // mediaId = urlModel.filename;
    // if (_response != null) showSnackBar('File uploaded');
    // createPost();
  }

  uploadFile() async {
    setState(LoadingState.loading);
    Map<String, dynamic> data = serializer.prepareDataToUploadFile(
        content: postMedia.readAsBytesSync(), contentType: isVideo ? 'video/mp4' : 'image/jpeg', metadata: isVideo ? 'post_video' : 'post_image');
    UploadFile _response = await _uploadService.uploadFile(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      showSnackBar('File uploaded');
      mediaId = _response.filename;
      createPost();
    }
  }

  createPost() async {
    print('===== p tags to post -> $postHashtags');
    Map<String, dynamic> data = serializer.prepareDataToCretePost(
      caption: captionController.text,
      hashtags: postHashtags,
      location: LocationModel(lat: selectedPlace?.geometry?.location?.lat, long: selectedPlace?.geometry?.location?.lng),
      medias: [NewPostMediaModel(contentType: isVideo ? 'video/mp4' : 'image/jpeg', mediaId: mediaId)],
      locationName: selectedPlace?.formattedAddress ?? selectedPlace?.name ?? _userModel.locationName,
    );

    PostModel _response = await _postsService.createPost(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      print("Post Created");
      print(_response.hashtags);
    }
    setState(LoadingState.idle);
    onNavigatorPop();
  }

  void onPlaceClicked(int index) {
    selectedPlace = listOfNearByPlaces[index];
    listOfNearByPlaces = [];
    notifyListeners();
  }

  onAddAddressClicked() async {
    PlaceModel selectedPlace =
        await navigationService.push(MaterialPageRoute(builder: (_) => AddLocationPage(position: currentPosition, listOfPlaces: listOfNearByPlaces)));
    if (selectedPlace != null) {
      this.selectedPlace = selectedPlace;
      notifyListeners();
    }
  }

  void onCaptionChanged(String value) {
    List<String> words = value.split(' ');
    if (words.last.contains('#')) {
      if (_searchTimer != null) _searchTimer.cancel();
      _searchTimer = Timer(Duration(milliseconds: 500), () {
        _search = words.last.replaceAll('#', '');
        fetchHashtags();
      });
    } else if (value.isEmpty) {
      if (_searchTimer != null) _searchTimer.cancel();
      _searchTimer = Timer(Duration(milliseconds: 500), () {
        _search = '';
        fetchHashtags();
      });
    }
    // if (value.characters.last == '#') {
    //   tagIndex = value.length - 2;
    // } else if (value.characters.last == ' ') {
    //   tagIndex = null;
    //   hashtags.clear();
    //   notifyListeners();
    // }
    // if (tagIndex != null) {
    //   var search = value.substring(tagIndex);
    //   if (_searchTimer != null) _searchTimer.cancel();
    //   _searchTimer = Timer(Duration(milliseconds: 500), () {
    //     _search = search;
    //     fetchHashtags();
    //   });
    // }
    // updateCaptionTags(value);
  }

  void fetchHashtags() async {
    isHashtagLoading = true;
    hashtags.clear();
    notifyListeners();
    HashtagSuggestModel _response = await _postsService
        .getHashtags(search: _search) //(_search ?? '').isNotEmpty ? _search.substring(2) : '')
        .onError((error, stackTrace) => onError(error));
    if (_response != null) {
      hashtags.clear();
      _search = '';
      _response.hashtags.forEach((element) => hashtags.add(HashtagModel(name: element.name, slug: '#${element.slug}')));
      // hashtags = _response.hashtags;
    }
    isHashtagLoading = false;
    notifyListeners();
  }

  onHashtagClicked(int index) {
    var text = captionController.text;
    var selectedTag = hashtags[index];
    List<String> words = text.split(' ');
    if (selectedTag.slug.contains(words.last)) words.removeLast();
    text = '';
    words.forEach((element) => text += text.isEmpty ? element : ' $element');
    postHashtags.add({'name': selectedTag.slug});
    // captionController.text = '${text.isNotEmpty ? text.substring(0, tagIndex + 1) : ''}${hashtags[index].slug} ';
    // tagIndex = captionController.text.length - 1;
    captionController.text = text + (text.isEmpty ? '${selectedTag.slug} ' : ' ${selectedTag.slug} ');
    captionController.selection = TextSelection.fromPosition(TextPosition(offset: captionController.text.length));
    // hashtags.clear();
    print("===== postHashtags1: $postHashtags");
    notifyListeners();
  }

  void updateCaptionTags(String caption) {
    List<String> words = caption.split(' ');
    List<String> hashtagsWords = [];
    words.forEach((element) {
      if (element.contains('#')) hashtagsWords.add(element);
    });
    List<Map<String, dynamic>> postHashtags = [];
    for (var word in hashtagsWords) {
      for (var tag in this.postHashtags) {
        if ("#${tag['name']}" == word) postHashtags.add({'name': tag['name']});
      }
    }
    print("===== postHashtags$postHashtags");
    this.postHashtags = postHashtags;
    notifyListeners();
  }

  updateHashtags() {
    List<String> words = captionController.text.split(' ');
    List<String> hashtagsWords = [];
    words.forEach((element) {
      if (element.contains('#')) hashtagsWords.add(element);
    });
    List<Map<String, dynamic>> postHashtags = [];
    for (var word in hashtagsWords) {
      postHashtags.add({'name': word.substring(1)});
    }
    print("===== postHashtags$postHashtags");
    return postHashtags;
  }
}
