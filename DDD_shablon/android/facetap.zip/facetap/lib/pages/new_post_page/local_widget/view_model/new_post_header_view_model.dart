/*
import 'package:facetap/models/user_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:flutter/material.dart';

class NewPostHeaderViewModel extends BaseViewModel {
  final UserModel _userModel = locator<UserModel>();
  TextEditingController controller;
  // GlobalKey<FormState> postKey = GlobalKey<FormState>();

  @override
  void initState() {
    controller = TextEditingController();
    super.initState();
  }

  @override
  void onDispose() {
    controller.dispose();
    super.onDispose();
  }

  userImage() => _userModel.profilePhoto.isNotEmpty
      ? ClipRRect(
          borderRadius: BorderRadius.circular(50.0),
          child: Image.network(getProfileImageUrl(navigationService.currentContext), height: 35.0, width: 35.0),
        )
      : SvgPicture.asset(Assets.svgAvatarPlaceholder);
}
*/
