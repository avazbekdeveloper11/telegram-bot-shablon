import 'package:facetap/pages/new_post_page/local_widget/view_model/new_post_template_viewModel.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';

class SwitchTemplate extends StatelessWidget {
  final String title;
  final Function onTap;
  final Widget child;
  final bool isBorderVisible;

  const SwitchTemplate({Key key, @required this.onTap, @required this.child, @required this.title, this.isBorderVisible = true}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<NewPostTemplateViewModel>.reactive(
      viewModelBuilder: () => NewPostTemplateViewModel(),
      builder: (context, model, _) {
        return GestureDetector(
          onTap: onTap,
          child: Container(
            decoration: isBorderVisible
                ? BoxDecoration(border: Border(top: BorderSide(width: 1.0, color: NewPostBorderColor)), color: Colors.transparent)
                : null,
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  title,
                  style: Regular.copyWith(fontSize: 16.0, color: Colors.white),
                ),
                child
              ],
            ),
          ),
        );
      },
    );
  }
}
