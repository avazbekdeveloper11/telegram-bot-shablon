/*
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:facetap/pages/new_post_page/local_widget/view_model/new_post_header_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class NewPostHeaderWidget extends StatelessWidget {
  final ImageProvider imageProvider;

  const NewPostHeaderWidget({Key key, this.imageProvider}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<NewPostHeaderViewModel>.reactive(
        initState: (model) => model.initState(),
        onDispose: (model) => model.onDispose(),
        viewModelBuilder: () => NewPostHeaderViewModel(),
        builder: (context, model, _) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  'New post',
                  style: Medium.copyWith(color: WhiteColor, fontSize: 32),
                ),
              ),
              SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          model.userImage(),
                          SizedBox(width: 16),
                          Container(
                            height: 60,
                            width: 200,
                            child: TextFormField(
                              keyboardType: TextInputType.text,
                              controller: model.controller,
                              maxLines: 2,
                              style: Regular.copyWith(color: WhiteColor, fontSize: 16),
                              cursorColor: WhiteColor,
                              decoration: InputDecoration(
                                hintText: 'Write a caption',
                                hintStyle: Regular.copyWith(
                                  color: TextFromFieldHintColor,
                                  fontSize: 16,
                                ),
                                disabledBorder: UnderlineInputBorder(borderSide: BorderSide.none),
                                enabledBorder: UnderlineInputBorder(borderSide: BorderSide.none),
                                border: UnderlineInputBorder(borderSide: BorderSide.none),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(4)),
                            image: DecorationImage(image: imageProvider, fit: BoxFit.cover),
                          ),
                          height: screenWidth(context) / 5,
                          width: screenWidth(context) / 5)
                    ]),
              ),
              SizedBox(height: 12),
            ],
          );
        });
  }
}
*/
