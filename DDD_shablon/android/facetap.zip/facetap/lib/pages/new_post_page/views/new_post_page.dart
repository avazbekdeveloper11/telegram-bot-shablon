import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/content_loader.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/scrollable_footer_layout.dart';
import 'package:facetap/global_widgets/views/subscribe_button.dart';
import 'package:facetap/pages/new_post_page/local_widget/views/new_post_template.dart';
import 'package:facetap/pages/new_post_page/view_model/new_post_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class NewPostPage extends StatelessWidget {
  final String filePath;
  final bool isVideo;

  const NewPostPage({Key key, this.filePath, this.isVideo}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<NewPostViewModel>.reactive(
        initState: (model) => model.initData(filePath, isVideo),
        onDispose: (model) => model.onDispose(),
        viewModelBuilder: () => NewPostViewModel(),
        builder: (context, model, _) {
          return BaseClass(
            child: Stack(
              children: [
                Scaffold(
                  resizeToAvoidBottomInset: false,
                  backgroundColor: PrimaryDarkColor.withOpacity(0.7),
                  appBar: AppBar(
                    leading: IconButton(
                      icon: SvgPicture.asset(Assets.svgArrowBack, color: WhiteColor),
                      onPressed: model.onNavigatorPop,
                    ),
                    title: Text('New post'),
                    centerTitle: true,
                    elevation: 0,
                    backgroundColor: PrimaryDarkColor.withOpacity(0.7),
                  ),
                  body: Container(
                    color: PrimaryDarkColor.withOpacity(0.7),
                    child: NoScrollGlow(
                      child: ScrollableFooterLayout(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      height: screenWidth(context) / 3,
                                      width: screenWidth(context) - (screenWidth(context) / 4) - 48,
                                      child: TextFormField(
                                        keyboardType: TextInputType.text,
                                        controller: model.captionController,
                                        maxLines: 5,
                                        style: Regular.copyWith(color: WhiteColor, fontSize: 16),
                                        cursorColor: WhiteColor,
                                        decoration: InputDecoration(
                                          hintText: 'Write a caption',
                                          hintStyle: Regular.copyWith(color: TextFromFieldHintColor, fontSize: 16),
                                          disabledBorder: UnderlineInputBorder(borderSide: BorderSide.none),
                                          enabledBorder: UnderlineInputBorder(borderSide: BorderSide.none),
                                          border: UnderlineInputBorder(borderSide: BorderSide.none),
                                        ),
                                        onChanged: (value) => model.onCaptionChanged(value),
                                      ),
                                    ),
                                    Container(
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(4.0),
                                          child: isVideo
                                              ? model.videoThumbnail
                                              : model.postMedia != null
                                                  ? Image.file(model.postMedia, fit: BoxFit.cover)
                                                  : Container(color: TextFromFieldHintColor),
                                        ),
                                        height: screenWidth(context) / 3,
                                        width: screenWidth(context) / 4)
                                  ],
                                ),
                              ),
                              model.isHashtagLoading
                                  ? Padding(padding: EdgeInsets.only(bottom: 16.0), child: Center(child: ContentLoader()))
                                  : Container(),
                              model.hashtags.isNotEmpty
                                  ? SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 8.0, right: 8.0, bottom: 16.0),
                                        child: Row(
                                          children: [
                                            for (int index = 0; index < model.hashtags.length; index++)
                                              GestureDetector(
                                                onTap: () => model.onHashtagClicked(index),
                                                child: Container(
                                                  padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
                                                  margin: EdgeInsets.symmetric(horizontal: 4.0),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(4.0),
                                                    color: WhiteColor.withOpacity(0.2),
                                                  ),
                                                  child: Text(
                                                    '${model.hashtags[index].slug}',
                                                    style: Regular.copyWith(color: WhiteColor, fontSize: 16.0),
                                                  ),
                                                ),
                                              ),
                                          ],
                                        ),
                                      ),
                                    )
                                  : Container(),
                              SwitchTemplate(
                                title: 'Add Location',
                                onTap: model.onAddAddressClicked,
                                child: Row(
                                  children: [
                                    Text(
                                      model.selectedPlace?.name ?? '',
                                      style: Regular.copyWith(color: WhiteColor.withOpacity(0.5)),
                                    ),
                                    Icon(Icons.keyboard_arrow_right, color: WhiteColor),
                                  ],
                                ),
                              ),
                              model.isPlacesLoading ? Center(child: ContentLoader()) : Container(),
                              model.selectedPlace == null
                                  ? SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 8.0, right: 8.0, bottom: 16.0),
                                        child: Row(
                                          children: [
                                            for (int index = 0; index < model.listOfNearByPlaces.length; index++)
                                              GestureDetector(
                                                onTap: () => model.onPlaceClicked(index),
                                                child: Container(
                                                  padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
                                                  margin: EdgeInsets.symmetric(horizontal: 4.0),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(4.0),
                                                    color: WhiteColor.withOpacity(0.2),
                                                  ),
                                                  child: Text(
                                                    model.listOfNearByPlaces[index].name,
                                                    style: Regular.copyWith(color: WhiteColor, fontSize: 16.0),
                                                  ),
                                                ),
                                              ),
                                          ],
                                        ),
                                      ),
                                    )
                                  : Container(),
                              Container(
                                decoration: BoxDecoration(
                                  border: Border(bottom: BorderSide(width: 1.0, color: NewPostBorderColor)),
                                ),
                              ),
                            ],
                          )
                        ],
                        footer: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
/*
                            Padding(
                              padding: const EdgeInsets.only(left: 16.0),
                              child: Text(
                                'Automatically share to:',
                                style: Regular.copyWith(fontSize: 14.0, color: TextFromFieldHintColor),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  LoginSocialContainer(svgName: Assets.svgInstagram),
                                  SizedBox(width: 8.0),
                                  LoginSocialContainer(svgName: Assets.svgFacebook),
                                  SizedBox(width: 8.0),
                                  LoginSocialContainer(svgName: Assets.svgYoutube),
                                ],
                              ),
                            ),
*/
                            Padding(
                              padding: const EdgeInsets.only(bottom: 32.0, left: 16.0, right: 16.0),
                              child: Container(
                                height: 52.0,
                                child: SubscribeButton(
                                    onTap: model.onPostButton, text: 'Post', buttonColor: WhiteColor, isColorText: false, fontSize: 16.0),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                model.isloading ? Loading() : Container()
              ],
            ),
          );
        });
  }
}
