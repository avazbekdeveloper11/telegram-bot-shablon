import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/views/search_widget.dart';
import 'package:facetap/models/places_model.dart';
import 'package:facetap/pages/new_post_page/view_model/add_location_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:geolocator/geolocator.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class AddLocationPage extends StatelessWidget {
  final Position position;
  final List<PlaceModel> listOfPlaces;

  const AddLocationPage({Key key, this.position, this.listOfPlaces}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<AddLocationViewModel>.reactive(
      initState: (model) => model.initData(position, listOfPlaces),
      viewModelBuilder: () => AddLocationViewModel(),
      builder: (context, model, _) {
        return Scaffold(
          resizeToAvoidBottomInset: false,
          backgroundColor: PrimaryDarkColor,
          appBar: AppBar(
            leading: IconButton(
              icon: SvgPicture.asset(Assets.svgArrowBack, color: WhiteColor),
              onPressed: model.onBackPressed,
            ),
            title: Text('Locations' /*, style: Regular.copyWith(fontSize: 17.0)*/),
            centerTitle: true,
            actions: [
              IconButton(
                icon: SvgPicture.asset(Assets.svgLocation, color: WhiteColor),
                onPressed: model.getNearByPlacesList,
              ),
            ],
            elevation: 0,
            backgroundColor: PrimaryDarkColor.withOpacity(0.7),
          ),
          body: Stack(
            children: [
              NoScrollGlow(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 8.0, right: 16.0, left: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          width: double.infinity,
                          height: 42.0,
                          child: SearchWidget(
                            onEditingComplete: () {},
                            controller: model.searchController,
                            hintText: 'Search',
                            onChangedSuffix: (value) => model.onSearchChanged(value),
                          ),
                        ),
                        model.listOfPlaces.length > 0
                            ? ListView.builder(
                                physics: NeverScrollableScrollPhysics(),
                                itemCount: model.listOfPlaces.length,
                                shrinkWrap: true,
                                itemBuilder: (BuildContext context, int index) {
                                  var item = model.listOfPlaces[index];
                                  return ListTile(
                                    onTap: () => model.onPlaceClicked(index),
                                    title: Text(
                                      item.name,
                                      style: Medium.copyWith(color: WhiteColor, fontSize: 16.0),
                                    ),
                                    subtitle: Text(
                                      item.formattedAddress ?? item.vicinity ?? '',
                                      style: Regular.copyWith(color: TextFromFieldHintColor, fontSize: 14.0),
                                    ),
                                  );
                                },
                              )
                            : Container(),
                      ],
                    ),
                  ),
                ),
              ),
              model.isloading ? Loading() : Container()
            ],
          ),
        );
      },
    );
  }
}
