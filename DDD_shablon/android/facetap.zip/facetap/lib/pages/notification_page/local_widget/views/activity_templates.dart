import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/notifications_model.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class ActivityTemplates extends StatelessWidget {
  final Function onNavigationPostPage;
  final Function onNavigationProfilePage;
  final Function onNavigationGiftPage;
  final NotificationModel notification;

  const ActivityTemplates({
    Key key,
    this.onNavigationPostPage,
    this.onNavigationProfilePage,
    this.onNavigationGiftPage,
    this.notification,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      // like, comment, follow, gift, system
      child: notification.type == 'follow'
          ? followed(context)
          : notification.type == 'gift'
              ? sendGift(context)
              : notification.type == 'system'
                  ? newAchievement(context)
                  : postLiked(context),
    );
  }

  sendGift(context) {
    return GestureDetector(
      onTap: onNavigationProfilePage,
      child: Container(
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            CircleAvatar(
              radius: screenWidth(context) / 14,
              backgroundColor: TextFromFieldHintColor,
              child: notification.profilePhoto.isNotEmpty
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(32.0),
                      child: CachedNetworkImage(
                        imageUrl: notification.profilePhoto,
                        fit: BoxFit.cover,
                        height: screenWidth(context) / 7,
                        width: screenWidth(context) / 7,
                        placeholder: (context, url) => Container(color: TextFromFieldHintColor),
                      ),
                    )
                  : SvgPicture.asset(Assets.svgAvatarPlaceholder),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('@${notification.username}', style: Medium.copyWith(fontSize: 14.0, color: WhiteColor)),
                    SizedBox(height: 8.0),
                    Text('${notification.content}', style: Regular.copyWith(fontSize: 14.0, color: TextFromFieldHintColor)),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: onNavigationGiftPage,
              child: Container(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4.0),
                    child: notification.objectPhoto.isNotEmpty
                        ? CachedNetworkImage(
                            imageUrl: notification.objectPhoto,
                            fit: BoxFit.cover,
                            errorWidget: (context, url, error) {
                              return Container(
                                color: WhiteColor.withOpacity(0.1),
                                alignment: Alignment.center,
                                child: Icon(Icons.image_outlined, color: WhiteColor),
                              );
                            },
                          )
                        : Container(
                            color: TextFromFieldHintColor,
                            alignment: Alignment.center,
                            child: Icon(Icons.image_outlined, color: WhiteColor),
                          ),
                  ),
                  height: screenWidth(context) / 5,
                  width: screenWidth(context) / 5),
            )
          ],
        ),
      ),
    );
  }

  postLiked(context) {
    return GestureDetector(
      onTap: onNavigationProfilePage,
      child: Container(
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            CircleAvatar(
              radius: screenWidth(context) / 14,
              backgroundColor: TextFromFieldHintColor,
              child: notification.profilePhoto.isNotEmpty
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(32.0),
                      child: CachedNetworkImage(
                        imageUrl: notification.profilePhoto,
                        fit: BoxFit.cover,
                        height: screenWidth(context) / 7,
                        width: screenWidth(context) / 7,
                        placeholder: (context, url) => Container(color: TextFromFieldHintColor),
                      ),
                    )
                  : SvgPicture.asset(Assets.svgAvatarPlaceholder),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('@${notification.username}', style: Medium.copyWith(fontSize: 14.0, color: WhiteColor)),
                    SizedBox(height: 8.0),
                    Text('${notification.content} ${timeDifference()}', style: Regular.copyWith(fontSize: 14.0, color: TextFromFieldHintColor)),
                  ],
                ),
              ),
            ),
            GestureDetector(
              onTap: onNavigationPostPage,
              child: Container(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4.0),
                    child: notification.objectPhoto.isNotEmpty
                        ? CachedNetworkImage(
                            imageUrl: notification.objectPhoto,
                            fit: BoxFit.cover,
                            errorWidget: (context, url, error) {
                              return Container(
                                color: TextFromFieldHintColor,
                                alignment: Alignment.center,
                                child: Icon(Icons.image_outlined, color: WhiteColor),
                              );
                            },
                          )
                        : Container(color: TextFromFieldHintColor, alignment: Alignment.center, child: Icon(Icons.image_outlined, color: WhiteColor)),
                  ),
                  height: screenWidth(context) / 5,
                  width: screenWidth(context) / 6),
            )
          ],
        ),
      ),
    );
  }

  followed(context) {
    return GestureDetector(
      onTap: onNavigationProfilePage,
      child: Container(
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            SvgPicture.asset(Assets.svgUserSubscribed, width: screenWidth(context) / 7, height: screenWidth(context) / 7),
            Flexible(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: RichText(
                  text: TextSpan(
                    children: <TextSpan>[
                      TextSpan(text: '@${notification.username} ', style: Medium.copyWith(fontSize: 14.0, color: WhiteColor)),
                      TextSpan(text: '${notification.content}', style: Regular.copyWith(fontSize: 14.0, color: WhiteColor)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  newAchievement(context) {
    return GestureDetector(
      //onTap: onNavigationProfilePage,
      child: Container(
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            SvgPicture.asset(Assets.svgAchievementStar, width: screenWidth(context) / 7, height: screenWidth(context) / 7),
            Flexible(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Text('${notification.content}', style: Regular.copyWith(fontSize: 14.0, color: WhiteColor)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  timeDifference() {
    // "2021-07-03T07:23:53Z"
    var date = DateTime.parse(notification.sentDate);
    var now = DateTime.now();
    // var format = DateFormat("yyyy-MM-dd hh:mm a");
    // print('===== time notification : ${format.format(date)}');
    // print('===== time now : ${format.format(now)}');
    // print('===== time diff : ${now.difference(date).inHours}');
    var diff = now.difference(date);

    if (diff.inSeconds <= 60)
      return '${diff.inSeconds == 0 ? 1 : diff.inSeconds}s';
    else if (diff.inMinutes <= 60)
      return '${diff.inMinutes == 0 ? 1 : diff.inMinutes}m';
    else if (diff.inHours <= 24)
      return '${diff.inHours == 0 ? 1 : diff.inHours}h';
    else if (diff.inDays <= 7)
      return '${diff.inDays == 0 ? 1 : diff.inDays}d';
    else
      return '${(diff.inDays % 7) == 0 ? 1 : diff.inDays % 7}w';
  }
}
