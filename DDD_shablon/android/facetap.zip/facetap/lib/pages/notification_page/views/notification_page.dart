import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/views/infinite_list_empty.dart';
import 'package:facetap/models/notifications_model.dart';
import 'package:facetap/pages/notification_page/local_widget/views/activity_templates.dart';
import 'package:facetap/pages/notification_page/view_model/notification_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class NotificationPage extends StatelessWidget {
  const NotificationPage({Key key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<NotificationViewModel>.reactive(
      initState: (model) => model.initState(),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => NotificationViewModel(),
      builder: (context, model, _) {
        return Stack(
          children: [
            BaseClass(
              child: Scaffold(
                backgroundColor: PrimaryDarkColor.withOpacity(0.9),
                appBar: AppBar(
                  elevation: 0,
                  backgroundColor: Transparent,
                  title: Text("Activity", style: Medium.copyWith(color: WhiteColor, fontSize: 32)),
                ),
                body: PagedListView<int, NotificationModel>(
                  pagingController: model.pagingController,
                  builderDelegate: PagedChildBuilderDelegate<NotificationModel>(
                    itemBuilder: (context, item, index) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: item.status == 'section'
                          ? Padding(
                              padding: const EdgeInsets.only(top: 16.0, bottom: 16.0),
                              child: Text(item.content, style: Medium.copyWith(fontSize: 16, color: TextFromFieldHintColor)),
                            )
                          : ActivityTemplates(
                              onNavigationProfilePage: () => model.onNavigationProfilePage(item.senderId),
                              onNavigationPostPage: () => model.onNavigationPostPage(item.objectId),
                              onNavigationGiftPage: () => model.onNavigationGiftPage(item.objectId),
                              notification: item,
                            ),
                    ),
                    firstPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                    newPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                    noItemsFoundIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                  ),
                ),
              ),
            ),
            model.isloading ? Loading() : Container()
          ],
        );
      },
    );
  }
}
