import 'package:facetap/models/notifications_model.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/pages/content_page/views/view_post_page.dart';
import 'package:facetap/pages/gift_page/views/view_gift_page.dart';
import 'package:facetap/pages/profile_page/views/profile_page.dart';
import 'package:facetap/services/gifts_service.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class NotificationViewModel extends BaseViewModel {
  final UserService _userService = locator<UserService>();
  final PostsService _postsService = locator<PostsService>();
  final GiftsService _giftsService = locator<GiftsService>();
  PagingController pagingController = PagingController<int, NotificationModel>(firstPageKey: 1);
  final _today = NotificationModel(content: 'Today', status: 'section');
  final _yesterday = NotificationModel(content: 'Yesterday', status: 'section');
  final _thisMonth = NotificationModel(content: 'This month', status: 'section');
  final _twoMonths = NotificationModel(content: 'Two months', status: 'section');
  bool hasMessage = false;


   initState() {
    pagingController.addPageRequestListener((pageKey) {
      fetchNotifications(pageKey);
    });
  }

  @override
  void onDispose() {
    pagingController.dispose();
    super.onDispose();
  }

  onNavigationPostPage(String postId) async {
    var post = await getPost(postId);
    if (post != null)
      navigationService.push(MaterialPageRoute(builder: (_) => ViewPostPage(isNavigatorPop: true, post: post)));
    else
      showSnackBar('Post not available');
  }


  onNavigationGiftPage(String giftId) async {
    setState(LoadingState.loading);
    var _response = await _giftsService.getGift(giftId: giftId).onError((error, stackTrace) => onError(error));
    _response != null
        ? navigationService.push(MaterialPageRoute(builder: (_) => ViewGiftPage(gift: _response)))
        : showSnackBar('Post not available');
    setState(LoadingState.idle);
  }

  onNavigationProfilePage(String userId) {
    navigationService.push(MaterialPageRoute(builder: (_) => ProfilePage(userId: userId, isNavigatorPop: true)));
  }

  Future<PostModel> getPost(String postId) async {
    setState(LoadingState.loading);
    PostModel _response = await _postsService.getPost(postId: postId).onError((error, stackTrace) => onError(error));
    PostModel post;
    if (_response != null) {
      post = _response;
      notifyListeners();
    }
    setState(LoadingState.idle);
    return post;
  }

  void fetchNotifications(int pageKey) async {
    if (pageKey == 1) pagingController?.itemList?.clear();
    try {
      final _response =
          await _userService.getNotifications(page: pageKey, limit: 20).onError((error, stackTrace) => onError(error));
      List<NotificationModel> notifications = [];
      List<NotificationModel> listToCheck = pageKey > 1 ? (pagingController.itemList ?? []) : notifications;
      _response.results.forEach((item) {
        switch (item.date) {
          case 'Today':
            if (!listToCheck.contains(_today) && !notifications.contains(_today)) notifications.add(_today);
            break;
          case 'Yesterday':
            if (!listToCheck.contains(_yesterday) && !notifications.contains(_yesterday)) notifications.add(_yesterday);
            break;
          case 'ThisMonth':
            if (!listToCheck.contains(_thisMonth) && !notifications.contains(_thisMonth)) notifications.add(_thisMonth);
            break;
          case 'TwoMonths':
            if (!listToCheck.contains(_twoMonths) && !notifications.contains(_twoMonths)) notifications.add(_twoMonths);
            break;
        }
        notifications.add(item);
      });
      final isLastPage = /*(pagingController.itemList ?? []).length == _response.count ||*/ (notifications ?? [])
          .isEmpty;
      isLastPage
          ? pagingController.appendLastPage(notifications)
          : pagingController.appendPage(notifications, pageKey + 1);
    } catch (error) {
      pagingController.error = error;
    }
  }
}
