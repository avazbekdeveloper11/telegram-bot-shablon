import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/following_page/local_widgets/views/following_profiles.dart';
import 'package:facetap/pages/like_page/view_model/like_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class LikeScreen extends StatelessWidget {
  final UserModel profile;
 final PostModel post;

  const LikeScreen({Key key, this.profile, this.post}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LikeScreenViewModel>.reactive(
      initState: (model) => model.initData(profile, post),
      viewModelBuilder: () => LikeScreenViewModel(),
      builder: (context, model, _) {
        return Stack(
          children: [
            Align(
              alignment: Alignment.topCenter,
              child: Column(
                children: [
                  IconButton(
                    onPressed: model.onCloseLikes,
                    icon: SvgPicture.asset('assets/svg/open_comments.svg', width: 12.0, height: 12.0),
                    padding: EdgeInsets.only(top: 50.0, bottom: 24.0, left: 100.0, right: 100.0),
                  ),
                  Text(
                    '${model.likedUser.length} likes',
                    style: Regular.copyWith(color: WhiteColor),
                  ),
                  Container(
                    color: WhiteColor.withOpacity(0.2),
                    height: 1.0,
                    margin: EdgeInsets.all(16.0),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 130.0, bottom: 70.0),
              child: NoScrollGlow(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 8.0, right: 16.0, left: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        model.likedUser.length > 0
                            ? ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: model.likedUser.length,
                          shrinkWrap: true,
                          itemBuilder: (BuildContext context, int index) {
                            var item = model.likedUser[index];
                            return FollowingProfile(
                              isButtonsVisible: model.isMyProfile(index),
                              profile: item,
                              onChangeFollowing: () => model.onChangeFollowing(index),
                            );
                          },
                        )
                            : Container()
                      ],
                    ),
                  ),
                ),
              ),
            ),
            model.isloading ? Loading() : Container()
          ],
        );
      },
    );
  }
}