import 'dart:async';

import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/models/users_liked_model.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';

class LikeScreenViewModel extends BaseViewModel {
  final UserService _userService = locator<UserService>();
  final PostsService _postsService = locator<PostsService>();
  List<UserModel> likedUser = [];
  int page = 1;
  UserModel profile;
  PostModel post;

  initData(UserModel profile, PostModel post) {
    print("1111111111");
    this.profile = profile;
    this.post = post;
    fetchFollowing();
    super.initState();
  }

  bool isMyProfile(int index) => profile.id != likedUser[index].id;

  onCloseLikes() => navigationService.pop();

  onChangeFollowing(int index) {
    likedUser[index].amIFollowing == 'true' ? unfollowUser(likedUser[index].id) : followUser(likedUser[index].id);
    likedUser[index].amIFollowing = likedUser[index].amIFollowing == 'true' ? 'false' : 'true';
    notifyListeners();
  }

  unfollowUser(String id) async {
    Map<String, dynamic> data = serializer.prepareDataToFollow(id: id);
    bool _response = await _userService.unfollow(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      print('unfollow $id');
    }
  }

  followUser(String id) async {
    Map<String, dynamic> data = serializer.prepareDataToFollow(id: id);
    bool _response = await _userService.follow(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      print('follow $id');
    }
  }

  fetchFollowing() async {
    setState(LoadingState.loading);
    UsersLikedModel _response = await _postsService
        .getUsersLiked(type: 'like', userId: profile.id, objectType: 'post', objectId: post.id, page: page, limit: 20)
        .onError((error, stackTrace) => onError(error));
    // print("_response.users.length${_response.count}");
    if (_response != null && _response.users.length > 0) {
      likedUser = _response.users;
      notifyListeners();
    }
    setState(LoadingState.idle);
  }
}
