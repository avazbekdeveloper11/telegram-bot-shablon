import 'dart:io';

import 'package:facetap/state_manager/manager.dart';
import 'package:video_trimmer/video_trimmer.dart';

class VideoTrimmerViewModel extends BaseViewModel {
  final Trimmer trimmer = Trimmer();

  double startValue = 0.0;
  double endValue = 0.0;

  bool isPlaying = false;
  bool progressVisibility = false;

  saveVideo() async {
    if (!progressVisibility) {
      progressVisibility = true;
      notifyListeners();
      String _value;

      await trimmer.saveTrimmedVideo(startValue: startValue, endValue: endValue).then((value) {
        progressVisibility = false;
        _value = value;
        notifyListeners();
      });

      print('OUTPUT PATH: $_value');
      navigationService.pop(_value);
    }
  }

  void loadVideo(File file) {
    trimmer.loadVideo(videoFile: file);
  }

  initData(File file) {
    loadVideo(file);
    super.initState();
  }

  @override
  void onDispose() {
    trimmer.dispose();
    super.onDispose();
  }

  void onBackPressed() {
    navigationService.pop();
  }
}
