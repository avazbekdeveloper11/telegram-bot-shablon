import 'dart:io';

import 'package:facetap/generated/assets.dart';
import 'package:facetap/pages/video_trimmer/video_trimmer_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:video_trimmer/video_trimmer.dart';

class VideoTrimmer extends StatelessWidget {
  final File file;

  const VideoTrimmer({Key key, this.file}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<VideoTrimmerViewModel>.reactive(
      viewModelBuilder: () => VideoTrimmerViewModel(),
      initState: (model) => model.initData(file),
      onDispose: (model) => model.onDispose(),
      builder: (context, model, _) {
        return Scaffold(
          backgroundColor: BottomSheetColor,
          appBar: AppBar(
            centerTitle: true,
            title: Text('Trim Video', style: Regular),
            leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
            actions: [
              IconButton(
                icon: Icon(Icons.done_outlined, color: WhiteColor, size: 28.0),
                onPressed: model.progressVisibility
                    ? null
                    : () async {
                        model.saveVideo();
                      },
              ),
            ],
            elevation: 0,
            backgroundColor: Transparent,
          ),
          body: Builder(
            builder: (context) => Center(
              child: Container(
                padding: EdgeInsets.only(bottom: 30.0),
                color: Colors.black,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget>[
                    Visibility(visible: model.progressVisibility, child: LinearProgressIndicator(backgroundColor: Colors.red)),
                    Expanded(child: VideoViewer(trimmer: model.trimmer)),
                    Center(
                      child: TrimEditor(
                        trimmer: model.trimmer,
                        viewerHeight: 50.0,
                        viewerWidth: MediaQuery.of(context).size.width,
                        maxVideoLength: Duration(seconds: 60),
                        onChangeStart: (value) {
                          model.startValue = value;
                        },
                        onChangeEnd: (value) {
                          model.endValue = value;
                        },
                        onChangePlaybackState: (value) {
                          model.isPlaying = value;
                          model.notifyListeners();
                        },
                      ),
                    ),
                    TextButton(
                      child: model.isPlaying
                          ? Icon(Icons.pause, size: 80.0, color: Colors.white)
                          : Icon(Icons.play_arrow, size: 80.0, color: Colors.white),
                      onPressed: () async {
                        bool playbackState = await model.trimmer.videPlaybackControl(startValue: model.startValue, endValue: model.endValue);
                        model.isPlaying = playbackState;
                        model.notifyListeners();
                      },
                    )
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
