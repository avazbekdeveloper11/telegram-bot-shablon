import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/scrollable_footer_layout.dart';
import 'package:facetap/global_widgets/views/changed_text_form_field.dart';
import 'package:facetap/global_widgets/views/subscribe_button.dart';
import 'package:facetap/pages/login_page/view_model/reset_password_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/validators.dart';
import 'package:flutter/material.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class ResetPasswordPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ResetPasswordViewModel>.reactive(
      initState: (model) => model.initState(),
      viewModelBuilder: () => ResetPasswordViewModel(),
      builder: (context, model, _) {
        return BaseClass(
          child: Container(
            color: PrimaryDarkColor.withOpacity(0.5),
            child: Scaffold(
              resizeToAvoidBottomInset: false,
              backgroundColor: PrimaryDarkColor.withOpacity(0.5),
              appBar: AppBar(elevation: 0, backgroundColor: PrimaryDarkColor.withOpacity(0.5)),
              body: Container(
                color: PrimaryDarkColor.withOpacity(0.5),
                child: NoScrollGlow(
                  child: ScrollableFooterLayout(
                    children: [
                      Form(
                        key: model.resetPasswordKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                              child: Text("Reset Password", style: Medium.copyWith(fontSize: 32.0, color: WhiteColor)),
                            ),
                            ChangedTextFormField(
                                controller: model.emailController,
                                labelText: "Email",
                                validator: (value) {
                                  if (value.isEmpty) return 'Please enter Email';
                                  if (!isEmailValidate(value)) return 'Please enter correct Email';
                                  return null;
                                },
                                textInputType: TextInputType.text),
                          ],
                        ),
                      ),
                    ],
                    footer: Padding(
                      padding: EdgeInsets.only(top: 16.0, left: 20.0, right: 20.0, bottom: 36.0),
                      child: Container(
                          height: 44.0,
                          child: model.loading ?  Center(
                            child: SizedBox(height:40, width: 40, child: Row(
                              children: [
                                CircularProgressIndicator(),
                              ],
                            )),
                          ) : SubscribeButton(
                              onTap: model.onResetPassword, text: "Reset", buttonColor: WhiteColor, isColorText: false, fontSize: 16.0) ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
