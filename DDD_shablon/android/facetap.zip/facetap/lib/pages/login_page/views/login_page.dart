import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/views/changed_text_form_field.dart';
import 'package:facetap/global_widgets/views/subscribe_button.dart';
import 'package:facetap/pages/login_page/view_model/login_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/validators.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LoginViewModel>.reactive(
        initState: (model) => model.initState(),
        onDispose: (model) => model.onDispose(),
        viewModelBuilder: () => LoginViewModel(),
        builder: (context, model, _) {
          return BaseClass(
            child: Container(
              color: PrimaryDarkColor.withOpacity(0.5),
              child: Stack(
                children: [
                  Scaffold(
                    resizeToAvoidBottomInset: false,
                    backgroundColor: PrimaryDarkColor.withOpacity(0.5),
                    appBar: AppBar(elevation: 0, backgroundColor: PrimaryDarkColor.withOpacity(0.5)),
                    body: Container(
                      color: PrimaryDarkColor.withOpacity(0.5),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Flexible(
                          fit: FlexFit.loose,
                          child: NoScrollGlow(
                            child: SingleChildScrollView(
                              child: Form(
                                key: model.loginKey,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                                      child: Text('Log In', style: Medium.copyWith(fontSize: 32.0, color: WhiteColor)),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                      child: TypeAheadFormField(
                                        textFieldConfiguration: TextFieldConfiguration(
                                          keyboardType: TextInputType.emailAddress,
                                          controller: model.typeAheadController,
                                          style: Medium.copyWith(fontSize: 16.0, color: WhiteColor),
                                          cursorColor: WhiteColor,
                                          decoration: InputDecoration(
                                            labelText: 'Email',
                                            labelStyle: Medium.copyWith(fontSize: 16.0, color: TextFromFieldHintColor),
                                            disabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: TextFromFieldHintColor)),
                                            enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: TextFromFieldHintColor)),
                                            focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: TextFromFieldHintColor)),
                                            border: UnderlineInputBorder(borderSide: BorderSide(color: TextFromFieldHintColor)),
                                          ),
                                        ),
                                        suggestionsCallback: (pattern) => model.getSuggestions(pattern),
                                        itemBuilder: (context, suggestion) => ListTile(
                                          title: Text(suggestion),
                                        ),
                                        transitionBuilder: (context, suggestionsBox, controller) => suggestionsBox,
                                        onSuggestionSelected: (suggestion) {
                                          model.typeAheadController.text = suggestion;
                                        },
                                        validator: (value) {
                                          if (value.isEmpty) return 'Please enter Email';
                                          if (!isEmailValidate(value)) return 'Please enter correct Email';
                                          return null;
                                        },
                                      ),
                                    ),
                                    // ChangedTextFormField(
                                    //     controller: model.emailController,
                                    //     labelText: 'Email',
                                    //     validator: (value) {
                                    //       if (value.isEmpty) return 'Please enter Email';
                                    //       if (!isEmailValidate(value)) return 'Please enter correct Email';
                                    //       return null;
                                    //     },
                                    //     textInputType: TextInputType.emailAddress),
                                    ChangedTextFormField(
                                      controller: model.passwordController,
                                      labelText: 'Password',
                                      validator: (value) {
                                        if (value.isEmpty) return 'Please enter Password';
                                        return null;
                                      },
                                      obscureText: model.isPasswordHidden,
                                      textInputType: TextInputType.visiblePassword,
                                      suffixIcon: IconButton(
                                        onPressed: model.togglePasswordView,
                                        icon: SvgPicture.asset(
                                          model.isPasswordHidden ? Assets.svgEyeOpened : Assets.svgEyeClosed,
                                          width: 18.0,
                                          height: 18.0,
                                        ),
                                      ),
                                    ),
                                    Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        TextButton(
                                          child: Text('Reset password?', style: Medium.copyWith(fontSize: 14.0, color: AccentColor)),
                                          onPressed: model.onResetPassword,
                                        ),
                                      ],
                                    ),
/*
                                    Padding(
                                      padding: const EdgeInsets.only(left: 16.0, top: 40.0),
                                      child: Text(
                                        'Social login',
                                        style: Medium.copyWith(fontSize: 16.0, color: TextFromFieldHintColor),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 12.0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          LoginSocialContainer(svgName: Assets.svgInstagram),
                                          SizedBox(width: 8.0),
                                          LoginSocialContainer(svgName: Assets.svgFacebook),
                                          SizedBox(width: 8.0),
                                          LoginSocialContainer(svgName: Assets.svgYoutube),
                                        ],
                                      ),
                                    ),
*/
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 16.0),
                          child: Column(children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
                              child: SubscribeButton(
                                onTap: model.onSignInButton,
                                buttonColor: WhiteColor,
                                text: 'Sign In',
                                isColorText: false,
                                fontSize: 16.0,
                                isBorderColored: true,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 16.0, right: 16.0, bottom: 24.0),
                              child: SubscribeButton(onTap: model.onSignUpButton, text: 'Sign Up', isColorText: true, fontSize: 16.0),
                            ),
                          ]),
                        ),
                      ]),
                    ),
                  ),
                  model.isloading ? Loading() : Container()
                ],
              ),
            ),
          );
        });
  }
}
