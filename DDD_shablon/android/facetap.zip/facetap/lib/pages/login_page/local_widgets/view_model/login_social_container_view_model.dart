import 'package:facetap/state_manager/manager.dart';

class LoginSocialContainerViewModel extends BaseViewModel {}
