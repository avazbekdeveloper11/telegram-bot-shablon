import 'package:facetap/pages/login_page/local_widgets/view_model/login_social_container_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class LoginSocialContainer extends StatelessWidget {
  final String svgName;

  const LoginSocialContainer({Key key, this.svgName}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LoginSocialContainerViewModel>.reactive(
      viewModelBuilder: () => LoginSocialContainerViewModel(),
      builder: (context, model, _) {
        return Expanded(
          child: Container(
            padding: const EdgeInsets.all(4.0),
            decoration: BoxDecoration(
              border: Border.all(color: TextFromFieldHintColor, width: 1.0),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: SvgPicture.asset(svgName),
          ),
        );
      },
    );
  }
}
