import 'package:facetap/apis/errors.dart';
import 'package:facetap/services/authentication_service.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class ResetPasswordViewModel extends BaseViewModel {
  final AuthenticationService _authService = locator<AuthenticationService>();
  GlobalKey<FormState> resetPasswordKey = GlobalKey<FormState>();
  TextEditingController emailController;
  bool loading = false;

  @override
  void initState() {
    super.initState();
    emailController = TextEditingController();
  }

  @override
  void onDispose() {
    emailController.dispose();
    super.onDispose();
  }

  @override
  Future<T> onError<T extends Object>(error) {
    if (error == ApiClientErrors.EMAIL_NOT_EXISTS) {
      // navigationService.push(MaterialPageRoute(builder: (_) => NotInvitedPage()));
    }
    return super.onError(error);
  }

  onResetPassword() async {
    if (!resetPasswordKey.currentState.validate()) {
      return;
    }
    loading = true;
    notifyListeners();
    print(1);
    print(2);
    Map<String, dynamic> data = serializer.prepareDataToResetPassword(email: emailController.text, type: "forgot");
    print(3);
    String _response = await _authService.sendVerification(data: data).onError((error, stackTrace) => onError(error));
    print(4);
    if (_response != null) {
      print(5);
      print('password reset');
      showSnackBar(_response);
      loading = false;
      navigationService.pop();
    } else {
      showSnackBar("error");
      loading = false;
    }
    print(6);
    // navigationService
    //     .pushAndRemoveUntil(MaterialPageRoute(builder: (_) => HomePage(defaultIndex: 4)));
    print(7);
  }
}
