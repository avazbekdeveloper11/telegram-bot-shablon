import 'dart:io';

import 'package:facetap/models/error_model.dart';
import 'package:facetap/models/login_model.dart';
import 'package:facetap/pages/home_page/views/home_screen.dart';
import 'package:facetap/pages/login_page/views/reset_password_page.dart';
import 'package:facetap/pages/registration_page/views/registration_page.dart';
import 'package:facetap/providers/base_class_provider.dart';
import 'package:facetap/services/authentication_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginViewModel extends BaseViewModel {
  final AuthenticationService _authService = locator<AuthenticationService>();
  GlobalKey<FormState> loginKey = GlobalKey<FormState>();
  TextEditingController emailController;
  TextEditingController passwordController;
  bool isPasswordHidden = true;
  FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  String fcmToken = "";
  TextEditingController typeAheadController;
  List<String> emails = [];

  @override
  void initState() {
    passwordController = TextEditingController();
    emailController = TextEditingController();
    typeAheadController = TextEditingController();
    _firebaseListeners();
    getEmails();
    super.initState();
  }

  @override
  void onDispose() {
    passwordController.dispose();
    emailController.dispose();
    typeAheadController.dispose();
    super.onDispose();
  }

  void _firebaseListeners() {
    if (Platform.isIOS) _iosPermission();
    _firebaseMessaging.getToken().then((token) {
      print('\n===== fcm token $token\n');
      fcmToken = token;
    });
  }

  void _iosPermission() async {
    NotificationSettings settings = await _firebaseMessaging.requestPermission(sound: true, badge: true, alert: true);
    print('User granted permission: ${settings.authorizationStatus}');
  }

  onSignInButton() async {
    if (!loginKey.currentState.validate()) return;
    setState(LoadingState.loading);
    Map<String, dynamic> data = serializer.prepareDataToLogin(email: typeAheadController.text, fcmToken: fcmToken, password: passwordController.text);
    LoginModel _response = await _authService.login(data: data).onError((error, stackTrace) => onError(error));

    if (_response != null) {
      await appendEmailAndSave(typeAheadController.text);
      setProfileImageUrl(_response.profilePhoto, navigationService.currentContext);
      navigationService.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => HomePage(defaultIndex: 4)));
    }
    setState(LoadingState.idle);
  }

  @override
  Future<T> onError<T extends Object>(dynamic error) {
    if (error is ErrorModel) {
      switch (error.error.status) {
        case 'NOT_FOUND':
        case 'INVALID_CREDENTIALS':
          showSnackBar('E-Mail or Password is incorrect');
          break;
      }
    }
    return null;
  }

  onSignUpButton() => navigationService.push(MaterialPageRoute(builder: (_) => RegistrationPage()));

  onTermOfService() {}

  onPrivacyPolicy() {}

  togglePasswordView() {
    isPasswordHidden = !isPasswordHidden;
    notifyListeners();
  }

  onResetPassword() => navigationService.push(MaterialPageRoute(builder: (_) => ResetPasswordPage()));

  getEmails() async {
    await SharedPreferences.getInstance().then((prefs) async {
      emails = prefs.getStringList('emails') ?? [];
      print('''\n=====
        emails: $emails
        =====\n''');
    });
  }

  appendEmailAndSave(String email) async {
    if (!emails.contains(email)) {
      emails.add(email);
      await SharedPreferences.getInstance().then((pref) async {
        await pref.setStringList('emails', emails);
      });
    }
  }

  getSuggestions(String pattern) {
    List<String> list = [];
    emails.forEach((element) {
      if (element.startsWith(pattern)) list.add(element);
    });
    return list;
  }
}
