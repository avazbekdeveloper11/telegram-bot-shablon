import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/pages/gift_page/local_widgets/view_models/gift_category_view_model.dart';
import 'package:facetap/pages/gift_page/local_widgets/views/gift_item.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class GiftCategory extends StatelessWidget {
  final Function onCategoryPressed;
  final Function onGiftPressed;
  final GiftModel gift;

  const GiftCategory({Key key, this.onCategoryPressed, this.gift, this.onGiftPressed}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<GiftCategoryViewModel>.reactive(
      viewModelBuilder: () => GiftCategoryViewModel(),
      builder: (context, model, _) {
        double height = 130.0;
        return Column(
          children: [
            GestureDetector(
              onTap: onCategoryPressed,
              child: Container(
                margin: EdgeInsets.only(top: 12.0),
                padding: EdgeInsets.symmetric(vertical: 10.0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    SizedBox(width: 16.0),
                    Text(gift.category, style: Medium.copyWith(color: WhiteColor, fontSize: 16.0)),
                    Flexible(child: Container()),
                    Text('See all', style: Regular.copyWith(color: TextFromFieldHintColor, fontSize: 14.0)),
                    Container(margin: EdgeInsets.only(left: 8.0, right: 16.0), child: SvgPicture.asset(Assets.svgArrowRight)),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: height,
              child: ListView.builder(
                padding: EdgeInsets.symmetric(horizontal: 10.0),
                itemCount: gift.giftTemps.length,
                itemBuilder: (_, index) => GestureDetector(
                  onTap: () => onGiftPressed(index),
                  child: GiftItem(gift: gift.giftTemps[index]),
                ),
                scrollDirection: Axis.horizontal,
                shrinkWrap: false,
                physics: BouncingScrollPhysics(),
              ),
            ),
          ],
        );
      },
    );
  }
}
