import 'package:facetap/state_manager/manager.dart';

class FollowerRecipientsProfilesViewModel extends BaseViewModel {}
