import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/pages/gift_page/local_widgets/view_models/gift_item_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';

class GiftItem extends StatelessWidget {
  final GiftTempsModel gift;

  const GiftItem({Key key, this.gift}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<GiftItemViewModel>.reactive(
      viewModelBuilder: () => GiftItemViewModel(),
      builder: (context, model, _) {
        double radius = 12.0;
        return Column(
          children: [
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.only(left: 6.0, right: 6.0, bottom: 8.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(radius),
                child: CachedNetworkImage(
                  imageUrl: gift.image.mediaUrl,
                  fit: BoxFit.cover,
                  height: 100.0,
                  width: 100.0,
                  placeholder: (context, url) => Container(color: PrimaryLightColor),
                ),
              ),
            ),
            Text(
              '${gift.receiverPoints} vote',
              style: Regular.copyWith(color: TextFromFieldHintColor),
            )
          ],
        );
      },
    );
  }
}
