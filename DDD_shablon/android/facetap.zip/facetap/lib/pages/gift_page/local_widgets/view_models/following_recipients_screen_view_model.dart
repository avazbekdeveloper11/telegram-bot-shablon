import 'dart:async';

import 'package:facetap/models/user_model.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class FollowingRecipientsScreenViewModel extends BaseViewModel {
  final UserService _userService = locator<UserService>();
  TextEditingController searchController = TextEditingController();
  List<UserModel> following = [];
  int page = 1;
  String _search;
  Timer _searchTimer;
  UserModel profile;
  PagingController pagingController = PagingController<int, UserModel>(firstPageKey: 1);

  initData(UserModel profile) {
    this.profile = profile;
    pagingController.addPageRequestListener((pageKey) => fetchFollowing(pageKey));
    super.initState();
  }

  @override
  void onDispose() {
    pagingController.dispose();
    super.onDispose();
  }

  void onSearchChanged(String value) {
    if (_searchTimer != null) _searchTimer.cancel();
    _searchTimer = Timer(Duration(milliseconds: 500), () {
      _search = value;
      fetchFollowing(1);
    });
  }

  fetchFollowing(int pageKey) async {
    if (pageKey == 1) pagingController?.itemList?.clear();
    try {
      final _response = await _userService
          .userFollowing(userId: profile.id, page: pageKey, limit: 20, search: _search ?? '')
          .onError((error, stackTrace) => onError(error));
      final isLastPage = (pagingController.itemList ?? []).length == _response.count || (_response.results ?? []).isEmpty;
      isLastPage ? pagingController.appendLastPage(_response.results) : pagingController.appendPage(_response.results, pageKey + 1);
    } catch (error) {
      pagingController.error = error;
    }
  }
}
