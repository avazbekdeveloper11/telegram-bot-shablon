import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/views/infinite_list_empty.dart';
import 'package:facetap/global_widgets/views/search_widget.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/gift_page/local_widgets/view_models/follower_recipients_screen_view_model.dart';
import 'package:facetap/pages/gift_page/local_widgets/views/follower_recipients_profiles.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class FollowerRecipientsScreen extends StatelessWidget {
  final UserModel profile;
  final Function onRecipientSelected;

  const FollowerRecipientsScreen({Key key, this.profile, this.onRecipientSelected}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<FollowerRecipientsScreenViewModel>.reactive(
      initState: (model) => model.initData(profile),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => FollowerRecipientsScreenViewModel(),
      builder: (context, model, _) {
        return Stack(
          children: [
            NoScrollGlow(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity,
                        height: 42.0,
                        child: SearchWidget(
                          controller: model.searchController,
                          onTap: () {},
                          hintText: "Search",
                          onChangedSuffix: (value) => model.onSearchChanged(value),
                        ),
                      ),
                      PagedListView<int, UserModel>(
                        physics: NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        padding: EdgeInsets.only(top: 8.0),
                        pagingController: model.pagingController,
                        builderDelegate: PagedChildBuilderDelegate<UserModel>(
                          itemBuilder: (context, item, index) => GestureDetector(
                            onTap: () => onRecipientSelected(item),
                            child: FollowerRecipientsProfile(profile: item),
                          ),
                          firstPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                          newPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                          noItemsFoundIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            model.isloading ? Loading() : Container()
          ],
        );
      },
    );
  }
}
