import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/scrollable_footer_layout.dart';
import 'package:facetap/global_widgets/views/subscribe_button.dart';
import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/gift_page/view_model/send_gift_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class SendGiftPage extends StatelessWidget {
  final GiftTempsModel giftTemps;
  final UserModel profile;

  const SendGiftPage({Key key, this.giftTemps, this.profile}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SendGiftViewModel>.reactive(
      initState: (model) => model.initData(profile),
      viewModelBuilder: () => SendGiftViewModel(),
      builder: (context, model, _) {
        double avatarSize = 60.0;
        var messageBorder = OutlineInputBorder(
          borderSide: BorderSide(color: TextFromFieldHintColor.withOpacity(0.5)),
          borderRadius: BorderRadius.all(Radius.circular(12.0)),
        );
        return Stack(
          children: [
            Scaffold(
              backgroundColor: BottomSheetColor,
              appBar: AppBar(
                leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
                backgroundColor: Transparent,
                elevation: 0,
                centerTitle: true,
                title: Text('Gift', style: Regular),
              ),
              body: NoScrollGlow(
                child: ScrollableFooterLayout(
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                radius: avatarSize / 2,
                                backgroundColor: TextFromFieldHintColor,
                                child: model.profile.profilePhoto.isNotEmpty
                                    ? ClipRRect(
                                        borderRadius: BorderRadius.circular(avatarSize / 2),
                                        child: CachedNetworkImage(
                                          imageUrl: model.profile.profilePhoto,
                                          fit: BoxFit.cover,
                                          height: avatarSize,
                                          width: avatarSize,
                                          placeholder: (context, url) => Container(color: PrimaryLightColor),
                                        ),
                                      )
                                    : SvgPicture.asset(Assets.svgAvatarPlaceholder),
                              ),
                              GestureDetector(
                                onTap: model.changeRecipient,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 12.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('${model.profile.firstName} ${model.profile.lastName}',
                                          style: Medium.copyWith(color: WhiteColor, fontSize: 16)),
                                      SizedBox(height: 4.0),
                                      Text('Change recipient', style: Regular.copyWith(color: AccentColor, fontSize: 14)),
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                          Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              Container(
                                alignment: Alignment.center,
                                margin: EdgeInsets.only(top: 32.0, bottom: 12.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(12.0),
                                  child: CachedNetworkImage(
                                    imageUrl: giftTemps.image.mediaUrl,
                                    fit: BoxFit.cover,
                                    height: 200.0,
                                    width: 200.0,
                                    placeholder: (context, url) => Container(color: PrimaryLightColor),
                                  ),
                                ),
                              ),
                              Stack(
                                alignment: Alignment.centerLeft,
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(color: BottomSheetColor, width: 2.0),
                                      borderRadius: BorderRadius.only(topRight: Radius.circular(50.0), bottomRight: Radius.circular(50.0)),
                                      color: AccentColor,
                                    ),
                                    margin: EdgeInsets.only(left: 16.0),
                                    padding: EdgeInsets.only(left: 20.0, right: 12.0, top: 4.0, bottom: 4.0),
                                    child: Text('+ ${giftTemps.receiverPoints}', style: Medium.copyWith(color: WhiteColor, fontSize: 14.0)),
                                  ),
                                  Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(color: BottomSheetColor, width: 2.0),
                                      borderRadius: BorderRadius.circular(50.0),
                                      color: AccentColor,
                                    ),
                                    padding: EdgeInsets.all(4.0),
                                    child: SvgPicture.asset(Assets.svgFeedRating, width: 20.0, height: 20.0),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 25.0),
                            child: Form(
                              key: model.messageKey,
                              child: Container(
                                color: RoundButtonColor,
                                child: TextFormField(
                                  minLines: 2,
                                  maxLines: 2,
                                  keyboardType: TextInputType.emailAddress,
                                  controller: model.messageController,
                                  cursorColor: WhiteColor,
                                  validator: (value) {
                                    if (value.isEmpty) return 'Please enter Message';
                                    return null;
                                  },
                                  style: Medium.copyWith(fontSize: 16.0, color: WhiteColor),
                                  decoration: InputDecoration(
                                    labelStyle: Medium.copyWith(fontSize: 16.0, color: TextFromFieldHintColor),
                                    labelText: 'Your message',
                                    alignLabelWithHint: true,
                                    hintStyle: Medium.copyWith(fontSize: 16.0, color: TextFromFieldHintColor),
                                    enabledBorder: messageBorder,
                                    focusedBorder: messageBorder,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                  footer: Column(
                    children: [
                      Container(
                        height: 1.0,
                        color: TextFromFieldHintColor.withOpacity(0.5),
                        margin: EdgeInsets.symmetric(vertical: 16.0),
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('You have ${model.votes} ${model.votes > 1 ? 'votes' : 'vote'}',
                              style: Regular.copyWith(color: TextFromFieldHintColor, fontSize: 14.0)),
                          GestureDetector(
                            onTap: model.gotoWallet,
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 12.0),
                              child: Text('Buy more', style: Medium.copyWith(color: AccentColor, fontSize: 14.0)),
                            ),
                          )
                        ],
                      ),
                      Container(
                        height: 52.0,
                        margin: EdgeInsets.only(left: 16.0, right: 16.0, bottom: 32.0, top: 16.0),
                        child: SubscribeButton(
                          onTap: () => model.sendGiftPressed(giftTemps, model.profile.id),
                          isBorderColored: true,
                          buttonColor: AccentColor,
                          isColorText: true,
                          text: 'Send for ${giftTemps.price} ${giftTemps.price > 1 ? 'votes' : 'vote'}',
                          fontSize: 16.0,
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
            model.isloading ? Loading() : Container()
          ],
        );
      },
    );
  }
}
