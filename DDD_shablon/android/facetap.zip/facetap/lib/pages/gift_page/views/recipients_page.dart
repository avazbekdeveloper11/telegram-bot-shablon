import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/gift_page/local_widgets/views/follower_recipients_screen.dart';
import 'package:facetap/pages/gift_page/local_widgets/views/following_recipients_screen.dart';
import 'package:facetap/pages/gift_page/view_model/recipients_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class RecipientsPage extends StatefulWidget {
  final UserModel profile;

  RecipientsPage({Key key, this.profile}) : super(key: key);

  @override
  _FollowingPageState createState() => _FollowingPageState();
}

class _FollowingPageState extends State<RecipientsPage> with SingleTickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<RecipientsViewModel>.reactive(
      initState: (model) => model.initData(this),
      viewModelBuilder: () => RecipientsViewModel(),
      builder: (context, model, _) {
        return Scaffold(
          backgroundColor: DarkWindowColor,
          appBar: AppBar(
            centerTitle: true,
            title: Text("@${widget.profile.username}", style: Regular),
            leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
            elevation: 0,
            backgroundColor: Transparent,
            bottom: TabBar(
                isScrollable: false,
                indicatorColor: WhiteColor,
                controller: model.tabController,
                labelStyle: Medium.copyWith(fontSize: 16.0),
                unselectedLabelColor: WhiteColor.withOpacity(0.5),
                tabs: [
                  Tab(text: 'FOLLOWING', iconMargin: EdgeInsets.zero),
                  Tab(text: 'FOLLOWERS', iconMargin: EdgeInsets.zero),
                ]),
          ),
          body: TabBarView(
            controller: model.tabController,
            children: [
              FollowingRecipientsScreen(profile: widget.profile, onRecipientSelected: (recipient) => model.onRecipientSelected(recipient)),
              FollowerRecipientsScreen(profile: widget.profile, onRecipientSelected: (recipient) => model.onRecipientSelected(recipient)),
            ],
          ),
        );
      },
    );
  }
}
