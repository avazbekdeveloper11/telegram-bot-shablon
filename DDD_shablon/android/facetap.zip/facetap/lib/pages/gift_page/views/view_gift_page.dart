import 'package:cached_network_image/cached_network_image.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/pages/gift_page/view_model/view_gift_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class ViewGiftPage extends StatelessWidget {
  final MyGiftModel gift;

  const ViewGiftPage({Key key, this.gift}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ViewGiftViewModel>.reactive(
      initState: (model) => model.initData(gift),
      viewModelBuilder: () => ViewGiftViewModel(),
      builder: (context, model, _) {
        double avatarSize = 60.0;
        var messageBorder = OutlineInputBorder(
          borderSide: BorderSide(color: TextFromFieldHintColor.withOpacity(0.5)),
          borderRadius: BorderRadius.all(Radius.circular(12.0)),
        );
        return Stack(
          children: [
            Scaffold(
              backgroundColor: BottomSheetColor,
              appBar: AppBar(
                leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
                backgroundColor: Transparent,
                elevation: 0,
                centerTitle: true,
                title: Text('Gift', style: Regular),
              ),
              body: NoScrollGlow(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                        child: Column(
                          children: [
                            GestureDetector(
                              onTap: () => model.onNavigationProfilePage(gift.sender.id),
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    radius: avatarSize / 2,
                                    backgroundColor: TextFromFieldHintColor,
                                    child: gift.sender.profilePhoto.isNotEmpty
                                        ? ClipRRect(
                                            borderRadius: BorderRadius.circular(avatarSize / 2),
                                            child: CachedNetworkImage(
                                              imageUrl: gift.sender.profilePhoto,
                                              fit: BoxFit.cover,
                                              height: avatarSize,
                                              width: avatarSize,
                                              placeholder: (context, url) => Container(color: PrimaryLightColor),
                                            ),
                                          )
                                        : SvgPicture.asset(Assets.svgAvatarPlaceholder),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 12.0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('Sender', style: Regular.copyWith(color: AccentColor, fontSize: 14)),
                                        SizedBox(height: 4.0),
                                        Text(
                                          '${gift.sender.firstName} ${gift.sender.lastName}',
                                          style: Medium.copyWith(color: WhiteColor, fontSize: 16),
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                Container(
                                  alignment: Alignment.center,
                                  margin: EdgeInsets.only(top: 32.0, bottom: 12.0),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(12.0),
                                    child: CachedNetworkImage(
                                      imageUrl: gift.giftTemp.image.mediaUrl,
                                      fit: BoxFit.cover,
                                      height: 200.0,
                                      width: 200.0,
                                      placeholder: (context, url) => Container(color: PrimaryLightColor),
                                    ),
                                  ),
                                ),
                                Stack(
                                  alignment: Alignment.centerLeft,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        border: Border.all(color: BottomSheetColor, width: 2.0),
                                        borderRadius: BorderRadius.only(topRight: Radius.circular(50.0), bottomRight: Radius.circular(50.0)),
                                        color: AccentColor,
                                      ),
                                      margin: EdgeInsets.only(left: 16.0),
                                      padding: EdgeInsets.only(left: 20.0, right: 12.0, top: 4.0, bottom: 4.0),
                                      child: Text('+ ${gift.giftTemp.receiverPoints}', style: Medium.copyWith(color: WhiteColor, fontSize: 14.0)),
                                    ),
                                    Container(
                                      decoration: BoxDecoration(
                                        border: Border.all(color: BottomSheetColor, width: 2.0),
                                        borderRadius: BorderRadius.circular(50.0),
                                        color: AccentColor,
                                      ),
                                      padding: EdgeInsets.all(4.0),
                                      child: SvgPicture.asset(Assets.svgFeedRating, width: 20.0, height: 20.0),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 25.0),
                              child: Form(
                                key: model.messageKey,
                                child: Container(
                                  color: RoundButtonColor,
                                  child: TextFormField(
                                    minLines: 2,
                                    enabled: false,
                                    maxLines: 2,
                                    keyboardType: TextInputType.emailAddress,
                                    controller: model.messageController,
                                    cursorColor: WhiteColor,
                                    style: Medium.copyWith(fontSize: 16.0, color: WhiteColor),
                                    decoration: InputDecoration(
                                      labelStyle: Medium.copyWith(fontSize: 16.0, color: TextFromFieldHintColor),
                                      labelText: 'Message',
                                      alignLabelWithHint: true,
                                      hintStyle: Medium.copyWith(fontSize: 16.0, color: TextFromFieldHintColor),
                                      enabledBorder: messageBorder,
                                      disabledBorder: messageBorder,
                                      focusedBorder: messageBorder,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
            model.isloading ? Loading() : Container()
          ],
        );
      },
    );
  }
}
