import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/pages/gift_page/local_widgets/views/gift_item.dart';
import 'package:facetap/pages/gift_page/view_model/gifts_by_category_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class GiftsByCategoryPage extends StatelessWidget {
  final GiftModel gift;

  const GiftsByCategoryPage({Key key, this.gift}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<GiftsByCategoryViewModel>.reactive(
      initState: (model) => model.initState(),
      viewModelBuilder: () => GiftsByCategoryViewModel(),
      builder: (context, model, _) {
        return Stack(
          children: [
            Scaffold(
              backgroundColor: BottomSheetColor,
              appBar: AppBar(
                leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
                backgroundColor: Transparent,
                elevation: 0,
                centerTitle: true,
                title: Text(gift.category, style: Regular),
              ),
              body: NoScrollGlow(
                child: SingleChildScrollView(
                  padding: EdgeInsets.symmetric(vertical: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      GridView.builder(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
                        padding: EdgeInsets.symmetric(horizontal: 8.0),
                        itemCount: gift.giftTemps.length,
                        itemBuilder: (_, index) => GestureDetector(
                          onTap: () => model.onGiftPressed(gift.giftTemps[index]),
                          child: GiftItem(gift: gift.giftTemps[index]),
                        ),
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        physics: BouncingScrollPhysics(),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            model.isloading ? Loading() : Container()
          ],
        );
      },
    );
  }
}
