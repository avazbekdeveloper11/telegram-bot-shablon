import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/gift_page/local_widgets/views/gift_category.dart';
import 'package:facetap/pages/gift_page/view_model/gifts_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class GiftsPage extends StatelessWidget {
  final UserModel profile;

  const GiftsPage({Key key, this.profile}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<GiftsViewModel>.reactive(
      initState: (model) => model.initState(),
      viewModelBuilder: () => GiftsViewModel(),
      builder: (context, model, _) {
        return Stack(
          children: [
            Scaffold(
              backgroundColor: BottomSheetColor,
              appBar: AppBar(
                leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
                backgroundColor: Transparent,
                elevation: 0,
                centerTitle: true,
                title: Text('Gifts', style: Regular),
              ),
              body: NoScrollGlow(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      for (int index = 0; index < model.gifts.length; index++)
                        GiftCategory(
                          onCategoryPressed: () => model.onCategoryPressed(index, profile),
                          onGiftPressed: (i) => model.onGiftPressed(model.gifts[index].giftTemps[i], profile),
                          gift: model.gifts[index],
                        ),
                    ],
                  ),
                ),
              ),
            ),
            model.isloading ? Loading() : Container()
          ],
        );
      },
    );
  }
}
