import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/gift_page/views/recipients_page.dart';
import 'package:facetap/pages/wallet_page/views/wallet_page.dart';
import 'package:facetap/services/gifts_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class SendGiftViewModel extends BaseViewModel {
  final GiftsService _giftsService = locator<GiftsService>();
  final UserModel _userModel = locator<UserModel>();
  List<GiftModel> gifts = [];
  GlobalKey<FormState> messageKey = GlobalKey<FormState>();
  TextEditingController messageController;
  UserModel profile;
  int votes = 0;

  initData(UserModel profile) {
    this.profile = profile;
    votes = _userModel.votes;
    messageController = TextEditingController();
    super.initState();
  }

  @override
  onDispose() {
    messageController.dispose();
    super.onDispose();
  }

  onBackPressed() {
    navigationService.pop();
  }

  gotoWallet() {
    navigationService.push(MaterialPageRoute(builder: (_) => WalletPage()));
  }

  sendGiftPressed(GiftTempsModel giftTempsModel, String receiverId) async {
    print("rec $receiverId");
    if (!messageKey.currentState.validate()) return;
    setState(LoadingState.loading);
    BoughtGiftModel _responseGift = await _giftsService.buyGift(giftTempId: giftTempsModel.id).onError((error, stackTrace) => onError(error));
    if (_responseGift != null) {
      giftTempsModel.message = messageController.text;
      Map<String, dynamic> data = serializer.prepareDataToSendGift(
          giftId: _responseGift.giftId, giftTempId: giftTempsModel.id, message: messageController.text, receiverId: receiverId);
      bool _response = await _giftsService.sendGift(data: data).onError((error, stackTrace) => onError(error));
      if (_response != null) print('gift sent');
    }
    _userModel.votes = _userModel.votes - giftTempsModel.price;
    notifyListeners();
    setState(LoadingState.idle);
    navigationService.pop(giftTempsModel);
  }

  changeRecipient() async {
    UserModel recipient = await navigationService.push(MaterialPageRoute(builder: (_) => RecipientsPage(profile: _userModel)));
    if (recipient != null) {
      profile = recipient;
      notifyListeners();
    }
  }
}
