import 'package:facetap/models/user_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class RecipientsViewModel extends BaseViewModel {
  TabController tabController;

  onBackPressed() => navigationService.pop();

  void initData(_pageState) {
    tabController = TabController(length: 2, vsync: _pageState);
    super.initState();
  }

  @override
  void onDispose() {
    tabController?.dispose();
    super.onDispose();
  }

  onRecipientSelected(UserModel recipient) {
    navigationService.pop(recipient);
  }
}
