import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/gift_page/views/gifts_by_category_page.dart';
import 'package:facetap/pages/gift_page/views/send_gift_page.dart';
import 'package:facetap/services/gifts_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class GiftsViewModel extends BaseViewModel {
  final GiftsService _giftsService = locator<GiftsService>();
  List<GiftModel> gifts = [];

  @override
  initState() {
    fetchGifts();
    super.initState();
  }

  onBackPressed() {
    navigationService.pop();
  }

  void fetchGifts() async {
    setState(LoadingState.loading);
    AllGiftsModel _response = await _giftsService.getAllGifts(categories: 10, items: 10).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      gifts.addAll(_response.results);
      notifyListeners();
    }
    setState(LoadingState.idle);
  }

  onCategoryPressed(int index, UserModel profile) async {
    GiftTempsModel giftTemps = await navigationService.push(MaterialPageRoute(builder: (_) => GiftsByCategoryPage(gift: gifts[index])));
    if (giftTemps != null) {
      onGiftPressed(giftTemps, profile);
    }
  }

  onGiftPressed(GiftTempsModel giftTemps, UserModel profile) async {
    GiftTempsModel needUpdate = await navigationService.push(MaterialPageRoute(builder: (_) => SendGiftPage(giftTemps: giftTemps, profile: profile)));
    if (needUpdate != null) navigationService.pop(needUpdate);
  }
}
