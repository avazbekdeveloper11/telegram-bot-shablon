import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/pages/profile_page/views/profile_page.dart';
import 'package:facetap/services/gifts_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class ViewGiftViewModel extends BaseViewModel {
  final GiftsService _giftsService = locator<GiftsService>();
  List<GiftModel> gifts = [];
  GlobalKey<FormState> messageKey = GlobalKey<FormState>();
  TextEditingController messageController;

  initData(MyGiftModel gift) {
    messageController = TextEditingController(text: gift.message);
    super.initState();
  }

  @override
  onDispose() {
    messageController.dispose();
    super.onDispose();
  }

  onBackPressed() {
    navigationService.pop();
  }

  sendGiftPressed(String giftTempId, String receiverId) async {
    if (!messageKey.currentState.validate()) return;
    setState(LoadingState.loading);
    BoughtGiftModel _responseGift = await _giftsService.buyGift(giftTempId: giftTempId).onError((error, stackTrace) => onError(error));
    if (_responseGift != null) {
      Map<String, dynamic> data = serializer.prepareDataToSendGift(
          giftId: _responseGift.giftId, giftTempId: giftTempId, message: messageController.text, receiverId: receiverId);
      bool _response = await _giftsService.sendGift(data: data).onError((error, stackTrace) => onError(error));
      if (_response != null) {
        print('gift sent');
      }
    }
    setState(LoadingState.idle);
    navigationService.pop();
  }

  onNavigationProfilePage(String id) {
    navigationService.push(MaterialPageRoute(builder: (_) => ProfilePage(userId: id, isNavigatorPop: true)));
  }
}
