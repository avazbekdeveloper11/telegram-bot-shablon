import 'package:facetap/models/gifts_model.dart';
import 'package:facetap/services/gifts_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';

class GiftsByCategoryViewModel extends BaseViewModel {
  final GiftsService _giftsService = locator<GiftsService>();
  List<GiftModel> gifts = [];

  @override
  initState() {
    //fetchGifts();
    super.initState();
  }

  onBackPressed() {
    navigationService.pop();
  }

  void fetchGifts() async {
    setState(LoadingState.loading);
    AllGiftsModel _response = await _giftsService.getAllGifts(categories: 10, items: 10).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      gifts.addAll(_response.results);
      notifyListeners();
    }
    setState(LoadingState.idle);
  }

  onGiftPressed(GiftTempsModel giftTemps) {
    //navigationService.push(MaterialPageRoute(builder: (_) => SendGiftPage(giftTemps: giftTemps, profile: profile)));
    navigationService.pop(giftTemps);
  }
}
