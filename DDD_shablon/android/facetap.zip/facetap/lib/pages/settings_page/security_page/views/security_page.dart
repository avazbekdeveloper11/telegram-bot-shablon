import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/pages/settings_page/local_widget/views/settings_templates.dart';
import 'package:facetap/pages/settings_page/security_page/view_model/security_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';

class SecurityPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SecurityViewModel>.reactive(
      viewModelBuilder: () => SecurityViewModel(),
      builder: (context, model, _) {
        return BaseClass(
          child: Container(
            color: PrimaryDarkColor.withOpacity(0.5),
            child: Scaffold(
              backgroundColor: PrimaryDarkColor.withOpacity(0.5),
              appBar: AppBar(elevation: 0, backgroundColor: PrimaryDarkColor.withOpacity(0.5)),
              body: Container(
                color: PrimaryDarkColor.withOpacity(0.5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        "Security",
                        style: Medium.copyWith(fontSize: 32.0, color: WhiteColor),
                      ),
                    ),
                    SettingsTemplates(
                      name: "Password",
                      leadingWidget: Icon(Icons.vpn_key_outlined, color: WhiteColor),
                      onNavigationTap: model.onNavigationPassword,
                    ),
                    SettingsTemplates(
                      name: "Login activity",
                      leadingWidget: Icon(Icons.location_pin, color: WhiteColor),
                    ),
                    SettingsTemplates(
                      name: "Saved login information",
                      leadingWidget: Icon(Icons.perm_device_information, color: WhiteColor),
                    ),
                    SettingsTemplates(
                      name: "Two-factor authentication",
                      leadingWidget: Icon(Icons.admin_panel_settings, color: WhiteColor),
                    ),
                    SettingsTemplates(
                      name: "Emails from FaceTap",
                      leadingWidget: Icon(Icons.email, color: WhiteColor),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
