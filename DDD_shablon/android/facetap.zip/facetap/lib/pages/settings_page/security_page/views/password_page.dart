import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/scrollable_footer_layout.dart';
import 'package:facetap/global_widgets/views/changed_text_form_field.dart';
import 'package:facetap/global_widgets/views/subscribe_button.dart';
import 'package:facetap/pages/settings_page/security_page/view_model/password_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/validators.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class PasswordPage extends StatelessWidget {
  final bool resetPassword;

  const PasswordPage({Key key, this.resetPassword=false}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PasswordViewModel>.reactive(
      initState: (model) => model.initState(),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => PasswordViewModel(),
      builder: (context, model, _) {
        return Scaffold(
          resizeToAvoidBottomInset: false,
          backgroundColor: DarkWindowColor,
          appBar: AppBar(
            centerTitle: true,
            title: Text("Password", style: Regular),
            leading: resetPassword ? Container() : IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
            elevation: 0,
            backgroundColor: Transparent,
          ),
          body: NoScrollGlow(
            child: ScrollableFooterLayout(
              children: [
                Form(
                  key: model.changePasswordKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
/*
                      ChangedTextFormField(
                          controller: model.currentPasswordController,
                          labelText: "Current password",
                          textInputType: TextInputType.emailAddress),
*/
                      ChangedTextFormField(
                          controller: model.newPasswordController,
                          labelText: "New password",
                          validator: (value) {
                            if (value.isEmpty) return 'Please enter New Password';
                            if (!isPasswordValidate(value)) return 'Min 8 characters including one capital letter, symbol and a number';
                            return null;
                          },
                          focusNode: model.newPasswordNode,
                          onFieldSubmitted: (value) {
                            model.fieldFocusChange(model.newPasswordNode, model.enterNewPasswordNode);
                          },
                          textInputType: TextInputType.text),
                      ChangedTextFormField(
                          controller: model.enterNewPasswordController,
                          labelText: "Re-enter new password",
                          focusNode: model.enterNewPasswordNode,
                          validator: (value) {
                            if (value.isEmpty) return 'Please Re-enter new password';
                            if (value != model.newPasswordController.text) return 'Passwords should be same';
                            if (!isPasswordValidate(value)) return 'Min 8 characters including one capital letter, symbol and a number';
                            return null;
                          },
                          textInputType: TextInputType.text),
                    ],
                  ),
                ),
              ],
              footer: Padding(
                padding: EdgeInsets.only(top: 16.0, left: 20.0, right: 20.0, bottom: 36.0),
                child: Container(
                    height: 44.0,
                    child:
                        SubscribeButton(onTap: resetPassword ? model.onPasswordReset : model.onPasswordChange, text: resetPassword ? "Save" : "Change", buttonColor: WhiteColor, isColorText: false, fontSize: 16.0)),
              ),
            ),
          ),
        );
      },
    );
  }
}
