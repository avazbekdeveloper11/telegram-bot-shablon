import 'package:facetap/pages/settings_page/security_page/views/password_page.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class SecurityViewModel extends BaseViewModel {
  onNavigationPassword() {
    navigationService.push(MaterialPageRoute(builder: (_) => PasswordPage(resetPassword: false,)));
  }
}
