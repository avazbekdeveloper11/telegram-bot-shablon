import 'package:facetap/apis/errors.dart';
import 'package:facetap/pages/home_page/views/home_screen.dart';
import 'package:facetap/services/authentication_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class PasswordViewModel extends BaseViewModel {
  final AuthenticationService _authService = locator<AuthenticationService>();
  GlobalKey<FormState> changePasswordKey = GlobalKey<FormState>();
  TextEditingController currentPasswordController;
  TextEditingController newPasswordController;
  TextEditingController enterNewPasswordController;

  FocusNode newPasswordNode;
  FocusNode enterNewPasswordNode;

  @override
  void initState() {
    print(1);
    super.initState();
    currentPasswordController = TextEditingController();
    newPasswordController = TextEditingController();
    enterNewPasswordController = TextEditingController();
    newPasswordNode = FocusNode();
    enterNewPasswordNode = FocusNode();
  }

  @override
  void onDispose() {
    currentPasswordController.dispose();
    newPasswordController.dispose();
    enterNewPasswordController.dispose();
    newPasswordNode.dispose();
    enterNewPasswordNode.dispose();
    super.onDispose();
  }

  @override
  Future<T> onError<T extends Object>(error) {
    if (error == ApiClientErrors.EMAIL_NOT_EXISTS) {
      // navigationService.push(MaterialPageRoute(builder: (_) => NotInvitedPage()));
    }
    return super.onError(error);
  }

  onBackPressed() => navigationService.pop();

  onPasswordChange() async {
    if (!changePasswordKey.currentState.validate()) return;
    setState(LoadingState.loading);

    Map<String, dynamic> data = serializer.prepareDataToChangePassword(password: newPasswordController.text);
    bool _response = await _authService.setPassword(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
    print(_response);
      print('password changed');
    }
      showSnackBar('password changed');
    navigationService.pop();
    setState(LoadingState.idle);
  }

  onPasswordReset() async {
    if (!changePasswordKey.currentState.validate()) return;
    setState(LoadingState.loading);

    Map<String, dynamic> data = serializer.prepareDataToChangePassword(password: newPasswordController.text);
    bool _response = await _authService.setPassword(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      print('password changed');
    }
    navigationService.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => HomePage(defaultIndex: 4,)));
    setState(LoadingState.idle);
  }


  fieldFocusChange(FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(navigationService.currentContext).requestFocus(nextFocus);
  }
}
