import 'dart:io';

import 'package:facetap/generated/assets.dart';
import 'package:facetap/models/scheme_model.dart';
import 'package:facetap/models/share_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/models/vote_cards_model.dart';
import 'package:facetap/pages/home_page/views/home_screen.dart';
import 'package:facetap/pages/interests_page/views/edit_interests_page.dart';
import 'package:facetap/pages/settings_page/blocked_accounts_page/views/blocked_accounts_page.dart';
import 'package:facetap/pages/settings_page/privacy_page/views/privacy_page.dart';
import 'package:facetap/pages/settings_page/security_page/views/password_page.dart';
import 'package:facetap/pages/settings_page/security_page/views/security_page.dart';
import 'package:facetap/pages/wallet_page/views/wallet_page.dart';
import 'package:facetap/services/authentication_service.dart';
import 'package:facetap/services/cache_service.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/validators.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_appavailability/flutter_appavailability.dart';
import 'package:flutter_svg/svg.dart';
import 'package:share_options/share_options.dart';

class SettingsViewModel extends BaseViewModel {
  final AuthenticationService _authService = locator<AuthenticationService>();
  final UserService _userService = locator<UserService>();
  final UserModel _userModel = locator<UserModel>();
  final CacheService _cacheService = locator<CacheService>();
  List<ShareOption> shareOptions = [];
  List<SchemeModel> shareOptionsIOS = [];
  int votes = 0;

  @override
  initState() {
    votes = _userModel.votes;
    if (shareOptionsIOS.length <= 1) {
      shareOptionsIOS.clear();
      shareOptionsIOS.add(null);
      schemas.forEach((element) async {
        try {
          var availability = await AppAvailability.checkAvailability(element.scheme);
          print('===== scheme $element: ${availability['package_name']}');
          shareOptionsIOS.add(element);
        } catch (e) {
          print((e as PlatformException).message);
        }
      });
    }
    super.initState();
  }

  fetchUserVotes() async {
    UserVotes _response = await _userService.getUserVotes().onError((error, stackTrace) => onError(error));
    if (_response != null) {
      _userModel.votes = _response.votes;
      votes = _userModel.votes;
    }
    notifyListeners();
  }

  onNavigationSecurityPage() {
    navigationService.push(MaterialPageRoute(builder: (_) => SecurityPage()));
  }

  onNavigationWalletPage() {
    navigationService.push(MaterialPageRoute(builder: (_) => WalletPage()));
  }

  onNavigationPrivacyPage() {
    navigationService.push(MaterialPageRoute(builder: (_) => PrivacyPage()));
  }

  onNavigationBlockAccountsPage() {
    navigationService.push(MaterialPageRoute(builder: (_) => BlockedAccountsPage()));
  }

  void onSwitchAccount() {}

  void onLogout() async {
    bool _response = await _authService.logout().onError((error, stackTrace) => onError(error));
    if (_response != null) print("\n===== logout =====\n");
    _cacheService.saveAccessToken("");
    _cacheService.saveRefreshToken("");
    _cacheService.saveId("");
    _cacheService.saveProfileImage("");
    _userModel.setProfile(UserModel());
    _userModel.setProfileAuth("", "");
    navigationService.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => HomePage()));
  }

  void onBackPressed() => navigationService.pop();

  onNavigationPassword() {
    navigationService.push(MaterialPageRoute(builder: (_) => PasswordPage(resetPassword: false)));
  }

  shareProfile() async {
    if (_userModel.share == null) {
      setState(LoadingState.loading);
      ShareModel _response = await _userService.getProfileLink(userId: _userModel.id).onError((error, stackTrace) => onError(error));
      if (_response != null) {
        _userModel.share = _response.url;
        notifyListeners();
      }
      setState(LoadingState.idle);
    }
    if (Platform.isAndroid) {
      if (shareOptions.length <= 1) {
        shareOptions.clear();
        shareOptions.add(null);
        final options = await ShareOptions.getTextShareOptions('Check out facetap profile ${_userModel.share}', subject: 'Facetap Profile');
        options.forEach((element) {
          if (checkSocialOccurrences(element.activityInfo.packageName) || checkSocialOccurrences(element.activityInfo.className))
            shareOptions.add(element);
        });
      }
    } else {
      if (shareOptionsIOS.length <= 1) {
        shareOptionsIOS.clear();
        shareOptionsIOS.add(null);
        schemas.forEach((element) async {
          try {
            var availability = await AppAvailability.checkAvailability(element.scheme);
            print('===== scheme $element: ${availability['package_name']}');
            shareOptionsIOS.add(element);
          } catch (e) {
            print((e as PlatformException).message);
          }
        });
      }
    }
    showProfileBottomSheet();
  }

  showProfileBottomSheet() => showModalBottomSheet(
        backgroundColor: BottomSheetColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(12.0), topRight: Radius.circular(12.0))),
        context: navigationService.currentContext,
        builder: (BuildContext bc) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16, right: 16, top: 12, bottom: 16.0),
                child: Text('Share on', style: Regular.copyWith(color: WhiteColor, fontSize: 16)),
              ),
              Platform.isIOS
                  ? Container(
                      color: Color(0xff1d1d1d),
                      padding: EdgeInsets.symmetric(vertical: 16.0),
                      child: SizedBox(
                        height: 90.0,
                        child: ListView.builder(
                          itemCount: shareOptionsIOS.length,
                          itemBuilder: (_, index) {
                            var shareOption = shareOptionsIOS[index];
                            return Container(
                              width: 90.0,
                              child: shareOption == null
                                  ? InkWell(
                                      onTap: () => Clipboard.setData(new ClipboardData(text: _userModel.share)).then((_) {
                                        onBackPressed();
                                        showSnackBar('Link copied to clipboard');
                                      }),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          CircleAvatar(
                                            radius: 24.0,
                                            backgroundColor: RoundButtonColor,
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(24.0),
                                              child: Padding(
                                                padding: const EdgeInsets.all(10.0),
                                                child: SvgPicture.asset(Assets.svgCopy, width: 48.0, height: 48.0),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              'Copy link',
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : InkWell(
                                      onTap: () => shareIos(shareOption, _userModel.share), //=> shareOption.share(),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          ClipRRect(
                                            borderRadius: BorderRadius.circular(24.0),
                                            child: SvgPicture.asset(shareOption.iconAssets, width: 48, height: 48),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              shareOption.name,
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                            );
                          },
                          scrollDirection: Axis.horizontal,
                          shrinkWrap: false,
                          physics: BouncingScrollPhysics(),
                        ),
                      ),
                    )
                  : Container(
                      color: Color(0xff1d1d1d),
                      padding: EdgeInsets.symmetric(vertical: 16.0),
                      child: SizedBox(
                        height: 90.0,
                        child: ListView.builder(
                          itemCount: shareOptions.length,
                          itemBuilder: (_, index) {
                            var shareOption = shareOptions[index];
                            return Container(
                              width: 90.0,
                              child: shareOption == null
                                  ? InkWell(
                                      onTap: () => Clipboard.setData(new ClipboardData(text: _userModel.share)).then((_) {
                                        onBackPressed();
                                        showSnackBar('Link copied to clipboard');
                                      }),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          CircleAvatar(
                                            radius: 24.0,
                                            backgroundColor: RoundButtonColor,
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(24.0),
                                              child: Padding(
                                                padding: const EdgeInsets.all(10.0),
                                                child: SvgPicture.asset(Assets.svgCopy, width: 48.0, height: 48.0),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              'Copy link',
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : InkWell(
                                      onTap: () => shareOption.share(),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          ClipRRect(
                                            borderRadius: BorderRadius.circular(24.0),
                                            child: Image.memory(shareOption.icon, width: 48.0, height: 48.0),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 8.0),
                                            child: Text(
                                              shareOption.name,
                                              overflow: TextOverflow.ellipsis,
                                              style: Regular.copyWith(color: WhiteColor),
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                            );
                          },
                          scrollDirection: Axis.horizontal,
                          shrinkWrap: false,
                          physics: BouncingScrollPhysics(),
                        ),
                      ),
                    ),
            ],
          );
        },
      );

  shareIos(SchemeModel shareOption, String url) {
    var launch = '';
    switch (shareOption.scheme) {
      case 'fb://': //fb://post/%s  https://gist.github.com/nhnam/5f106eaebff6366c0e21578c40515094
        launch = 'post/$url';
        break;
      case 'twitter://': //twitter://post?message=[Tweet Text]  https://github.com/yeswasi/URLScheme/wiki/Twitter
        launch = 'post?message=$url';
        break;
      case 'vk://': // not support https://github.com/VKCOM/vk-ios-sdk/issues/545#issuecomment-554340462
        launch = '';
        break;
      case 'whatsapp://': // whatsapp://send?text=xxx
        launch = 'send?text=$url';
        break;
      case 'tg://': // tg://msg?text=Hello
        launch = 'msg?text=$url';
        break;
      case 'viber://': // viber://forward?text=foo
        launch = 'forward?text=$url';
        break;
      case 'wechat://': // no info
        launch = '';
        break;
      case 'line://': // no info
        launch = '';
        break;
      case 'instagram://': //  maybe
        launch = 'send/text=$url';
        break;
      case 'ha://': // no info
        launch = '';
        break;
      case 'linkedin://': //
        launch = '';
        break;
    }
    if (launch.isNotEmpty) AppAvailability.launchApp(shareOption.scheme + launch);
  }

  showLogoutBottomSheet() => showModalBottomSheet(
        backgroundColor: BottomSheetColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(12.0), topRight: Radius.circular(12.0))),
        context: navigationService.currentContext,
        builder: (BuildContext context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16, right: 16, top: 12),
                child: Text('Are you sure to logout?', style: Medium.copyWith(color: WhiteColor, fontSize: 16)),
              ),
              Container(
                margin: EdgeInsets.only(top: 16.0),
                padding: EdgeInsets.only(left: 16, right: 16),
                color: Color(0xff1d1d1d),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      ListTile(
                        title: Center(child: Text('Switch account', style: Regular.copyWith(fontSize: 16.0, color: WhiteColor))),
                        onTap: onSwitchAccount,
                      ),
                      ListTile(
                        title: Center(child: Text('Log out', style: Regular.copyWith(fontSize: 16.0, color: AccentColor))),
                        onTap: onLogout,
                      ),
                    ],
                  ),
                ),
              )
            ],
          );
        },
      );

  showLogoutDialog() => showDialog(
        context: navigationService.currentContext,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: Color(0xff1e1e1e),
            title: Text('Are you sure to logout?', style: Medium.copyWith(color: WhiteColor)),
            content: Text("You can login later with your credentials.", style: Regular.copyWith(color: WhiteColor)),
            actions: [
              TextButton(
                child: Text('Cancel', style: Medium.copyWith(color: WhiteColor)),
                onPressed: () => navigationService.pop(),
              ),
              TextButton(
                child: Text('Logout', style: Medium.copyWith(color: AccentColor)),
                onPressed: onLogout,
              )
            ],
          );
        },
      );

  onNavigationEditInterestsPage() {
    navigationService.push(MaterialPageRoute(builder: (_) => EditInterestsPage()));
  }
}
