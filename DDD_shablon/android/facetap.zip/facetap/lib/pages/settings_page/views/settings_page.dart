import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/pages/settings_page/local_widget/views/settings_templates.dart';
import 'package:facetap/pages/settings_page/view_model/settings_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class SettingsPage extends StatefulWidget {
  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SettingsViewModel>.reactive(
      initState: (model) => model.initState(),
      viewModelBuilder: () => SettingsViewModel(),
      builder: (context, model, _) {
        return Stack(
          children: [
            Scaffold(
              backgroundColor: DarkWindowColor,
              appBar: AppBar(
                leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
                backgroundColor: Transparent,
                elevation: 0,
                centerTitle: true,
                title: Text('Settings', style: Regular),
              ),
              body: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SettingsTemplates(
                    name: 'Wallet',
                    leadingWidget: Icon(Icons.account_balance_wallet_outlined, color: WhiteColor),
                    trailingWidget: Row(
                      children: [
                        Text('${model.votes}', style: Bold.copyWith(color: WhiteColor, fontSize: 16.0)),
                        Padding(
                          padding: EdgeInsets.only(left: 16.0),
                          child: SvgPicture.asset(Assets.svgDiamond, width: 24, height: 24),
                        ),
                      ],
                    ),
                    onNavigationTap: model.onNavigationWalletPage,
                  ),
                  SettingsTemplates(
                    name: 'Change password',
                    onNavigationTap: model.onNavigationPassword,
                    leadingWidget: SvgPicture.asset(Assets.svgSettingsPrivacy),
                  ),
                  /*SettingsTemplates(
                    name: "Security",
                    onNavigationTap: model.onNavigationSecurityPage,
                  ),*/
                  /*SettingsTemplates(
                    name: "Privacy",
                    onNavigationTap: model.onNavigationPrivacyPage,
                  ),*/
                  SettingsTemplates(
                    name: 'Blocked accounts',
                    onNavigationTap: model.onNavigationBlockAccountsPage,
                    leadingWidget: SvgPicture.asset(Assets.svgBlocked),
                  ),
                  SettingsTemplates(
                    name: 'Interests',
                    onNavigationTap: model.onNavigationEditInterestsPage,
                    leadingWidget: SvgPicture.asset(Assets.svgSettingsInterests),
                  ),
                  SettingsTemplates(
                    name: 'Share profile',
                    onNavigationTap: model.shareProfile,
                    leadingWidget: SvgPicture.asset(Assets.svgSettingsShare),
                  ),
                  SettingsTemplates(
                    name: 'Logout',
                    onNavigationTap: model.showLogoutDialog, //model.showLogoutBottomSheet,
                    leadingWidget: SvgPicture.asset(Assets.svgLogOut),
                  ),
                ],
              ),
            ),
            model.isloading ? Loading() : Container()
          ],
        );
      },
    );
  }
}
