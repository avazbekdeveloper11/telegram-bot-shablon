import 'package:facetap/pages/profile_page/views/profile_page.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class BlockedProfilesViewModel extends BaseViewModel {
  onNavigationProfilePage(String id) {
    navigationService.push(MaterialPageRoute(builder: (_) => ProfilePage(userId: id, isNavigatorPop: true)));
  }
}
