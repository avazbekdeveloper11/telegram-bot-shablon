import 'dart:async';

import 'package:facetap/models/blocked_users_model.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class BlockedAccountsViewModel extends BaseViewModel {
  final UserService _userService = locator<UserService>();
  TextEditingController searchController = TextEditingController();
  List<BlockedModel> blocked = [];
  String _search;
  Timer _searchTimer;
  PagingController pagingController = PagingController<int, BlockedModel>(firstPageKey: 1);

  @override
  void initState() {
    pagingController.addPageRequestListener((pageKey) => fetchBlocked(pageKey));
    super.initState();
  }

  @override
  void onDispose() {
    pagingController.dispose();
    super.onDispose();
  }

  onBackPressed() => navigationService.pop();

  onChangeBlocked(int index) {
    pagingController.itemList[index].isBlocked ? unblockUser(pagingController.itemList[index].id) : blockUser(pagingController.itemList[index].id);
    pagingController.itemList[index].isBlocked = !pagingController.itemList[index].isBlocked;
    notifyListeners();
  }

  unblockUser(String id) async {
    Map<String, dynamic> data = serializer.prepareDataToBlock(id: id);
    bool _response = await _userService.unblock(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print("unblock $id");
  }

  blockUser(String id) async {
    Map<String, dynamic> data = serializer.prepareDataToBlock(id: id);
    bool _response = await _userService.block(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print("block $id");
  }

  void onSearchChanged(String value) {
    if (_searchTimer != null) _searchTimer.cancel();
    _searchTimer = Timer(Duration(milliseconds: 500), () {
      _search = value;
      fetchBlocked(1);
    });
  }

  fetchBlocked(int pageKey) async {
    if (pageKey == 1) pagingController?.itemList?.clear();
    try {
      final _response =
          await _userService.getBlockedUsers(page: pageKey, limit: 20, search: _search ?? '').onError((error, stackTrace) => onError(error));
      final isLastPage = (pagingController.itemList ?? []).length == _response.count || (_response.results ?? []).isEmpty;
      isLastPage ? pagingController.appendLastPage(_response.results) : pagingController.appendPage(_response.results, pageKey + 1);
    } catch (error) {
      pagingController.error = error;
    }
  }
}
