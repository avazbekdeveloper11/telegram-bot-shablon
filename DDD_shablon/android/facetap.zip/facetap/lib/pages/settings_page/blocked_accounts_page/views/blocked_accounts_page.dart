import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/views/infinite_list_empty.dart';
import 'package:facetap/global_widgets/views/search_widget.dart';
import 'package:facetap/models/blocked_users_model.dart';
import 'package:facetap/pages/settings_page/blocked_accounts_page/local_widgets/views/blocked_profiles.dart';
import 'package:facetap/pages/settings_page/blocked_accounts_page/view_model/blocked_accounts_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class BlockedAccountsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<BlockedAccountsViewModel>.reactive(
      initState: (model) => model.initState(),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => BlockedAccountsViewModel(),
      builder: (context, model, _) {
        return Scaffold(
          backgroundColor: DarkWindowColor,
          appBar: AppBar(
            centerTitle: true,
            title: Text('Blocked accounts', style: Regular),
            leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
            elevation: 0,
            backgroundColor: Transparent,
          ),
          body: Stack(
            children: [
              NoScrollGlow(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 8.0, right: 16.0, left: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          width: double.infinity,
                          height: 42.0,
                          child: SearchWidget(
                            onEditingComplete: () {},
                            controller: model.searchController,
                            onTap: () {},
                            hintText: 'Search',
                            onChangedSuffix: (value) => model.onSearchChanged(value),
                          ),
                        ),
                        PagedListView<int, BlockedModel>(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          pagingController: model.pagingController,
                          builderDelegate: PagedChildBuilderDelegate<BlockedModel>(
                            itemBuilder: (context, item, index) => BlockedProfile(
                              profile: item,
                              onChangeFollowing: () => model.onChangeBlocked(index),
                            ),
                            firstPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                            newPageErrorIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                            noItemsFoundIndicatorBuilder: (_) => InfiniteListEmptyItem(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              model.isloading ? Loading() : Container()
            ],
          ),
        );
      },
    );
  }
}
