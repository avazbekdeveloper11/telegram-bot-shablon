import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/pages/settings_page/local_widget/views/settings_templates.dart';
import 'package:facetap/pages/settings_page/privacy_page/view_model/privacy_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';

class PrivacyPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PrivacyViewModel>.reactive(
      viewModelBuilder: () => PrivacyViewModel(),
      builder: (context, model, _) {
        return BaseClass(
          child: Container(
            color: PrimaryDarkColor.withOpacity(0.5),
            child: Scaffold(
              backgroundColor: PrimaryDarkColor.withOpacity(0.5),
              appBar: AppBar(
                elevation: 0,
                backgroundColor: PrimaryDarkColor.withOpacity(0.5),
              ),
              body: Container(
                color: PrimaryDarkColor.withOpacity(0.5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        'Privacy',
                        style: Medium.copyWith(fontSize: 32.0, color: WhiteColor),
                      ),
                    ),
                    SettingsTemplates(
                      name: 'Comments',
                      leadingWidget: Icon(Icons.comment, color: WhiteColor),
                    ),
                    SettingsTemplates(
                      name: 'Tags',
                      leadingWidget: Icon(Icons.tag, color: WhiteColor),
                    ),
                    SettingsTemplates(
                      name: 'Guides',
                      leadingWidget: Icon(Icons.assignment_rounded, color: WhiteColor),
                    ),
                    SettingsTemplates(
                      name: 'Activity status',
                      leadingWidget: Icon(Icons.person_add_alt_1, color: WhiteColor),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
