import 'package:facetap/pages/settings_page/local_widget/view_model/settings_templates_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';

class SettingsTemplates extends StatelessWidget {
  final String name;
  final Widget leadingWidget;
  final Widget trailingWidget;
  final Function onNavigationTap;

  const SettingsTemplates({Key key, this.name, this.onNavigationTap, this.leadingWidget, this.trailingWidget}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SettingsTemplatesViewModel>.reactive(
      viewModelBuilder: () => SettingsTemplatesViewModel(),
      builder: (context, model, _) {
        return GestureDetector(
          child: Container(
            color: Transparent,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          leadingWidget != null ? Padding(padding: const EdgeInsets.symmetric(horizontal: 8.0), child: leadingWidget) : Container(),
                          Text(name, style: Regular.copyWith(fontSize: 16.0, color: WhiteColor)),
                        ],
                      ),
                      Row(
                        children: [
                          trailingWidget != null
                              ? Padding(padding: const EdgeInsets.symmetric(horizontal: 8.0), child: trailingWidget)
                              : Icon(Icons.chevron_right, color: Color(0xff808185)),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          onTap: onNavigationTap,
        );
      },
    );
  }
}
