import 'dart:io';

import 'package:cached_video_player/cached_video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:facetap/global_widgets/views/comments_page.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/like_page/views/like_screen.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/base_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:http/http.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:pedantic/pedantic.dart';
import 'package:video_player/video_player.dart';

class ViewPostViewModel extends BaseViewModel {
  final PostsService _postsService = locator<PostsService>();
  final UserService _userService = locator<UserService>();
  final UserModel userModel = locator<UserModel>();
  bool isContentController = true;
  bool isOpenComments = false;
  int page = 1;
  int prevIndex = 0;
  PostModel post;
  VideoPlayerController controller;
  ChewieController chewieController;
  bool playbackVisible = false;
  CachedVideoPlayerController cachedController;
  VideoPlayerController _videoPlayerController;

  initController(VideoPlayerController _controller) {
    this.controller = _controller;
  }

  bool _isNeedUpdate = false;
  List<String> usersIHaveSubscribed = [];

 Future httpResponse(PostModel _post)async{
   print("response.statusCode1");
    Response  response = await get(Uri.parse(_post.medias.first.mediaUrl));
   print("response.statusCode ${response.statusCode}");
   if(response.statusCode==200){
     getInit(post.medias.first.mediaUrl);
   }else{
     httpResponse(_post);
   }
  }
 Future checkStatus(PostModel _post)async{
   Response  response = await get(Uri.parse(_post.medias.first.mediaUrl));
   if(response.statusCode==200){
     print("response.statusCode ${response.statusCode}");
   }else{
httpResponse(_post);
   }
  }
  goVideo(PostModel post)async{
    if (post.medias.first.contentType.contains('video')) {
 checkStatus(post);
          getInit(post.medias.first.mediaUrl);
    }
  }
  initData(PostModel post) {
   goVideo(post);
    this.post = post;
    fetchViewed();
    notifyListeners();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.resumed:
        if (Platform.isAndroid) {
          chewieController?.pause();
        } else {
          cachedController?.pause();
        }
        break;
      case AppLifecycleState.paused:
        if (Platform.isAndroid) {
          chewieController?.pause();
        } else {
          cachedController?.pause();
        }
        break;
      case AppLifecycleState.inactive:
        break;
      default:
        break;
    }
  }

  getInit(String url) async {
    if (Platform.isAndroid) {
      final fileInfo = await DefaultCacheManager().getFileFromCache(url);
      if (fileInfo == null || fileInfo.file == null) {
        unawaited(DefaultCacheManager().downloadFile(url));
        controller = VideoPlayerController.network(url)..initialize().then((value) {
          chewieController = ChewieController(
            showControls: false,
            looping: true,
            autoPlay: true,
            aspectRatio: controller.value.aspectRatio,
            videoPlayerController: controller,
            autoInitialize: false,
            deviceOrientationsAfterFullScreen: [DeviceOrientation.portraitUp],
            materialProgressColors: ChewieProgressColors(
              playedColor: Colors.purple,
              handleColor: Colors.transparent,
              backgroundColor: Colors.transparent,
              bufferedColor: Colors.transparent,
            ),
            placeholder: Container(
              color: Colors.transparent,
            ),
          );
          notifyListeners();
        });
      } else {
         _videoPlayerController = VideoPlayerController.file(fileInfo.file)..initialize().then((value) {
          chewieController = ChewieController(
            showControls: false,
            looping: true,
            autoPlay: true,
            aspectRatio: _videoPlayerController.value.aspectRatio,
            videoPlayerController: _videoPlayerController,
            autoInitialize: false,
            deviceOrientationsAfterFullScreen: [DeviceOrientation.portraitUp],
            materialProgressColors: ChewieProgressColors(
              playedColor: Colors.purple,
              handleColor: Colors.transparent,
              backgroundColor: Colors.transparent,
              bufferedColor: Colors.transparent,
            ),
            placeholder: Container(
              color: Colors.transparent,
            ),
          );
          notifyListeners();
        });
      }
    } else {
      cachedController = CachedVideoPlayerController.network(url);
      cachedController.setLooping(true);
      cachedController.initialize().then((_) {
        cachedController.play();
        notifyListeners();
      });
    }
  }

  toggleVideoControllerPlayback() {
    if (Platform.isAndroid) {
      if (chewieController?.isPlaying == true) {
        playbackVisible = true;
        chewieController?.pause();
      } else {
        playbackVisible = false;
        chewieController?.play();
      }
    } else {
      if (cachedController?.value?.isPlaying == true) {
        playbackVisible = true;
        cachedController?.pause();
      } else {
        playbackVisible = false;
        cachedController?.play();
      }
    }
    notifyListeners();
  }

  onBackPressed() => navigationService.pop(_isNeedUpdate);

  onIsContentControllerUpdate(value) {
    isContentController = value;
    notifyListeners();
  }

  onCommentsPressed(PostModel post) {
    showMaterialModalBottomSheet(
      backgroundColor: PrimaryDarkColor.withOpacity(0.5),
      context: navigationService.currentContext,
      builder: (_) => CommentsPage(post: post),
    );
  }

  onSubscribePressed() {
    _isNeedUpdate = true;
    post.user.amIFollowing == 'true' ? unfollowUser(post.user.id) : followUser(post.user.id);
    post.user.amIFollowing = post.user.amIFollowing == 'true' ? 'false' : 'true';
    notifyListeners();
  }

  unfollowUser(String id) async {
    if (usersIHaveSubscribed.isNotEmpty) usersIHaveSubscribed.remove(id);
    Map<String, dynamic> data = serializer.prepareDataToFollow(id: id);
    bool _response = await _userService.unfollow(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print('unfollow $id');
    notifyListeners();
  }

  followUser(String id) async {
    usersIHaveSubscribed.add(id);
    Map<String, dynamic> data = serializer.prepareDataToFollow(id: id);
    bool _response = await _userService.follow(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print('follow $id');
    notifyListeners();
  }

  fetchViewed() async {
    Map<String, dynamic> data = serializer.prepareDataToView(objectType: 'post', objectId: post.id, userId: post.user.id);
    bool _response = await _postsService.viewed('post', post.id, post.user.id, data).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      print('post viewed');
    }
  }

  Future<bool> willPopCallback() async {
    navigationService.pop(_isNeedUpdate);
    return false;
  }

  onLikesPressed() {
    showMaterialModalBottomSheet(
      backgroundColor: PrimaryDarkColor.withOpacity(0.5),
      context: navigationService.currentContext,
      builder: (_) => LikeScreen(profile: userModel, post: post),
    );
  }

  updateNeeded() async {
    _isNeedUpdate = true;
    PostModel _response = await _postsService.getPost(postId: post.id).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      post = _response;
      notifyListeners();
    }
  }

  @override
  void onDispose() {
    if (Platform.isAndroid) {
      chewieController?.pause();
      chewieController?.dispose();
    } else {
      cachedController?.pause();
      cachedController?.dispose();
    }
    // TODO: implement onDispose
    super.onDispose();
  }
}
