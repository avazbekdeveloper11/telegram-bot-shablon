import 'dart:async';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cached_video_player/cached_video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:facetap/global_widgets/views/comments_page.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/models/user_model.dart';
import 'package:facetap/pages/content_page/local_widget/views/facetap_swap_card.dart';
import 'package:facetap/pages/like_page/views/like_screen.dart';
import 'package:facetap/pages/login_page/views/login_page.dart';
import 'package:facetap/pages/wallet_page/views/wallet_page.dart';
import 'package:facetap/providers/base_class_provider.dart';
import 'package:facetap/services/posts_service.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/base_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:pedantic/pedantic.dart';
import 'package:video_player/video_player.dart';

class ContentViewModel extends BaseViewModel {
  final PostsService _postsService = locator<PostsService>();
  final UserService _userService = locator<UserService>();
  final UserModel userModel = locator<UserModel>();
  bool isContentController = true;
  bool isOpenComments = false;
  CardController cardController; // Use this to trigger swap.
  double width;
  int page = 1;
  double likeOpacity = 0;
  double dislikeOpacity = 0;
  ChewieController chewieController;
  List<String> usersIHaveSubscribed = [];
  VideoPlayerController controller;
  VideoPlayerController _videoPlayerController;
  bool playbackVisible = false;
  StreamController streamController;
  CachedVideoPlayerController cachedController;

  @override
  void initState() {
    width = screenWidth(navigationService.currentContext);
    cardController = CardController();
    streamController = new StreamController<List<PostModel>>();
    loadUser();
    super.initState();
  }

  loadUser() async {
    fetchPosts(page).then((value) async {
      streamController.add(value);
      return value;
    });
  }

  @override
  void onDispose() {
    streamController.close();
    if (Platform.isAndroid) {
      chewieController?.pause();
      chewieController?.dispose();
    } else {
      cachedController?.pause();
      cachedController?.dispose();
    }
    super.onDispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.resumed:
        if (Platform.isAndroid) {
          chewieController?.pause();
        } else {
          cachedController?.pause();
        }
        break;
      case AppLifecycleState.paused:
        if (Platform.isAndroid) {
          chewieController?.pause();
        } else {
          cachedController?.pause();
        }
        break;
      case AppLifecycleState.inactive:
        if (Platform.isAndroid) {
          chewieController?.pause();
        } else {
          cachedController?.pause();
        }
        break;
      case AppLifecycleState.detached:
        if (Platform.isAndroid) {
          chewieController?.pause();
        } else {
          cachedController?.pause();
        }
        break;
      default:
        break;
    }
  }

  List<PostModel> posts = [];

  Future<List<PostModel>> fetchPosts(int _page) async {
    posts = [];
    PostsModel _response =
        await _postsService.getPosts(location: userModel.locationName, page: _page, limit: 50).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      print(_response.results.length);
      print("posts.length1 ${posts.length}");
      posts.addAll(_response.results);
      print("posts.length ${posts.length}");
      page++;
      if (posts[0].medias.first.contentType.contains('video')) {
        getInit(posts[0].medias.first.mediaUrl);
      }
    }
    return posts;
  }

  getInit(String url) async {
    if (Platform.isAndroid) {
      final fileInfo = await DefaultCacheManager().getFileFromCache(url);
      if (fileInfo == null || fileInfo.file == null) {
        print('download');
        unawaited(DefaultCacheManager().downloadFile(url));
        controller = VideoPlayerController.network(url)..initialize().then((value) {
          chewieController = ChewieController(
            showControls: false,
            looping: true,
            autoPlay: true,
            aspectRatio: controller.value.aspectRatio,
            videoPlayerController: controller,
            autoInitialize: false,
            deviceOrientationsAfterFullScreen: [DeviceOrientation.portraitUp],
            materialProgressColors: ChewieProgressColors(
              playedColor: Colors.purple,
              handleColor: Colors.transparent,
              backgroundColor: Colors.transparent,
              bufferedColor: Colors.transparent,
            ),
            placeholder: Container(
              color: Colors.transparent,
            ),
          );
          // notifyListeners();
        });
      } else {
        print('cache');
         _videoPlayerController = VideoPlayerController.file(fileInfo.file)..initialize().then((value) {

          chewieController = ChewieController(
            showControls: false,
            looping: true,
            autoPlay: true,
            aspectRatio: _videoPlayerController.value.aspectRatio,
            videoPlayerController: _videoPlayerController,
            autoInitialize: false,
            deviceOrientationsAfterFullScreen: [DeviceOrientation.portraitUp],
            materialProgressColors: ChewieProgressColors(
              playedColor: Colors.purple,
              handleColor: Colors.transparent,
              backgroundColor: Colors.transparent,
              bufferedColor: Colors.transparent,
            ),
            placeholder: Container(
              color: Colors.transparent,
            ),
          );
          notifyListeners();
        });
      }
    } else {
      cachedController?.dispose();
      cachedController = CachedVideoPlayerController.network(url);
      cachedController.setLooping(true);
      cachedController.initialize().then((_) {
        cachedController.play();
        notifyListeners();
      });
    }
  }

  onNavigationPop() => navigationService.pop();

  onIsContentControllerUpdate(value) {
    isContentController = value;
    notifyListeners();
  }

  gotoLogin() {
    navigationService.push(MaterialPageRoute(builder: (_) => LoginPage()));
  }

  gotoWallet() {
    navigationService.push(MaterialPageRoute(builder: (_) => WalletPage()));
  }

  onCommentsPressed(PostModel post) {
    userModel.accessToken.isNotEmpty
        ? showMaterialModalBottomSheet(
            backgroundColor: PrimaryDarkColor.withOpacity(0.5),
            context: navigationService.currentContext,
            expand: true,
            builder: (_) => CommentsPage(post: post))
        : gotoLogin();
  }

  onLikesPressed(PostModel post) {
    userModel.accessToken.isNotEmpty
        ? showMaterialModalBottomSheet(
            backgroundColor: PrimaryDarkColor.withOpacity(0.9),
            context: navigationService.currentContext,
            builder: (_) => LikeScreen(profile: userModel, post: post))
        : gotoLogin();
  }

  onSwipeUpdateCallback(DragUpdateDetails details, Alignment align) {
    if (align.x == 0) {
      if (Platform.isIOS) cachedController?.play();
    } else {
      if (Platform.isIOS) cachedController?.pause();
    }
    notifyListeners();
    if (userModel.accessToken.isNotEmpty) {
      if (align.x > 1) {
        likeOpacity = details.globalPosition.dx;
        dislikeOpacity = 0;
      } else if (align.x < -1) {
        dislikeOpacity = screenWidth(navigationService.currentContext) - details.globalPosition.dx;
        likeOpacity = 0;
      } else {
        likeOpacity = 0;
        dislikeOpacity = 0;
      }
    } else {
      if (page <= 3) {
        if (align.x > 1) {
          likeOpacity = details.globalPosition.dx;
          dislikeOpacity = 0;
        } else if (align.x < -1) {
          print("dislike2");
          dislikeOpacity = screenWidth(navigationService.currentContext) - details.globalPosition.dx;
          likeOpacity = 0;
        } else {
          likeOpacity = 0;
          dislikeOpacity = 0;
        }
        notifyListeners();
      } else {
        gotoLogin();
      }
    }
  }

  onSwipeEndCallback(DragEndDetails details) {
    if (Platform.isIOS) cachedController?.play();
    dislikeOpacity = 0;
    likeOpacity = 0;
  }

  onSwipeCompleteCallback(CardSwipeOrientation orientation, int index, List<PostModel> posts) async {
    print("initIndex $index");
    playbackVisible = false;
    if (userModel.accessToken.isNotEmpty) {
      if (orientation == CardSwipeOrientation.LEFT || orientation == CardSwipeOrientation.RIGHT) {
        width = screenWidth(navigationService.currentContext);
        orientation == CardSwipeOrientation.LEFT ? await onPostDisliked(index, posts) : await onPostLiked(index, posts);
        setImagePath(CachedNetworkImageProvider(posts[index + 1].medias.first.thumbnailUrl), navigationService.currentContext);
      }
    } else {
      if (index <= 10) {
        if (orientation == CardSwipeOrientation.LEFT || orientation == CardSwipeOrientation.RIGHT) {
          width = screenWidth(navigationService.currentContext);
          orientation == CardSwipeOrientation.LEFT ? onPostDisliked(index, posts) : onPostLiked(index, posts);
          setImagePath(CachedNetworkImageProvider(posts[index + 1].medias.first.thumbnailUrl), navigationService.currentContext);
        }
      } else {
        gotoLogin();
      }
    }
    notifyListeners();
  }

  onStartCallback() {
    width = screenWidth(navigationService.currentContext) * 0.9;
    notifyListeners();
  }

  Future onPostLiked(int index, List<PostModel> posts) async {
    print("index $index");
    print("posts.length ${posts.length}");
    if (index + 1 >= posts.length) {
      print(1221122112);
      streamController = new StreamController<List<PostModel>>();
      streamController.sink.add(await fetchPosts(page));
    }
    if (index + 1 < posts.length && posts[index + 1].medias.first.contentType.contains('video')) {
      print("video12212 ${posts[index + 1].medias.first.mediaUrl}");
      getInit(posts[index + 1].medias.first.mediaUrl);
    } else {
      if (Platform.isAndroid) {
        chewieController?.pause();
      } else {
        cachedController?.dispose();
      }
      notifyListeners();
    }
    fetchViewed(posts[index].id);
    Map<String, dynamic> data = serializer.prepareDataToLike(id: posts[index].id, objectType: 'post', type: 'like', ownerId: posts[index].user.id);
    _postsService.like(data: data).onError((error, stackTrace) => onError(error));
  }

  Future onPostDisliked(int index, List<PostModel> posts) async {
    print("index $index");
    print("posts.length ${posts.length}");
    if (index + 1 >= posts.length) {
      print(1221122112);
      streamController = new StreamController<List<PostModel>>();
      streamController.sink.add(await fetchPosts(page));
    }
    if (index + 1 < posts.length && posts[index + 1].medias.first.contentType.contains('video')) {
      getInit(posts[index + 1].medias.first.mediaUrl);
    } else {
      if (Platform.isAndroid) {
        chewieController?.pause();
      } else {
        cachedController?.dispose();
      }
      notifyListeners();
    }
    fetchViewed(posts[index].id);
    Map<String, dynamic> data = serializer.prepareDataToLike(id: posts[index].id, objectType: 'post', type: 'dislike', ownerId: posts[index].user.id);
    _postsService.like(data: data).onError((error, stackTrace) => onError(error));
  }

  onSubscribePressed(PostModel post) {
    UserModel profile = post.user;
    profile.amIFollowing == 'true' ? unfollowUser(profile.id) : followUser(profile.id);
    profile.amIFollowing = profile.amIFollowing == 'true' ? 'false' : 'true';
    notifyListeners();
  }

  unfollowUser(String id) async {
    if (usersIHaveSubscribed.isNotEmpty) usersIHaveSubscribed.remove(id);
    Map<String, dynamic> data = serializer.prepareDataToFollow(id: id);
    bool _response = await _userService.unfollow(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print('unfollow $id');
    notifyListeners();
  }

  followUser(String id) async {
    usersIHaveSubscribed.add(id);
    Map<String, dynamic> data = serializer.prepareDataToFollow(id: id);
    bool _response = await _userService.follow(data: data).onError((error, stackTrace) => onError(error));
    if (_response != null) print('follow $id');
    notifyListeners();
  }

  fetchViewed(String objectId) async {
    Map<String, dynamic> data = serializer.prepareDataToView(objectType: 'post', objectId: objectId, userId: userModel.id);
    bool _response = await _postsService.viewed('post', objectId, userModel.id, data).onError((error, stackTrace) => onError(error));
    if (_response != null) print('post viewed');
  }

  toggleVideoControllerPlayback() {
    if (Platform.isAndroid) {
      if (chewieController?.isPlaying == true) {
        playbackVisible = true;
        chewieController?.pause();
      } else {
        playbackVisible = false;
        chewieController?.play();
      }
    } else {
      if (cachedController?.value?.isPlaying == true) {
        playbackVisible = true;
        cachedController?.pause();
      } else {
        playbackVisible = false;
        cachedController?.play();
      }
    }
    notifyListeners();
  }

  updateNeeded(PostModel post) async {
    PostModel _response = await _postsService.getPost(postId: post.id).onError((error, stackTrace) => onError(error));
    if (_response != null) {
      post = _response;
      notifyListeners();
    } else {
      width = screenWidth(navigationService.currentContext);
      setImagePath(CachedNetworkImageProvider(post.medias.first.thumbnailUrl), navigationService.currentContext);
      if (post.medias.first.contentType.contains('video')) {
        getInit(post.medias.first.mediaUrl);
      } else {
        if (Platform.isAndroid) {
          chewieController?.pause();
        } else {
          cachedController?.pause();
        }
        notifyListeners();
      }
    }
  }
}
