import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';


class VideoPlayerWidget extends StatelessWidget {
  final ChewieController controller;
  const VideoPlayerWidget({Key key, this.controller}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: controller!=null ? controller.videoPlayerController.value.isInitialized ?  AspectRatio(
        aspectRatio: controller.videoPlayerController.value.aspectRatio,
        child: Chewie(
          controller: controller,
        ),
      ) : Container(): Container(),
    );
  }
}

