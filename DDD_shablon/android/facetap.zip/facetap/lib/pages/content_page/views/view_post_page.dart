import 'dart:io';
import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cached_video_player/cached_video_player.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/content_loader.dart';
import 'package:facetap/global_widgets/views/content_controller.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/pages/content_page/local_widget/views/video_player_widget.dart';
import 'package:facetap/pages/content_page/view_model/view_post_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class ViewPostPage extends StatefulWidget {
  final PostModel post;
  final bool isNavigatorPop;

  ViewPostPage({Key key, this.post, this.isNavigatorPop = false}) : super(key: key);

  @override
  _ViewPostPageState createState() => _ViewPostPageState();
}

class _ViewPostPageState extends State<ViewPostPage> with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ViewPostViewModel>.reactive(
      initState: (model) => model.initData(widget.post),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => ViewPostViewModel(),
      builder: (context, model, _) {
        print("widget.post.medias.first.thumbnailUrl ${model.post.medias.first.thumbnailUrl}");
        return WillPopScope(
          onWillPop: model.willPopCallback,
          child: Scaffold(
            backgroundColor: DarkWindowColor,
            body: GestureDetector(
              onTap: model.toggleVideoControllerPlayback,
              onVerticalDragUpdate: (up) {
                if ((up.delta.dy + 10) < 0) model.onCommentsPressed(model.post);
              },
              onLongPressStart: (s) => model.onIsContentControllerUpdate(false),
              onLongPressEnd: (e) => model.onIsContentControllerUpdate(true),
              child: Stack(
                children: [
                  Container(
                    width: screenWidth(context),
                    height: screenHeight(context),
                    child: widget.post.medias.first.contentType.contains('video')
                        ? Column(
                            children: [
                              Expanded(
                                child: widget.post.medias.first.contentType.contains('video')
                                    ? BackdropFilter(
                                        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                                        child: Container(
                                          width: screenWidth(context),
                                          height: screenHeight(context),
                                          color: Colors.black,
                                          child: Center(
                                            child: Platform.isAndroid
                                                ? VideoPlayerWidget(controller: model.chewieController)
                                                : model.cachedController?.value != null && model.cachedController.value.initialized
                                                    ? AspectRatio(
                                                        child: CachedVideoPlayer(model.cachedController),
                                                        aspectRatio: model.cachedController.value.aspectRatio,
                                                      )
                                                    : Center(
                                                        child: CircularProgressIndicator(),
                                                      ),
                                          ),
                                        ))
                                    : BackdropFilter(
                                        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                                        child: Container(
                                            width: screenWidth(context),
                                            height: screenHeight(context),
                                            child: CachedNetworkImage(
                                              imageUrl: widget.post.medias.first.mediaUrl,
                                              placeholder: (context, url) => ContentLoader(),
                                            )),
                                      ),
                              ),
                            ],
                          )
                        : BackdropFilter(
                            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                            child: Container(
                                width: screenWidth(context),
                                height: screenHeight(context),
                                child: CachedNetworkImage(
                                  fit: BoxFit.fitHeight,
                                  imageUrl: widget.post.medias.first.mediaUrl,
                                  placeholder: (context, url) => ContentLoader(),
                                )),
                          ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Visibility(
                      visible: model.playbackVisible,
                      child: SvgPicture.asset(
                        Assets.svgPlay,
                        width: 60,
                        height: 60,
                        color: WhiteColor,
                      ),
                    ),
                  ),
                  model.isContentController
                      ? Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.center,
                              colors: [PrimaryColor.withOpacity(0.7), Transparent],
                              stops: [0.0, 0.2],
                            ),
                          ),
                        )
                      : Container(),
                  model.isContentController
                      ? ContentController(
                          onCommentsPressed: () => model.onCommentsPressed(widget.post),
                          isOpenCommentsIcon: true,
                          post: model.post,
                          onLikedPressed: model.onLikesPressed,
                          usersIHaveSubscribed: model.usersIHaveSubscribed,
                          onSubscribePressed: model.onSubscribePressed,
                          updateNeeded: model.updateNeeded,
                        )
                      : Container(),
                  widget.isNavigatorPop
                      ? Padding(
                          padding: const EdgeInsets.only(top: 32.0, left: 8.0),
                          child: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
                        )
                      : Container(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
