import 'dart:io';
import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cached_video_player/cached_video_player.dart';
import 'package:facetap/Pages/content_page/view_model/content_page_view_model.dart';
import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/content_loader.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/global_widgets/views/content_controller.dart';
import 'package:facetap/models/posts_model.dart';
import 'package:facetap/pages/content_page/local_widget/views/facetap_swap_card.dart';
import 'package:facetap/pages/content_page/local_widget/views/video_player_widget.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:visibility_detector/visibility_detector.dart';

class ContentPage extends StatefulWidget {
  @override
  _ContentPageState createState() => _ContentPageState();
}

class _ContentPageState extends State<ContentPage> with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ContentViewModel>.reactive(
      initState: (model) => model.initState(),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => ContentViewModel(),
      builder: (context, model, _) {
        return Scaffold(
          backgroundColor: PrimaryDarkColor,
          resizeToAvoidBottomInset: false,
          body: StreamBuilder<List<PostModel>>(
              stream: model.streamController.stream,
              builder: (context, snapshot) {
                print("update");
                if (snapshot.hasError)
                  return Text("hey there is some error");
                else if (snapshot.connectionState == ConnectionState.waiting) return Center(child: CircularProgressIndicator());
                return Stack(
                  children: [
                    FacetapSwapCard(
                      orientation: AmassOrientation.TOP,
                      totalNum: snapshot.data.length,
                      stackNum: 2,
                      swipeEdge: 3.0,
                      maxWidth: screenWidth(context),
                      maxHeight: screenHeight(context),
                      minWidth: model.width,
                      minHeight: screenHeight(context),
                      cardBuilder: (context, index) {
                        print(" index $index  ${snapshot.data.length}");
                        model.width = screenWidth(context);
                        return GestureDetector(
                          onTap: () {
                            if (snapshot.data[index].medias.first.contentType.contains('video')) model.toggleVideoControllerPlayback();
                          },
                          onDoubleTap: () => model.userModel.id != snapshot.data[index].user.id && snapshot.data[index].user.amIFollowing == 'false'
                              ? model.onSubscribePressed(snapshot.data[index])
                              : null,
                          onVerticalDragUpdate: (up) {
                            if ((up.delta.dy + 10) < 0) model.onCommentsPressed(snapshot.data[index]);
                          },
                          onLongPressStart: (s) => model.onIsContentControllerUpdate(false),
                          onLongPressEnd: (e) => model.onIsContentControllerUpdate(true),
                          child: Stack(
                            children: [
                              Container(color: PrimaryColor),
                              BackdropFilter(
                                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                                child: Container(
                                    width: screenWidth(context),
                                    height: screenHeight(context),
                                    child: CachedNetworkImage(
                                      imageUrl: snapshot.data[index].medias.first.thumbnailUrl,
                                      placeholder: (context, url) => ContentLoader(),
                                    )),
                              ),
                              Container(
                                width: screenWidth(context),
                                height: screenHeight(context),
                                color: DarkWindowColor,
                                child: snapshot.data[index].medias.first.contentType.contains('video')
                                    ? Container(
                                        width: screenWidth(context),
                                        height: screenHeight(context),
                                        color: Colors.black,
                                        child: Column(
                                          children: [
                                            Expanded(
                                              child: Container(
                                                width: screenWidth(context),
                                                height: screenHeight(context),
                                                color: Colors.black,
                                                child: Center(
                                                  child: Platform.isAndroid
                                                      ? VideoPlayerWidget(controller: model.chewieController)
                                                      : VisibilityDetector(
                                                          key: Key('content_ios'),
                                                          child: model.cachedController?.value != null && model.cachedController.value.initialized
                                                              ? AspectRatio(
                                                                  child: CachedVideoPlayer(model.cachedController),
                                                                  aspectRatio: model.cachedController.value.aspectRatio,
                                                                )
                                                              : Center(child: CircularProgressIndicator()),
                                                          onVisibilityChanged: (VisibilityInfo info) {
                                                            info.visibleFraction == 0
                                                                ? model.cachedController?.pause()
                                                                : model.cachedController?.play();
                                                          }),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                    : CachedNetworkImage(
                                        fit: BoxFit.cover,
                                        imageUrl: snapshot.data[index].medias.first.mediaUrl,
                                        placeholder: (context, url) => ContentLoader(),
                                      ),
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: Visibility(
                                  visible: model.playbackVisible,
                                  child: SvgPicture.asset(
                                    Assets.svgPlay,
                                    width: 60,
                                    height: 60,
                                    color: WhiteColor,
                                  ),
                                ),
                              ),
                              model.isContentController
                                  ? Container(
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.topCenter,
                                          end: Alignment.center,
                                          colors: [PrimaryColor.withOpacity(0.7), Transparent],
                                          stops: [0.0, 0.2],
                                        ),
                                      ),
                                    )
                                  : Container(),
                              model.isContentController
                                  ? ContentController(
                                      onCommentsPressed: () => model.onCommentsPressed(snapshot.data[index]),
                                      isOpenCommentsIcon: true,
                                      post: snapshot.data[index],
                                      onLikedPressed: () => model.onLikesPressed(snapshot.data[index]),
                                      usersIHaveSubscribed: model.usersIHaveSubscribed,
                                      onSubscribePressed: () => model.onSubscribePressed(snapshot.data[index]),
                                      updateNeeded: () => model.updateNeeded(snapshot.data[index]),
                                    )
                                  : Container(),
                            ],
                          ),
                        );
                      },
                      cardController: model.cardController,
                      swipeUpdateCallback: (DragUpdateDetails details, Alignment align) => model.onSwipeUpdateCallback(details, align),
                      swipeEndCallback: (DragEndDetails details) => model.onSwipeEndCallback(details),
                      swipeCompleteCallback: (CardSwipeOrientation orientation, int index) =>
                          model.onSwipeCompleteCallback(orientation, index, snapshot.data),
                      onStart: model.onStartCallback,
                    ),
                    Visibility(
                      visible: model.likeOpacity != 0,
                      child: Align(
                        alignment: Alignment.center,
                        child: Opacity(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [Image.asset(Assets.imageLikePost), Text('like', style: Medium.copyWith(fontSize: 34.0, color: WhiteColor))],
                          ),
                          opacity: model.likeOpacity / screenWidth(context),
                        ),
                      ),
                    ),
                    Visibility(
                      visible: model.dislikeOpacity != 0,
                      child: Align(
                        alignment: Alignment.center,
                        child: Opacity(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Image.asset(Assets.imageDislikePost),
                              Text('dislike', style: Medium.copyWith(fontSize: 34.0, color: WhiteColor))
                            ],
                          ),
                          opacity: model.dislikeOpacity / screenWidth(context),
                        ),
                      ),
                    ),
                    SafeArea(
                      child: model.userModel.accessToken.isNotEmpty
                          ? IconButton(icon: SvgPicture.asset(Assets.svgDiamond), onPressed: model.gotoWallet)
                          : Container(),
                    ),
                    model.isloading /*&& model.page == 1*/ ? Loading() : Container()
                  ],
                );
              }),
        );
      },
    );
  }
}
