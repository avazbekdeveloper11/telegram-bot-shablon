import 'package:facetap/models/interest_model.dart';
import 'package:facetap/pages/home_page/views/home_screen.dart';
import 'package:facetap/services/user_service.dart';
import 'package:facetap/state_manager/enums.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:flutter/material.dart';

class EditInterestsViewModel extends BaseViewModel {
  List<String> userSelectedHashtags = [];
  List<InterestModel> interestsList = [];
  final UserService _userService = locator<UserService>();

  fetchInterest() async {
    setState(LoadingState.loading);
    interestsList.clear();
    InterestListModel _response = await _userService.getInterestService().onError((error, stackTrace) => onError(error));
    if (_response != null) {
      interestsList.addAll(_response.interests);
      interestsList.sort((a, b) => a.hashtag.compareTo(b.hashtag));
      interestsList.forEach((element) {
        if (element.isChosenByUser) userSelectedHashtags.add(element.hashtag);
      });
      notifyListeners();
    }
    setState(LoadingState.idle);
  }

  @override
  initState() {
    fetchInterest();
    super.initState();
  }

  @override
  onDispose() {
    super.onDispose();
  }

  void onBackPressed() => navigationService.pop();

  onInterestSelected(String hashtag) {
    userSelectedHashtags.contains(hashtag) ? userSelectedHashtags.remove(hashtag) : userSelectedHashtags.add(hashtag);
    notifyListeners();
  }

  onContinueButton() async {
    setState(LoadingState.loading);
    Map<String, dynamic> data = serializer.prepareDataToInterests(interests: userSelectedHashtags);
    bool _response = await _userService.updateInterests(data: data).onError((error, stackTrace) => onError(error));
    setState(LoadingState.idle);
    if (_response != null) {
      navigationService.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => HomePage(defaultIndex: 4)));
    }
  }
}
