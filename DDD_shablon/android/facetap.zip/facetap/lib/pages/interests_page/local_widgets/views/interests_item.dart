import 'package:facetap/generated/assets.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class InterestsItem extends StatelessWidget {
  final String interest;
  final Function onInterestSelected;
  final bool isSelected;

  const InterestsItem({Key key, this.interest, this.onInterestSelected, this.isSelected}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onInterestSelected,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12.0),
        margin: EdgeInsets.symmetric(vertical: 1.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(child: Text(interest, style: Regular.copyWith(color: WhiteColor, fontSize: 16.0))),
            SvgPicture.asset(isSelected ? Assets.svgCheckboxOn : Assets.svgCheckboxOff),
          ],
        ),
      ),
    );
  }
}
