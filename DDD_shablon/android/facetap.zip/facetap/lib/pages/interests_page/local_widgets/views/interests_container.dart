import 'package:facetap/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class InterestsContainer extends StatelessWidget {
  final String name;
  final String posts;
  final double size;
  final Function changeBox;
  final bool change;

  const InterestsContainer({Key key, this.name, this.posts, this.size, this.changeBox, this.change}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        child: Container(
          margin: const EdgeInsets.all(4.0),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: WhiteColor.withOpacity(0.5)),
            color: change ? Transparent : WhiteColor,
          ),
          width: size,
          height: size,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              change ? Container() : Icon(Icons.check, color: BlackColor),
              Text(
                name,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: change ? WhiteColor : BlackColor,
                ),
              ),
              Text(
                posts,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  color: (change ? WhiteColor : BlackColor).withOpacity(0.5),
                ),
              ),
            ],
          ),
        ),
        onTap: changeBox);
  }
}
