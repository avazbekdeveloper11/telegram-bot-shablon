import 'package:facetap/generated/assets.dart';
import 'package:facetap/global_widgets/loading.dart';
import 'package:facetap/pages/interests_page/local_widgets/views/interests_item.dart';
import 'package:facetap/pages/interests_page/view_model/edit_interests_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

class EditInterestsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<EditInterestsViewModel>.reactive(
      initState: (model) => model.initState(),
      onDispose: (model) => model.onDispose(),
      viewModelBuilder: () => EditInterestsViewModel(),
      builder: (context, model, _) {
        return Stack(
          children: [
            Scaffold(
              backgroundColor: DarkWindowColor,
              appBar: AppBar(
                leading: IconButton(icon: SvgPicture.asset(Assets.svgArrowBack), onPressed: model.onBackPressed),
                backgroundColor: Transparent,
                elevation: 0,
                actions: [
                  IconButton(icon: Text('Save', style: Regular.copyWith(color: WhiteColor)), onPressed: model.onContinueButton),
                ],
                centerTitle: true,
                title: Text('Interests', style: Regular),
              ),
              body: NoScrollGlow(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Select on the topics you’re interested in to customize your experience.',
                        style: Medium.copyWith(color: WhiteColor.withOpacity(0.5), fontSize: 15),
                      ),
                      for (int index = 0; index < model.interestsList.length; index++)
                        InterestsItem(
                          interest: model.interestsList[index].hashtag,
                          onInterestSelected: () => model.onInterestSelected(model.interestsList[index].hashtag),
                          isSelected: model.userSelectedHashtags.contains(model.interestsList[index].hashtag),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            model.isloading ? Loading() : Container()
          ],
        );
      },
    );
  }
}
