import 'package:facetap/global_widgets/base_class.dart';
import 'package:facetap/global_widgets/scrollable_footer_layout.dart';
import 'package:facetap/global_widgets/views/subscribe_button.dart';
import 'package:facetap/pages/interests_page/view_model/interests_page_view_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:facetap/utils/colors.dart';
import 'package:facetap/utils/fonts.dart';
import 'package:facetap/utils/formatter.dart';
import 'package:facetap/utils/screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:no_scroll_glow/no_scroll_glow.dart';

import '../local_widgets/views/interests_container.dart';

class InterestsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<InterestsViewModel>.reactive(
      initState: (model) => model.initState(),
      viewModelBuilder: () => InterestsViewModel(),
      builder: (context, model, _) {
        model.interestsList.sort((a, b) => b.postsNumber.compareTo(a.postsNumber));

        return BaseClass(
          child: Scaffold(
            backgroundColor: PrimaryDarkColor.withOpacity(0.9),
            body: SafeArea(
              child: NoScrollGlow(
                child: ScrollableFooterLayout(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                            padding: const EdgeInsets.only(left: 16.0),
                            child: Text('Choose your interests', style: TextStyle(color: WhiteColor, fontSize: 32))),
                        Padding(
                          padding: const EdgeInsets.only(left: 16.0, right: 16.0, top: 16.0, bottom: 32.0),
                          child: Text(
                            'Tap on the topics you’re interested in to customize your experience',
                            style: Medium.copyWith(color: WhiteColor.withOpacity(0.5), fontSize: 14),
                          ),
                        ),
                      ],
                    ),
                    NoScrollGlow(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Container(
                          height: screenHeight(context) / 1.4,
                          width: screenWidth(context) * 2.4,
                          child: SingleChildScrollView(
                            scrollDirection: Axis.vertical,
                            child: Wrap(
                              alignment: WrapAlignment.center,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              spacing: 16.0,
                              children: model.interestsList
                                  .map((item) {
                                    return InterestsContainer(
                                        size: 117 +
                                            64 *
                                                item.postsNumber /
                                                (model.interestsList[0].postsNumber == 0 ? 1.0 : model.interestsList[0].postsNumber),
                                        name: item.hashtag,
                                        posts: '${formatAmount(item.postsNumber)} posts',
                                        changeBox: () => model.changeBox(item.hashtag),
                                        change: !model.userSelectedHashtags.contains(item.hashtag));
                                  })
                                  .toList()
                                  .cast<Widget>(),
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                  footer: Padding(
                    padding: EdgeInsets.only(left: 16.0, right: 16.0, bottom: 24.0),
                    child: SubscribeButton(
                      onTap: model.onContinueButton,
                      isBorderColored: true,
                      buttonColor: WhiteColor,
                      text: 'Continue',
                      isColorText: false,
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
