import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

/*
class BaseClassProvider {
  String imagePath = "assets/images/image1.png";
  ImageProvider imageProvider = AssetImage("assets/images/image1.png");

  void setImagePath(ImageProvider imageProvider) {
    this.imageProvider = imageProvider;
  }
}

*/

class BaseClassProvider with ChangeNotifier {
  ImageProvider imageProvider = AssetImage("assets/images/image1.png");
  String imageUrl = "";

  void setImagePath(ImageProvider imageProvider) {
    this.imageProvider = imageProvider;
    notifyListeners();
  }

  void setProfileImageUrl(String url) {
    this.imageUrl = url;
    notifyListeners();
  }
}

setImagePath(ImageProvider imageProvider, context) => Provider.of<BaseClassProvider>(context, listen: false).setImagePath(imageProvider);

ImageProvider getImagePath(context) => Provider.of<BaseClassProvider>(context, listen: true).imageProvider;

setProfileImageUrl(String url, context) => Provider.of<BaseClassProvider>(context, listen: false).setProfileImageUrl(url);

String getProfileImageUrl(context) => Provider.of<BaseClassProvider>(context, listen: true).imageUrl;
