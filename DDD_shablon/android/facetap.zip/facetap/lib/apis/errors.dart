class ApiClientErrors {
  /// this error occurs when user is not has profile.
  static const String EMAIL_NOT_EXISTS = 'EMAIL_NOT_EXISTS';

  /// this error occurs when user wants to register.
  static const String EMAIL_EXISTS = 'EMAIL_EXISTS';

  /// this error occurs when user enters wrong password or email.
  static const String UNAUTHORIZED = 'UNAUTHORIZED';

  /// this error occurs when user email is not found.
  static const String NOT_FOUND = 'NOT_FOUND';

  /// this error occurs when there is server error [500].
  static const String SERVER_ERROR = 'SERVER_ERROR';

  /// this error occurs when there is unknown error.
  /// debug to solve it.
  static const String UNKNOWN_ERROR = 'UNKNOWN_ERROR';

  /// this error occurs when there is no.... TODO: complete.
  static const String NO_SUCCESS_BODY_FOUND = 'NO_SUCCESS_BODY_FOUND';

  static const String BAD_REQUEST = 'BAD_REQUEST';
}
