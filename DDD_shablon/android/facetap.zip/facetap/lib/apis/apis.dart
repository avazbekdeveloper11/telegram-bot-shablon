import 'dart:convert';
import 'dart:io';

import 'package:facetap/models/user_model.dart';
import 'package:facetap/state_manager/manager.dart';
import 'package:http/http.dart' as http;

class ApiClient {
  static const String HOST = 'https://facetap.test.uzpos.uz/v1';
  UserModel _userModel = locator<UserModel>();

// ===================== Authentication service =====================

  Future<http.Response> register(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/register/');
    print('''\n=====
        request: $uri
        body:$data
        =====\n''');
    return await http.post(uri, body: jsonEncode(data));
  }

  Future<http.Response> verifyByLink(Uri uri) async {
    print('''\n=====
        request: $uri
        =====\n''');
    return await http.get(uri);
  }

  Future<http.Response> getTokens(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/get_tokens/');
    print('''\n=====
        request: $uri
        body: $data
        =====\n''');
    return await http.post(uri, body: jsonEncode(data));
  }

  Future<http.Response> login(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/login/');
    print('''\n=====
        request: $uri
        body: $data
        =====\n''');
    return await http.post(uri, body: jsonEncode(data));
  }

  Future<http.Response> logout() async {
    var uri = Uri.parse('$HOST/logout/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.put(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> sendVerification(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/send-verification/');
    print('''\n=====
        request: $uri
        body: $data
        =====\n''');
    return await http.post(uri, body: jsonEncode(data));
  }

  Future<http.Response> setPassword(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/set-password/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

// ==================================================================

// ========================== User service ==========================

  Future<http.Response> getProfile(String userId) async {
    var uri = Uri.parse('$HOST/users/$userId/profile/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getProfileByLink(Uri uri) async {
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> elasticSearch({String type, String search, int limit, int page}) async {
    var uri = Uri.parse('$HOST/search/?type=$type&search=$search&limit=$limit&page=$page');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> userSearchGet({int limit, int page}) async {
    var uri = Uri.parse('$HOST/user-searches/?limit=$limit&page=$page');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> searchSuggest({String search}) async {
    var uri = Uri.parse('$HOST/user-search-word/suggest/?initials=$search');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getHashTagPost(int limit, String type, int page) async {
    var uri = Uri.parse('$HOST/user/rating-page-posts-by-hashtags/?limit=$limit&page=$page&type=$type');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> updateProfile(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/user/update/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.put(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> updateEmail(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/user/update-email/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.put(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> userFollowers(String userId, int page, int limit, String search) async {
    var uri = Uri.parse('$HOST/users/$userId/followers?page=$page&limit=$limit&search=$search');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> userFollowing(String userId, int page, int limit, String search) async {
    var uri = Uri.parse('$HOST/users/$userId/following?page=$page&limit=$limit&search=$search');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> follow(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/user/follow/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> unfollow(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/user/unfollow/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.delete(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> removeFollower(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/user/remove-follower/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.delete(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> block(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/user/block/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> unblock(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/user/unblock/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.delete(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getBlockedUsers(int page, int limit, String search) async {
    var uri = Uri.parse('$HOST/blocked-users?page=$page&limit=$limit&search=$search');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getUserPosts(String userId, int page, int limit) async {
    var uri = Uri.parse('$HOST/users/$userId/posts?page=$page&limit=$limit');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> locationPosts(String locationName, int page, int limit, bool isLocation) async {
    var uri = isLocation
        ? Uri.parse('$HOST/posts-by-location/$locationName/?limit=$limit&page=$page')
        : Uri.parse('$HOST/post/$locationName/get-posts-by-hashtag/?limit=$limit&page=$page');

    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getNotifications(int page, int limit) async {
    var uri = Uri.parse('$HOST/user/notifications?page=$page&limit=$limit');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

// ==================================================================

// ========================= Upload service =========================

  Future<http.Response> generateUploadUrl(String json) async {
    var uri = Uri.parse('$HOST/media/generate-upload-url/');
    print('''\n=====
        request: $uri
        body: $json
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: json, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> uploadToServer(String url, String contentType, String metaType, dynamic data) async {
    var uri = Uri.parse(url);
    return await http.put(uri, body: data, headers: {HttpHeaders.contentTypeHeader: contentType, 'x-amz-meta-object-type': metaType});
  }

  Future<http.Response> uploadFile(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/media/upload-file/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

// ==================================================================

// ========================== Post service ==========================

  Future<http.Response> getPosts(String location, int page, int limit) async {
    var uri = Uri.parse('$HOST/posts?location=$location&page=$page&limit=$limit');
    // print('''\n=====
    //     request: $uri
    //     headers: {
    //       ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
    //     }
    //     =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> createPost(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/posts/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> userSearchPost(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/user-searches/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getPost(String postId) async {
    var uri = Uri.parse('$HOST/posts/$postId');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> createUserChat(String receiverId) async {
    var uri = Uri.parse('$HOST/chat/get_or_create_room/?receiver_id=$receiverId');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getPostByLink(Uri uri) async {
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> deletePost(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/posts/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.delete(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getHashtags(String search) async {
    var uri = Uri.parse('$HOST/user/get-hashtags?initials=$search');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

// ============================== Like ==============================

  Future<http.Response> like(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/like/');
    // print('''\n=====
    //     request: $uri
    //     body: $data
    //     headers: {
    //       ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
    //     }
    //     =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getUsersLiked(String type, String userId, String objectType, String objectId, int page, int limit) async {
    var uri = Uri.parse('$HOST/like/users/$userId/$objectId/$objectType/$type?page=$page&limit=$limit');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
          $objectId
          
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getTopUser(int page, int limit) async {
    var uri = Uri.parse('$HOST/top-100-users/?limit=$limit&page=$page');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}   
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getLikeCount(String objectType, String objectId) async {
    var uri = Uri.parse('$HOST/like_count/$objectType/$objectId/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  // Future<http.Response> dislike(Map<String, dynamic> data) async {
  //   var uri = Uri.parse('$HOST/unlike/');
  //   print('''\n=====
  //       request: $uri
  //       body: $data
  //       headers: {
  //         ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
  //       }
  //       =====\n''');
  //   return await http
  //       .delete(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  // }

// ============================== Comments ==============================

  Future<http.Response> createComment(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/comments/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> deleteComment(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/comments/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.delete(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getComments(String objectType, String objectId, int page, int limit) async {
    print(objectId);
    var uri = Uri.parse('$HOST/comments/$objectType/$objectId?page=$page&limit=$limit');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

// ==================================================================

// ============================== View ==============================

  Future<http.Response> viewed(String objectType, String objectId, String userId, Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/view/$objectType/$objectId/$userId/');
    // print('''\n=====
    //     request: $uri
    //     body: $data
    //     headers: {
    //       ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
    //     }
    //     =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getViewsCount(String objectType, String objectId) async {
    var uri = Uri.parse('$HOST/views_count/$objectType/$objectId/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

// ==================================================================

// ======================= Google Places API ========================

  final String mapKey = 'AIzaSyDnsbXf2EUbLCzx4rWf39EKSXLTIBadeIQ';
  final int radius = 10000;

  Future<http.Response> getNearbyPlaces(double lat, double long, String pageToken, String search) async {
    var uri = Uri.parse(
        'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=$lat,$long&radius=$radius&pagetoken=$pageToken&key=$mapKey&keyword=$search');
    print('''\n=====
        request: $uri
        =====\n''');
    return await http.get(uri);
  }

  Future<http.Response> getPlacesByQuery(String search, String pageToken) async {
    var uri = Uri.parse('https://maps.googleapis.com/maps/api/place/textsearch/json?key=$mapKey&query=$search&pagetoken=$pageToken');
    print('''\n=====
        request: $uri
        =====\n''');
    return await http.get(uri);
  }

// ==================================================================

// =========================== Interests ============================

  Future<http.Response> getInterestGet() async {
    var uri = Uri.parse('$HOST/user/choose-interests/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> updateInterests(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/user/choose-interests/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

// ==================================================================

// ============================= Gifts ==============================

  Future<http.Response> getAllGifts(int limitNumberOfCategories, int limitInEachCategory) async {
    var uri = Uri.parse('$HOST/gift_temps/?LimitNumberOfCategories=$limitNumberOfCategories&LimitInEachCategory=$limitInEachCategory/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getUserGifts(String userId, int page, int limit) async {
    var uri = Uri.parse('$HOST/users/$userId/gifts?page=$page&limit=$limit');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> buyGift(String giftTempId) async {
    var uri = Uri.parse('$HOST/gift/buy/$giftTempId/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getGift(String giftId) async {
    var uri = Uri.parse('$HOST/gifts/$giftId/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> sendGift(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/gift/send/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

// ==================================================================

// ============================= Share ==============================

  Future<http.Response> getProfileLink(String userId) async {
    var uri = Uri.parse('$HOST/users/$userId/profile/share/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getPostLink(String postId) async {
    var uri = Uri.parse('$HOST/posts/$postId/share/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

// ==================================================================

// ============================= Share ==============================

  Future<http.Response> getSavedPosts(int page, int limit) async {
    var uri = Uri.parse('$HOST/saved-posts?page=$page&limit=$limit');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getChatRooms(int page, int limit) async {
    var uri = Uri.parse('$HOST/chat/get-user-rooms/?page=$page&limit=$limit');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> hasUnreadMessageApi() async {
    var uri = Uri.parse('$HOST/chat/check-unread/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> savePost(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/saved-posts/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> removeSavedPost(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/saved-posts/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.delete(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

// ==================================================================

// ============================= Report =============================

  Future<http.Response> reportUserTypes(int page, int limit) async {
    var uri = Uri.parse('$HOST/user-report-types?page=$page&limit=$limit');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> reportUser(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/user/reports/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> reportPostTypes(int page, int limit) async {
    var uri = Uri.parse('$HOST/post-report-types?page=$page&limit=$limit');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> reportPost(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/post/reports/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

// ==================================================================

  Future<http.Response> getVoteCards(int page, int limit) async {
    var uri = Uri.parse('$HOST/user/vote-cards?page=$page&limit=$limit');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> createPayment(Map<String, dynamic> data) async {
    var uri = Uri.parse('$HOST/user/payments/');
    print('''\n=====
        request: $uri
        body: $data
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.post(uri, body: jsonEncode(data), headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }

  Future<http.Response> getUserVotes() async {
    var uri = Uri.parse('$HOST/user/votes/');
    print('''\n=====
        request: $uri
        headers: {
          ${HttpHeaders.authorizationHeader}: ${_userModel.accessToken}
        }
        =====\n''');
    return await http.get(uri, headers: {HttpHeaders.authorizationHeader: _userModel.accessToken});
  }
}
