import 'package:facetap/models/posts_model.dart';

class RatingsListPostsModel {

  List<Map<String, dynamic>> results;
int count;
  RatingsListPostsModel({ this.results, this.count});

  factory RatingsListPostsModel.fromJson(Map<String, dynamic> data) {
    print(data['hashtags'].length);
    List< Map<String, dynamic>> postModelList = [];
    List hashtagsList = data['hashtags'];
    for (var hashtags in hashtagsList) {
      if(hashtags['posts'] !=null) {
        postModelList.add({"posts": RatingPostsModel
            .fromJson(hashtags['posts'])
            .results,
          "post_count" : hashtags['post_count'],
          "user_rating" : hashtags['user_rating'],
          "slug" : hashtags['slug'],
        }
        );
      }
    }
    return RatingsListPostsModel( results: postModelList, count: data['count']);
  }

}

class RatingPostsModel {

  List<PostModel> results;

  RatingPostsModel({ this.results});

  factory RatingPostsModel.fromJson(List data) {
    List<PostModel> results = [];
    for (var item in data) {
      results.add(PostModel.fromJson(item));
    }
    return RatingPostsModel( results: results);
  }

}

