class LoginModel {
  String accessToken;
  String email;
  String firstName;
  String id;
  String lastName;
  String profilePhoto;
  String refreshToken;
  String username;

  LoginModel({
    this.accessToken,
    this.email,
    this.firstName,
    this.id,
    this.lastName,
    this.profilePhoto,
    this.refreshToken,
    this.username,
  });

  //getters.
  bool get hasData =>
      (this.email != null && this.email.isNotEmpty) &&
      (this.firstName != null && this.firstName.isNotEmpty) &&
      (this.id != null && this.id.isNotEmpty) &&
      (this.lastName != null && this.lastName.isNotEmpty) &&
      (this.profilePhoto != null && this.profilePhoto.isNotEmpty) &&
      (this.username != null && this.username.isNotEmpty);

  String get hasToken => this.accessToken;

  String get hasRefreshToken => this.refreshToken;

  //setters.
  set setToken(String token) => this.accessToken = token;

  set setRefreshToken(String token) => this.refreshToken = token;

  factory LoginModel.fromJson(Map<String, dynamic> data) {
    return LoginModel(
        accessToken: data['access_token'],
        refreshToken: data['refresh_token'],
        email: data['email'],
        firstName: data['first_name'],
        id: data['id'],
        lastName: data['last_name'],
        profilePhoto: data['profile_photo'],
        username: data['username']);
  }
}
