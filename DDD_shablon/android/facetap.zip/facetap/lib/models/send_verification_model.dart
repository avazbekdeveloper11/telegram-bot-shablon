class SendVerificationModel {
  String id;

  SendVerificationModel({this.id});

  factory SendVerificationModel.fromJson(String data) {
    return SendVerificationModel(id: data);
  }
}
