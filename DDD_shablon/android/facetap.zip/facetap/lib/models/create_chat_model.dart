
class CreateChatModel {
  CreateChatModel({
    this.roomId,
    this.newCreated,
  });

  String roomId;
  bool newCreated;

  factory CreateChatModel.fromJson(Map<String, dynamic> json) => CreateChatModel(
    roomId: json["room_id"],
    newCreated: json["new_created"],
  );

  Map<String, dynamic> toJson() => {
    "room_id": roomId,
    "new_created": newCreated,
  };
}