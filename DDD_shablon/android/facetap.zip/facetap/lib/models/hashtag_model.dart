class HashtagModel {
  String name;
  String slug;

  HashtagModel({this.name, this.slug});

  factory HashtagModel.fromJson(Map<String, dynamic> data) {
    return HashtagModel(name: data['name'], slug: data['slug']);
  }

  Map<String, dynamic> toJson() => {'name': name, 'slug': slug};

  @override
  String toString() {
    return '''{
        name: $slug
      }''';
  }
}

class HashtagSuggestModel {
  int count;
  List<HashtagModel> hashtags;

  HashtagSuggestModel({this.count, this.hashtags});

  factory HashtagSuggestModel.fromJson(Map<String, dynamic> data) {
    List<HashtagModel> results = [];
    for (var item in data['hashtags']) {
      results.add(HashtagModel.fromJson(item));
    }
    return HashtagSuggestModel(count: data['count'], hashtags: results);
  }
}
