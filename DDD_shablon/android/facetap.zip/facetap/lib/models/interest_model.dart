class InterestListModel {
  List<InterestModel> interests;

  InterestListModel({this.interests});

  factory InterestListModel.fromJson(Map<String, dynamic> data) {
    List<InterestModel> hashtags = [];
    for (var item in data['hashtags']) hashtags.add(InterestModel.fromJson(item));
    return InterestListModel(interests: hashtags);
  }
}

class InterestModel {
  String hashtag;
  int postsNumber;
  bool isChosenByUser;

  InterestModel({this.hashtag, this.postsNumber, this.isChosenByUser});

  factory InterestModel.fromJson(Map<String, dynamic> data) {
    return InterestModel(
      hashtag: data['hashtag'],
      postsNumber: data['posts_number'],
      isChosenByUser: data['is_choosen_by_user'],
    );
  }
}
