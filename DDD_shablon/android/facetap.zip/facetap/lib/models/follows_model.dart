import 'package:facetap/models/user_model.dart';

class FollowersModel {
  int count;
  List<UserModel> results;

  FollowersModel({this.count, this.results});

  factory FollowersModel.fromJson(Map<String, dynamic> data) {
    List<UserModel> followers = [];
    for (var item in data['followers']) followers.add(UserModel.fromFollowJson(item));
    print(followers);
    return FollowersModel(count: data['count'], results: followers);
  }
}

class FollowingModel {
  int count;
  List<UserModel> results;

  FollowingModel({this.count, this.results});

  factory FollowingModel.fromJson(Map<String, dynamic> data) {
    List<UserModel> followings = [];
    for (var item in data['followings']) followings.add(UserModel.fromFollowJson(item));
    return FollowingModel(count: data['count'], results: followings);
  }
}
