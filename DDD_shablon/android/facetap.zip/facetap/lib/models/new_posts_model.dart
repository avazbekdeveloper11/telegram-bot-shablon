import 'package:facetap/models/hashtag_model.dart';
import 'package:facetap/models/location_model.dart';
import 'package:facetap/models/medias_model.dart';

class NewPostsModel {
  NewPostModel result;

  NewPostsModel({this.result});

  factory NewPostsModel.fromJson(Map<String, dynamic> data) {
    return NewPostsModel(result: data["result"]);
  }
}

class NewPostModel {
  String caption;
  List<HashtagModel> hashtags;
  LocationModel location;
  List<NewPostMediaModel> medias;

  NewPostModel({this.caption, this.hashtags, this.location, this.medias});

  factory NewPostModel.fromJson(Map<String, dynamic> data) {
    List<HashtagModel> _hashtags = [];
    List<NewPostMediaModel> _medias = [];
    for (var item in data["hashtags"]) _hashtags.add(HashtagModel.fromJson(item));
    for (var item in data["medias"]) _medias.add(NewPostMediaModel.fromJson(item));
    return NewPostModel(
      caption: data["caption"],
      hashtags: _hashtags,
      location: data["location"],
      medias: _medias,
    );
  }
}

/*
{
  "result": {
    "caption": "string",
    "hashtags": [
      {
        "name": "string"
      }
    ],
    "location": {
      "lat": 0,
      "long": 0
    },
    "medias": [
      {
        "content_type": "string",
        "media_id": "string"
      }
    ]
  }
}
* */
