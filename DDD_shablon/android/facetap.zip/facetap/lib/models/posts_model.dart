import 'package:facetap/models/hashtag_model.dart';
import 'package:facetap/models/location_model.dart';
import 'package:facetap/models/medias_model.dart';
import 'package:facetap/models/user_model.dart';

class PostsModel {
  int count;
  List<PostModel> results;

  PostsModel({this.count, this.results});

  factory PostsModel.fromJson(Map<String, dynamic> data) {
    List<PostModel> results = [];
    for (var item in data['results']) {
      results.add(PostModel.fromJson(item));
    }
    return PostsModel(count: data['count'], results: results);
  }
}

class PostModel {
  String id;
  String createdAt;
  String updatedAt;
  String deletedAt;
  String caption;
  LocationModel location;
  List<MediaModel> medias;
  UserModel user;
  List<HashtagModel> hashtags;
  int likeCount;
  bool isLiked;
  int commentCount;
  int dislikeCount;
  bool isDisliked;
  int viewCount;
  bool isViewed;
  String locationName;
  String share;
  int points;
  int rating;
  int postHashtagPoint;
  bool saved;

  PostModel({
    this.id,
    this.createdAt,
    this.updatedAt,
    this.deletedAt,
    this.caption,
    this.location,
    this.medias,
    this.user,
    this.hashtags,
    this.likeCount,
    this.isLiked,
    this.commentCount,
    this.dislikeCount,
    this.isDisliked,
    this.viewCount,
    this.isViewed,
    this.locationName,
    this.share,
    this.points,
    this.rating,
    this.postHashtagPoint,
    this.saved,
  });

  factory PostModel.fromJson(Map<String, dynamic> data) {
    List<MediaModel> medias = [];
    List<HashtagModel> hashtags = [];
    UserModel user = UserModel.fromPostJson(data['user']);
    for (var item in data['medias']) medias.add(MediaModel.fromJson(item));
    if (data['hashtags'] != null) for (var item in data['hashtags']) hashtags.add(HashtagModel.fromJson(item));
    return PostModel(
      id: data['id'],
      createdAt: data['created_at'],
      updatedAt: data['updated_at'],
      deletedAt: data['deleted_at'],
      caption: data['caption'],
      location: data['location'],
      medias: medias,
      user: user,
      hashtags: hashtags,
      likeCount: data['like_count'],
      isLiked: data['is_liked'],
      commentCount: data['comment_count'],
      dislikeCount: data['dislike_count'],
      isDisliked: data['is_disliked'],
      viewCount: data['view_count'],
      isViewed: data['is_viewed'],
      locationName: data['location_name'],
      points: data['points'],
      rating: data['rating'],
      postHashtagPoint: data['post_hashtag_point'],
      saved: data['is_saved'],
    );
  }

  @override
  String toString() {
    return '''{
      id: $id, 
      caption: $caption, 
      location: $location, 
      medias: $medias, 
      user: $user,
      locationName: $locationName,
      saved: $saved,
    }''';
  }
}
