class RegisterModel {
  String result;

  RegisterModel({this.result});

  factory RegisterModel.fromJson(Map<String, dynamic> data) {
    return RegisterModel(result: data["result"]);
  }
}
