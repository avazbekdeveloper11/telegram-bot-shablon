class ShareModel {
  String mediaUrl;
  String contentType;
  String thumbnailUrl;
  String url;

  ShareModel({this.mediaUrl, this.contentType, this.url, this.thumbnailUrl});

  factory ShareModel.fromJson(Map<String, dynamic> data) {
    return ShareModel(
      mediaUrl: data['media_url'],
      contentType: data['content_type'],
      thumbnailUrl: data['thumbnail_url'],
      url: data['url'],
    );
  }

  @override
  String toString() {
    return '''{
        mediaUrl: $mediaUrl,
        contentType: $contentType,
        url: $url
      }''';
  }
}
