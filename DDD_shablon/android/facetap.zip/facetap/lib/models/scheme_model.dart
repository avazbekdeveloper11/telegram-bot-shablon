class SchemeModel {
  String scheme;
  String iconAssets;
  String name;

  SchemeModel(this.scheme, this.iconAssets, this.name);
}
