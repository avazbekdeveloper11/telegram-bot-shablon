class PlacesModel {
  String nextPageToken;
  List<PlaceModel> results;
  String status;

  PlacesModel({this.nextPageToken, this.results, this.status});

  factory PlacesModel.fromJson(Map<String, dynamic> data) {
    List<PlaceModel> results = [];
    for (var item in data["results"]) {
      results.add(PlaceModel.fromJson(item));
    }
    return PlacesModel(nextPageToken: data["next_page_token"], results: results, status: data['status']);
  }
}

class PlaceModel {
  String formattedAddress;
  GeometryModel geometry;
  String name;
  String vicinity;

  PlaceModel({
    this.formattedAddress,
    this.geometry,
    this.name,
    this.vicinity,
  });

  factory PlaceModel.fromJson(Map<String, dynamic> data) {
    GeometryModel geometry = GeometryModel.fromJson(data['geometry']);
    return PlaceModel(
      formattedAddress: data['formatted_address'],
      geometry: geometry,
      name: data['name'],
      vicinity: data['vicinity'],
    );
  }

  @override
  String toString() {
    return '''{
        formatted_address: $formattedAddress,
        geometry: $geometry, 
        name: $name, 
        vicinity: $vicinity
      }''';
  }
}

class GeometryModel {
  PlaceLocationModel location;

  GeometryModel({this.location});

  factory GeometryModel.fromJson(Map<String, dynamic> data) {
    return GeometryModel(location: PlaceLocationModel.fromJson(data['location']));
  }

  @override
  String toString() {
    return '''{
        location: $location
    }''';
  }
}

class PlaceLocationModel {
  double lat;
  double lng;

  PlaceLocationModel({this.lat, this.lng});

  factory PlaceLocationModel.fromJson(Map<String, dynamic> data) {
    return PlaceLocationModel(lat: data["lat"], lng: data["lng"]);
  }

  @override
  String toString() {
    return '''{
        lat: $lat,
        lng: $lng
    }''';
  }
}
