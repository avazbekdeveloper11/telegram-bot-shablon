import 'package:facetap/models/user_model.dart';

class AllGiftsModel {
  int count;
  List<GiftModel> results;

  AllGiftsModel({this.count, this.results});

  factory AllGiftsModel.fromJson(Map<String, dynamic> data) {
    List<GiftModel> results = [];
    for (var item in data["results"]) {
      results.add(GiftModel.fromJson(item));
    }
    return AllGiftsModel(count: data['count'], results: results);
  }
}

class GiftModel {
  String category;
  int count;
  List<GiftTempsModel> giftTemps;

  GiftModel({this.category, this.count, this.giftTemps});

  factory GiftModel.fromJson(Map<String, dynamic> data) {
    List<GiftTempsModel> results = [];
    for (var item in data["giftTemps"]) {
      results.add(GiftTempsModel.fromJson(item));
    }
    return GiftModel(category: data['category'], count: data['count'], giftTemps: results);
  }
}

class GiftTempsModel {
  String id;
  String title;
  GiftMediaModel image;
  int price;
  int senderPoints;
  int receiverPoints;
  String createdAt;
  String updatedAt;
  String category;
  String message;

  GiftTempsModel(
      {this.id, this.title, this.image, this.price, this.senderPoints, this.receiverPoints, this.createdAt, this.updatedAt, this.category, this.message});

  factory GiftTempsModel.fromJson(Map<String, dynamic> data) {
    return GiftTempsModel(
      id: data['id'],
      title: data['title'],
      image: GiftMediaModel.fromJson(data['image']),
      price: data['price'],
      senderPoints: data['sender_points'],
      receiverPoints: data['receiver_points'],
      createdAt: data['created_at'],
      updatedAt: data['updated_at'],
      category: data['category'],
    );
  }
}

class GiftMediaModel {
  String contentType;
  String mediaId;
  String mediaUrl;
  String giftTempId;
  String media720x1280Url;

  GiftMediaModel({this.contentType, this.mediaId, this.mediaUrl, this.giftTempId, this.media720x1280Url});

  factory GiftMediaModel.fromJson(Map<String, dynamic> data) {
    return GiftMediaModel(
      contentType: data['content_type'],
      mediaId: data['media_id'],
      mediaUrl: data['media_url'],
      giftTempId: data['gift_temp_id'],
      media720x1280Url: data['media_720x1280_url'],
    );
  }
}

class UserGiftsModel {
  int count;
  List<MyGiftModel> results;

  UserGiftsModel({this.count, this.results});

  factory UserGiftsModel.fromJson(Map<String, dynamic> data) {
    List<MyGiftModel> results = [];
    for (var item in data['results']) {
      results.add(MyGiftModel.fromJson(item));
    }
    return UserGiftsModel(count: data['count'], results: results);
  }
}

class MyGiftModel {
  String id;
  String message;
  String purchasedAt;
  String receiverId;
  UserModel sender;
  String sentAt;
  GiftTempsModel giftTemp;

  MyGiftModel({this.id, this.purchasedAt, this.sentAt, this.receiverId, this.message, this.sender, this.giftTemp});

  factory MyGiftModel.fromJson(Map<String, dynamic> data) {
    return MyGiftModel(
      id: data['id'],
      purchasedAt: data['purchased_at'],
      sentAt: data['sent_at'],
      receiverId: data['receiver_id'],
      message: data['message'],
      sender: UserModel.fromGiftJson(data['sender']),
      giftTemp: GiftTempsModel.fromJson(data['giftTemp']),
    );
  }
}

class BoughtGiftModel {
  String giftId;

  BoughtGiftModel({
    this.giftId,
  });

  factory BoughtGiftModel.fromJson(Map<String, dynamic> data) {
    return BoughtGiftModel(
      giftId: data['gift_id'],
    );
  }
}
