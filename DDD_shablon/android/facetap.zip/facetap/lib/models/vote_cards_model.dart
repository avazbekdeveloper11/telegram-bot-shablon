class VoteCardsModel {
  int count;
  List<VoteCardModel> results;

  VoteCardsModel({this.count, this.results});

  factory VoteCardsModel.fromJson(Map<String, dynamic> data) {
    List<VoteCardModel> list = [];
    for (var item in data['vote_cards']) list.add(VoteCardModel.fromJson(item));
    return VoteCardsModel(count: data['count'] ?? 0, results: list);
  }
}

class VoteCardModel {
  int id;
  int qty;
  double price;
  bool isOld;
  String purchaseId;

  VoteCardModel({this.id, this.qty, this.price, this.isOld, this.purchaseId});

  factory VoteCardModel.fromJson(Map<String, dynamic> data) {
    return VoteCardModel(id: data['id'], qty: data['qty'], price: data['price'], isOld: data['is_old'], purchaseId: data['purchase_id']);
  }
}

class UserVotes {
  int votes;

  UserVotes({this.votes});

  factory UserVotes.fromJson(Map<String, dynamic> data) {
    return UserVotes(votes: data['votes']);
  }
}
