class TokensModel {
  String accessToken;
  String refreshToken;

  TokensModel({
    this.accessToken,
    this.refreshToken,
  });

  //getters.
  String get hasToken => this.accessToken;

  String get hasRefreshToken => this.refreshToken;

  //setters.
  set setToken(String token) => this.accessToken = token;

  set setRefreshToken(String token) => this.refreshToken = token;

  void fromJson(Map<String, dynamic> data) {
    accessToken = data['access_token'] ?? accessToken;
    refreshToken = data['refresh_token'] ?? refreshToken;
  }

  factory TokensModel.fromJson(Map<String, dynamic> data) {
    return TokensModel(
      accessToken: data["access_token"],
      refreshToken: data["refresh_token"],
    );
  }
}
