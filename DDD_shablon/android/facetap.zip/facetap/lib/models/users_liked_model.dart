import 'package:facetap/models/user_model.dart';

class UsersLikedModel {
  List<UserModel> users;

  UsersLikedModel({this.users});

  factory UsersLikedModel.fromJson(Map<String, dynamic> data) {
    List<UserModel> users = [];
    print(data["users"]);
    for (var item in data["users"]) {
      print(item['id']);
      users.add(UserModel.fromLikedJson(item));}
    print(users);
    return UsersLikedModel(users: users);
  }
}
