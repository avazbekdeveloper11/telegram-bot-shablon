import 'package:facetap/models/user_model.dart';

class TopUserModel {
  List<UserModel> users;

  TopUserModel({this.users});

  factory TopUserModel.fromJson(Map<String, dynamic> data) {
    List<UserModel> users = [];
    print(data["topUsers"]);
    for (var item in data["TopUsers"]) {
      print(item['id']);
      users.add(UserModel.fromTopUserJson(item));}
    print(users);
    return TopUserModel(users: users);
  }
}