class ErrorModel {
  ErrorBodyModel error;

  ErrorModel({this.error});

  factory ErrorModel.fromJson(Map<String, dynamic> data) {
    return ErrorModel(error: ErrorBodyModel.fromJson(data['error']));
  }

  @override
  String toString() {
    return '''{
        error: $error,
    }''';
  }
}

class ErrorBodyModel {
  String status;
  String message;

  ErrorBodyModel({this.status, this.message});

  factory ErrorBodyModel.fromJson(Map<String, dynamic> data) {
    return ErrorBodyModel(status: data['status'] ?? data['Status'], message: data['message'] ?? data['Message']);
  }

  @override
  String toString() {
    return '''{
        status: $status,
        message: $message
    }''';
  }
}
