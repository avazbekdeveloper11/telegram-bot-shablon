class LikesModel {
  int count;
  bool liked;

  LikesModel({this.count, this.liked});

  factory LikesModel.fromJson(Map<String, dynamic> data) {
    return LikesModel(count: data["count"], liked: data["liked"]);
  }

  Map<String, dynamic> toJson() => {'count': count, 'liked': liked};
}
