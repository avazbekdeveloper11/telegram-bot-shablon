class LocationModel {
  double lat;
  double long;

  LocationModel({this.lat, this.long});

  factory LocationModel.fromJson(Map<String, dynamic> data) {
    return LocationModel(lat: data["lat"], long: data["long"]);
  }

  Map<String, dynamic> toJson() => {'lat': lat, 'long': long};

  @override
  String toString() {
    return '''{
        lat: $lat,
        long: $long
    }''';
  }
}
