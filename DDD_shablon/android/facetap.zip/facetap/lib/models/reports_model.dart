class ReportTypesModel {
  int count;
  List<ReportTypeModel> results;

  ReportTypesModel({this.count, this.results});

  factory ReportTypesModel.fromJson(Map<String, dynamic> data) {
    List<ReportTypeModel> results = [];
    for (var item in data['report_types']) results.add(ReportTypeModel.fromJson(item));
    return ReportTypesModel(count: data['count'], results: results);
  }
}

class ReportTypeModel {
  String message;
  int id;

  ReportTypeModel({this.message, this.id});

  factory ReportTypeModel.fromJson(Map<String, dynamic> data) {
    return ReportTypeModel(message: data['message'], id: data['id']);
  }
}
