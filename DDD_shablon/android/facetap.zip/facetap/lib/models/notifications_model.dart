class NotificationsModel {
  int count;
  List<NotificationModel> results;

  NotificationsModel({this.count, this.results});

  factory NotificationsModel.fromJson(Map<String, dynamic> data) {
    List<NotificationModel> results = [];
    for (var item in data['notification_list']) results.add(NotificationModel.fromJson(item));
    var model = NotificationsModel(count: data['count_all'], results: results);
    return model;
  }

  @override
  String toString() {
    return '''{
        count: $count,
        results: $results
      }''';
  }
}

class NotificationModel {
  String id;
  String content;
  String senderId;
  String objectId;
  String objectType;
  String username;
  String status;
  String type;
  String sentDate; // "2021-07-03T07:23:53Z"
  String profilePhoto;
  String objectPhoto;
  String mediaId;
  String date; // "ThisMonth"

  NotificationModel(
      {this.id,
      this.content,
      this.senderId,
      this.objectId,
      this.objectType,
      this.username,
      this.status,
      this.type,
      this.sentDate,
      this.profilePhoto,
      this.mediaId,
      this.objectPhoto,
      this.date});

  factory NotificationModel.fromJson(Map<String, dynamic> data) {
    var model = NotificationModel(
      id: data['id'],
      content: data['content'],
      senderId: data['sender_id'],
      objectId: data['object_id'],
      objectType: data['object_type'],
      username: data['username'],
      status: data['status'],
      type: data['type'],
      sentDate: data['sent_date'],
      profilePhoto: data['profile_photo'],
      mediaId: data['media_id'],
      objectPhoto: data['object_photo'],
      date: data['date'],
    );
    return model;
  }

  @override
  String toString() {
    return '''{
        id: $id,
        content: $content,
        senderId: $senderId,
        objectId: $objectId,
        objectType: $objectType,
        username: $username,
        status: $status,
        type: $type,
        sentDate: $sentDate,
        profilePhoto: $profilePhoto,
        mediaId: $mediaId,
        objectPhoto: $objectPhoto
        date: $date
      }''';
  }
}
