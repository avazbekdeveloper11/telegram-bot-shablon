class UserModel {
  String id;
  String firstName;
  String lastName;
  String username;
  String email;
  int followersCount;
  int followingCount;
  String isFollowing;
  String amIFollowing;
  bool amIBlocked;
  bool isHeBlocked;
  String profilePhoto;
  String profileBanner;
  String bio;
  bool isBlockedByAdmin;
  bool isVerifiedByAdmin;
  String accessToken;
  String refreshToken;
  int rating;
  int points;
  String share;
  String locationName;
  int votes;

  UserModel({
    this.id = '',
    this.firstName = '',
    this.lastName = '',
    this.username = '',
    this.email = '',
    this.followersCount = 0,
    this.followingCount = 0,
    this.isFollowing = 'false',
    this.amIFollowing = 'false',
    this.amIBlocked = false,
    this.isHeBlocked = false,
    this.profilePhoto = '',
    this.profileBanner = '',
    this.bio = '',
    this.isBlockedByAdmin = false,
    this.isVerifiedByAdmin = false,
    this.accessToken = '',
    this.refreshToken = '',
    this.rating = 0,
    this.points = 0,
    this.share,
    this.locationName,
    this.votes,
  });

  factory UserModel.fromProfileJson(Map<String, dynamic> data) {
    return UserModel(
      id: data['id'],
      firstName: data['first_name'],
      lastName: data['last_name'],
      username: data['username'],
      email: data['email'],
      followersCount: data['followers_count'],
      followingCount: data['following_count'],
      isFollowing: data['is_following'],
      amIFollowing: data['am_i_following'],
      amIBlocked: data['am_i_blocked_by_him'],
      isHeBlocked: data['is_he_blocked_by_me'],
      profilePhoto: data['profile_photo'],
      profileBanner: data['profile_banner'],
      bio: data['bio'],
      isBlockedByAdmin: data['is_blocked_by_admin'],
      isVerifiedByAdmin: data['is_verified_by_admin'],
      rating: data['rating'],
      points: data['points'],
      votes: data['votes'],
    );
  }

  factory UserModel.fromSearchJson(Map<String, dynamic> data) {
    return UserModel(
      id: data['id'],
      firstName: data['first_name'],
      lastName: data['last_name'],
      username: data['username'],
      email: data['email'],
      followersCount: data['followers_count'],
      followingCount: data['following_count'],
      isFollowing: data['is_following'],
      amIFollowing: data['am_i_following'],
      amIBlocked: data['am_i_blocked_by_him'],
      isHeBlocked: data['is_he_blocked_by_me'],
      profilePhoto: data['profile_photo'],
      profileBanner: data['profile_banner'],
      bio: data['bio'],
      isBlockedByAdmin: data['is_blocked_by_admin'],
      isVerifiedByAdmin: data['is_verified_by_admin'],
      rating: data['rating'],
      points: data['points'],
    );
  }

  factory UserModel.fromUpdateJson(Map<String, dynamic> data) {
    return UserModel(
      bio: data['bio'],
      firstName: data['first_name'],
      lastName: data['last_name'],
      profilePhoto: data['profile_photo'],
      profileBanner: data['profile_banner'],
      username: data['username'],
    );
  }

  factory UserModel.fromPostJson(Map<String, dynamic> data) {
    return UserModel(
      id: data['id'],
      username: data['username'],
      profilePhoto: data['profile_photo'],
      profileBanner: data['profile_banner'] ?? "",
      email: data['email'],
      amIFollowing: data['am_i_following'],
      isVerifiedByAdmin: data['is_verified'],
    );
  }

  factory UserModel.fromCommentJson(Map<String, dynamic> data) {
    return UserModel(
      id: data['id'],
      username: data['username'],
      profilePhoto: data['profile_photo'],
      profileBanner: data['profile_banner'],
      email: data['email'],
    );
  }

  factory UserModel.fromLikedJson(Map<String, dynamic> data) {
    return UserModel(
      id: data['id'],
      profilePhoto: data['profile_photo'],
      username: data['username'],
      firstName: data['first_name'],
      lastName: data['last_name'],
      isFollowing: data['is_following'],
      amIFollowing: data['am_i_following'],
    );
  }

  factory UserModel.fromFollowJson(Map<String, dynamic> data) {
    return UserModel(
      id: data['id'],
      firstName: data['first_name'],
      lastName: data['last_name'],
      username: data['username'],
      profilePhoto: data['profile_photo'],
      amIFollowing: data['am_i_following'],
    );
  }

  factory UserModel.fromTopUserJson(Map<String, dynamic> data) {
    return UserModel(
      amIFollowing: data['am_i_following'],
      bio: data['bio'],
      id: data['id'],
      profilePhoto: data['profile_photo'],
      username: data['username'],
    );
  }

  factory UserModel.fromGiftJson(Map<String, dynamic> data) {
    return UserModel(
      email: data['email'],
      firstName: data['first_name'],
      id: data['id'],
      lastName: data['last_name'],
      profilePhoto: data['profile_photo'],
      username: data['username'],
    );
  }

  String get hasToken => this.accessToken;

  String get hasRefreshToken => this.refreshToken;

  //setters.
  set setToken(String token) => this.accessToken = token;

  set setRefreshToken(String token) => this.refreshToken = token;

  void regFromJson(Map<String, dynamic> data) {
    accessToken = data['access_token'];
    refreshToken = data['refresh_token'];
  }

  void verifyFromJson(Map<String, dynamic> data) {
    id = data['id'];
    accessToken = data['access_token'];
    refreshToken = data['refresh_token'];
  }

  void loginFromJson(Map<String, dynamic> data) {
    accessToken = data['access_token'];
    email = data['email'];
    refreshToken = data['refresh_token'];
    id = data['id'];
    firstName = data['first_name'];
    lastName = data['last_name'];
    profilePhoto = data['profile_photo'];
    profileBanner = data['profile_banner'];
    username = data['username'];
    bio = data['bio'];
  }

  void fromJson(Map<String, dynamic> data) {
    id = data['id'];
    firstName = data['first_name'];
    lastName = data['last_name'];
    username = data['username'];
    email = data['email'];
    followersCount = data['followers_count'];
    followingCount = data['following_count'];
    isFollowing = data['is_following'];
    amIFollowing = data['am_i_following'];
    amIBlocked = data['am_i_blocked_by_him'];
    isHeBlocked = data['is_he_blocked_by_me'];
    profilePhoto = data['profile_photo'];
    profileBanner = data['profile_banner'];
    bio = data['bio'];
    isBlockedByAdmin = data['is_blocked_by_admin'];
    isVerifiedByAdmin = data['is_verified_by_admin'];
    votes = data['votes'];
  }

  void setProfile(UserModel user) {
    id = user.id;
    firstName = user.firstName;
    lastName = user.lastName;
    username = user.username;
    email = user.email;
    followersCount = user.followersCount;
    followingCount = user.followingCount;
    amIBlocked = user.amIBlocked;
    isHeBlocked = user.isHeBlocked;
    profilePhoto = user.profilePhoto;
    profileBanner = user.profileBanner;
    bio = user.bio;
    isBlockedByAdmin = user.isBlockedByAdmin;
    isVerifiedByAdmin = user.isVerifiedByAdmin;
    rating = user.rating;
    votes = user.votes;
  }

  void setProfileAuth(String accessToken, String refreshToken) {
    this.accessToken = accessToken;
    this.refreshToken = refreshToken;
  }

  @override
  String toString() {
    return '''{
        id: $id, 
        username: $username, 
        profilePhoto: $profilePhoto, 
        profileBanner: $profileBanner,
        amIFollowing: $amIFollowing,
        isFollowing: $isFollowing,
        votes: $votes,
      }''';
  }
}
