class UploadUrlModel {
  List<UrlModel> uploadUrls;

  UploadUrlModel({this.uploadUrls});

  factory UploadUrlModel.fromJson(Map<String, dynamic> data) {
    List<UrlModel> _uploadUrls = [];
    for (var item in data['upload_urls']) _uploadUrls.add(UrlModel.fromJson(item));
    return UploadUrlModel(uploadUrls: _uploadUrls);
  }
}

class UrlModel {
  String filename;
  String metadata;
  String url;

  UrlModel({this.filename, this.metadata, this.url});

  factory UrlModel.fromJson(Map<String, dynamic> data) {
    return UrlModel(
      filename: data['filename'],
      metadata: data['metadata'],
      url: data['url'],
    );
  }
}

class GenerateUrlModel {
  String contentType;
  String metadata;

  GenerateUrlModel({this.contentType, this.metadata});

  Map<String, dynamic> toJson() => {'content_type': contentType, 'metadata': metadata};
}

class GenerateUrlListModel {
  List<GenerateUrlModel> list;

  GenerateUrlListModel({this.list});

  Map<String, dynamic> toJson() => {'upload_file_objects': list};
}

class UploadFile {
  String filename;

  UploadFile({this.filename});

  factory UploadFile.fromJson(Map<String, dynamic> data) {
    return UploadFile(filename: data['file_name']);
  }
}
