import 'package:facetap/models/user_model.dart';

class CommentsListModel {
  int count;
  List<CommentModel> comments;

  CommentsListModel({this.count, this.comments});

  factory CommentsListModel.fromJson(Map<String, dynamic> data) {
    List<CommentModel> comments = [];
    for (var item in data['results']) comments.add(CommentModel.fromJson(item));
    return CommentsListModel(count: data['count'], comments: comments);
  }
}

class CommentModel {
  String id;
  String content;
  String createdAt;
  String updatedAt;
  UserModel user;
  String objectId;
  String objectType;
  String status;
  int likeCount;
  bool isLiked;
  int replyCount;
  List<CommentModel> replies = [];

  CommentModel({
    this.id = '',
    this.content,
    this.createdAt = '',
    this.updatedAt = '',
    this.user,
    this.objectId,
    this.objectType,
    this.status,
    this.likeCount = 0,
    this.isLiked = false,
    this.replyCount = 0,
    this.replies,
  });

  factory CommentModel.fromJson(Map<String, dynamic> data) {
    return CommentModel(
      id: data['id'],
      content: data['content'],
      createdAt: data['created_at'],
      updatedAt: data['updated_at'],
      objectId: data['object_id'],
      objectType: data['object_type'],
      status: data['status'],
      user: UserModel.fromCommentJson(data['user']),
      likeCount: data['like_count'],
      isLiked: data['is_liked'],
      replyCount: data['reply_count'],
      replies: [],
    );
  }
}
