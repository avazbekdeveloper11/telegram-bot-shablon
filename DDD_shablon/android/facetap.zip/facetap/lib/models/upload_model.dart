class UploadModel {
  String mediaUrl;
  String mediaPath;
  String thumbnailPath;
  String contentType; String metaType; Map<String, dynamic> data;
  UploadModel({this.mediaUrl = '', this.mediaPath = '', this.contentType='', this.metaType='', this.data, this.thumbnailPath=''});

  void setProfile(UploadModel uploadModel) {
mediaPath = uploadModel.mediaPath;
mediaUrl = uploadModel.mediaUrl;
contentType = uploadModel.contentType;
metaType = uploadModel.metaType;
data = uploadModel.data;
thumbnailPath = uploadModel.thumbnailPath;
  }
}
