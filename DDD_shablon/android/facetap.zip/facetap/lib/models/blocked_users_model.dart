class BlockedUsersModel {
  int count;
  List<BlockedModel> results;

  BlockedUsersModel({this.count, this.results});

  factory BlockedUsersModel.fromJson(Map<String, dynamic> data) {
    List<BlockedModel> users = [];
    for (var item in data['users']) users.add(BlockedModel.fromJson(item));
    return BlockedUsersModel(count: data['count'], results: users);
  }
}

class BlockedModel {
  String firstName;
  String id;
  String isBusiness;
  bool isBlocked;
  String lastName;
  String profilePhoto;
  String username;

  BlockedModel({
    this.firstName,
    this.id,
    this.isBusiness,
    this.lastName,
    this.profilePhoto,
    this.username,
    this.isBlocked = true,
  });

  factory BlockedModel.fromJson(Map<String, dynamic> data) {
    return BlockedModel(
        firstName: data['first_name'],
        id: data['id'],
        isBusiness: data['is_business'],
        lastName: data['last_name'],
        profilePhoto: data['profile_photo'],
        username: data['username'],
        isBlocked: data['is_blocked'] ?? true);
  }
}
