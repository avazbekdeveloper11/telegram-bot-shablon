import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:pedantic/pedantic.dart';

class NewPostMediaModel {
  String contentType;
  String mediaId;

  NewPostMediaModel({this.contentType, this.mediaId});

  factory NewPostMediaModel.fromJson(Map<String, dynamic> data) {
    return NewPostMediaModel(contentType: data["content_type"], mediaId: data["media_id"]);
  }

  Map<String, dynamic> toJson() => {'content_type': contentType, 'media_id': mediaId};

  @override
  String toString() {
    return '''{
        contentType: $contentType, 
        mediaId: $mediaId, 
      }''';
  }
}

class MediaModel {
  String contentType;
  String mediaId;
  String mediaUrl;
  int orderNo;
  String postId;
  String thumbnailUrl;
  String thumbnail720x1280Url;
  String thumbnail480x858Url;
  String media720x1280Url;

  MediaModel({
    this.contentType,
    this.mediaId,
    this.mediaUrl,
    this.orderNo,
    this.postId,
    this.thumbnailUrl,
    this.thumbnail720x1280Url,
    this.thumbnail480x858Url,
    this.media720x1280Url,
  });
static getData(String url) async {
  final fileInfo = await DefaultCacheManager().getFileFromCache(url);
  if (fileInfo == null || fileInfo.file == null) {
    unawaited(DefaultCacheManager().downloadFile(url));
  }
}
  factory MediaModel.fromJson(Map<String, dynamic> data)  {
    if(data['content_type']=='video/mp4') {
      getData(data['media_url']);
    }
    return MediaModel(
      contentType: data['content_type'],
      mediaId: data['media_id'],
      mediaUrl: data['media_url'],
      orderNo: data['order_no'],
      postId: data['post_id'],
      thumbnailUrl: data['thumbnail_url'],
      thumbnail720x1280Url: data['thumbnail_720x1280_url'],
      thumbnail480x858Url: data['thumbnail_480x858_url'],
      media720x1280Url: data['media_720x1280_url'],
    );
  }

  @override
  String toString() {
    return '''{
        contentType: $contentType, 
        mediaId: $mediaId, 
        mediaUrl: $mediaUrl, 
        orderNo: $orderNo, 
        postId: $postId, 
        thumbnailUrl: $thumbnailUrl
      }''';
  }
}
