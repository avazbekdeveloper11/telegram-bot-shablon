class VerificationCodeModel {
  String accessToken;
  String id;
  String refreshToken;

  VerificationCodeModel({this.accessToken, this.id, this.refreshToken});

  factory VerificationCodeModel.fromJson(Map<String, dynamic> data) {
    return VerificationCodeModel(
      accessToken: data["access_token"],
      id: data["id"],
      refreshToken: data["refresh_token"],
    );
  }
}
