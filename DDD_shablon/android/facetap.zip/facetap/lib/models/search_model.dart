import 'dart:convert';

SearchModel welcomeFromJson(String str) => SearchModel.fromJson(json.decode(str));

String welcomeToJson(SearchModel data) => json.encode(data.toJson());

class SearchModel {
  SearchModel({
    this.users,
    this.hashtags,
    this.locations,
    this.posts,
    this.count,
  });

  SearchPosts users;
  SearchPosts hashtags;
  SearchPosts locations;
  SearchPosts posts;
  int count;

  factory SearchModel.fromJson(Map<String, dynamic> json) {
   return SearchModel(
      users: json["users"]!=null ? SearchPosts.fromJson(json["users"]) : SearchPosts(),
      hashtags: json["hashtags"]!=null ? SearchPosts.fromJson(json["hashtags"]) : SearchPosts(),
      locations: json["locations"]!=null ? SearchPosts.fromJson(json["locations"]) : SearchPosts(),
      posts: json["posts"]!=null ? SearchPosts.fromJson(json["posts"]) : SearchPosts(),
      count: json["count"],
    );
  }

  Map<String, dynamic> toJson() => {
    "users": users.toJson(),
    "hashtags": hashtags.toJson(),
    "locations": locations.toJson(),
    "posts": posts.toJson(),
    "count": count,
  };
}

class SearchPosts {
  SearchPosts({
    this.res,
    this.count,
  });

  List<SearchPost> res;
  int count;

  factory SearchPosts.fromJson(Map<String, dynamic> json) {
   return json["res"]!=null ?
   SearchPosts(
      res: List<SearchPost>.from(json["res"].map((x) => SearchPost.fromJson(x))),
      count: json["count"],
    ): SearchPosts();
  }
  Map<String, dynamic> toJson() => {
    "res": List<dynamic>.from(res.map((x) => x.toJson())),
    "count": count,
  };
}

class SearchPost {
  SearchPost({
    this.id,
    this.title,
    this.description,
    this.profilePhoto,
    this.type,
  });

  String id;
  String title;
  String description;
  String profilePhoto;
  String type;

  factory SearchPost.fromJson(Map<String, dynamic> json) {
  return  SearchPost(
      id: json["id"],
      title: json["title"],
      description: json["description"],
      profilePhoto: json["media_url"],
      type: json["type"],
    );
  }

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "description": description,
    "profile_photo": profilePhoto,
    "type": type,
  };
}



class SearchSuggestModel {
  SearchSuggestModel({
    this.searchTitles,
    this.count,
  });

  List<String> searchTitles;
  int count;

  factory SearchSuggestModel.fromJson(Map<String, dynamic> json) => SearchSuggestModel(
    searchTitles: List<String>.from(json["search_titles"].map((x) => x)),
    count: json["count"],
  );

  Map<String, dynamic> toJson() => {
    "search_titles": List<dynamic>.from(searchTitles.map((x) => x)),
    "count": count,
  };
}